"""Patch the generated Android project for aorc ai.

- INTERNET, RECORD_AUDIO, POST_NOTIFICATIONS, RECEIVE_BOOT_COMPLETED, VIBRATE permissions
- <queries>: TTS service and speech recognition
- notification receivers (flutter_local_notifications)
- app label "aorc ai"
- core library desugaring (required by flutter_local_notifications)
"""
import glob
import re
import sys

PATH = "android/app/src/main/AndroidManifest.xml"
with open(PATH, "r", encoding="utf-8") as f:
    xml = f.read()

perms = [
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.VIBRATE",
]
for p in perms:
    if p not in xml:
        xml = re.sub(r"(<manifest[^>]*>)", r'\1\n    <uses-permission android:name="%s"/>' % p, xml, count=1)

q_items = [
    ("TTS_SERVICE", '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'),
    ("RecognitionService", '<intent><action android:name="android.speech.RecognitionService"/></intent>'),
]
for key, item in q_items:
    if key not in xml:
        if "<queries>" in xml:
            xml = xml.replace("<queries>", "<queries>\n        " + item, 1)
        else:
            xml = xml.replace("<application", "<queries>\n        " + item + "\n    </queries>\n    <application", 1)

receivers = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""
if "ScheduledNotificationReceiver" not in xml:
    xml = xml.replace("</application>", receivers + "    </application>", 1)

xml = re.sub(r'android:label="[^"]*"', 'android:label="aorc ai"', xml, count=1)
with open(PATH, "w", encoding="utf-8") as f:
    f.write(xml)
print("Manifest patched")

# ---- Gradle: core library desugaring ----
files = glob.glob("android/app/build.gradle.kts") + glob.glob("android/app/build.gradle")
if not files:
    print("WARNING: no app build.gradle found")
    sys.exit(0)
g = files[0]
with open(g, "r", encoding="utf-8") as f:
    src = f.read()
kts = g.endswith(".kts")
if "coreLibraryDesugaring" not in src:
    if kts:
        src = re.sub(r"(compileOptions\s*\{)", r"\1\n        isCoreLibraryDesugaringEnabled = true", src, count=1)
        dep = '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")\n}\n'
    else:
        src = re.sub(r"(compileOptions\s*\{)", r"\1\n        coreLibraryDesugaringEnabled true", src, count=1)
        dep = "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'\n}\n"
    src += dep
    with open(g, "w", encoding="utf-8") as f:
        f.write(src)
print("Gradle patched:", g)
