import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Read-only story view: words that match your cards are underlined and tappable.
class StoryReader extends StatelessWidget {
  final String text;
  final bool rtl;
  const StoryReader({super.key, required this.text, this.rtl = false});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final map = <String, CardItem>{};
    for (final c in s.cards) {
      final k = c.front.trim().toLowerCase();
      if (k.isNotEmpty) map[k] = c;
    }
    const style = TextStyle(fontSize: 16.5, height: 1.7, fontWeight: FontWeight.w500, color: C.ink);
    if (map.isEmpty || text.trim().isEmpty) {
      return Directionality(
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        child: Text(text, style: style),
      );
    }
    final keys = map.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
    final re = RegExp(
      '(?<![\\p{L}\\p{N}])(${keys.map(RegExp.escape).join('|')})(?![\\p{L}\\p{N}])',
      caseSensitive: false,
      unicode: true,
    );
    final spans = <InlineSpan>[];
    int pos = 0;
    int hits = 0;
    for (final m in re.allMatches(text)) {
      if (m.start > pos) spans.add(TextSpan(text: text.substring(pos, m.start)));
      final word = m.group(0)!;
      final card = map[word.toLowerCase()];
      if (card != null) {
        hits++;
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.baseline,
          baseline: TextBaseline.alphabetic,
          child: GestureDetector(
            onTap: () => _show(context, card),
            child: Container(
              decoration: const BoxDecoration(
                color: C.creamDeep,
                border: Border(bottom: BorderSide(color: C.ink, width: 2.5)),
              ),
              child: Text(word, style: style.copyWith(fontWeight: FontWeight.w900)),
            ),
          ),
        ));
      } else {
        spans.add(TextSpan(text: word));
      }
      pos = m.end;
    }
    if (pos < text.length) spans.add(TextSpan(text: text.substring(pos)));
    return Directionality(
      textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          tx('${t('known_words')}: $hits', size: 12.5, bold: true, color: C.gray),
          const SizedBox(height: 8),
          Text.rich(TextSpan(style: style, children: spans)),
        ],
      ),
    );
  }

  void _show(BuildContext context, CardItem c) {
    final s = AppState.I;
    Speech.speak(c.front, s.frontLang);
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: C.cream,
        shape: const RoundedRectangleBorder(side: BorderSide(color: C.ink, width: 3)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              tx(c.front, size: 24, bold: true),
              const SizedBox(height: 6),
              tx(c.back, size: 20, bold: true, color: C.dark, align: TextAlign.center),
              if ((c.example ?? '').isNotEmpty) ...[
                const SizedBox(height: 8),
                tx(c.example!, size: 13, color: C.gray, align: TextAlign.center),
              ],
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SpeakBtn(c.front, s.frontLang),
                  const SizedBox(width: 8),
                  SpeakBtn(c.back, s.backLang),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: PixelButton(
                      label: t('dont_know'),
                      filled: false,
                      small: true,
                      expand: true,
                      onTap: () async {
                        Navigator.pop(ctx);
                        c.applyReview(0);
                        await s.saveCards();
                        await s.recordReview();
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: PixelButton(
                      label: t('know'),
                      icon: 'check',
                      small: true,
                      expand: true,
                      onTap: () async {
                        Navigator.pop(ctx);
                        c.applyReview(4);
                        await s.saveCards();
                        await s.recordReview();
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
