import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'progress.dart';

const List<String> kLevels = ['A1', 'A2', 'B1', 'B2', 'C1'];

class _PQ {
  final String level, q;
  final List<String> options;
  final int answer;
  int? picked;
  _PQ(this.level, this.q, this.options, this.answer);
}

class _Sug {
  final String word, translation;
  bool on = true;
  _Sug(this.word, this.translation);
}

/// 20-question placement test (A1..C1) that estimates the learner's level.
class PlacementScreen extends StatefulWidget {
  const PlacementScreen({super.key});
  @override
  State<PlacementScreen> createState() => _PlacementScreenState();
}

class _PlacementScreenState extends State<PlacementScreen> {
  int phase = 0; // 0 intro, 1 loading, 2 quiz, 3 result
  List<_PQ> qs = [];
  int i = 0;
  String result = '';
  bool busy = false;
  List<_Sug> sugs = [];
  final topic = TextEditingController();

  AppState get s => AppState.I;

  @override
  void dispose() {
    topic.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    setState(() => phase = 1);
    try {
      final lang = langOf(s.frontLang).en;
      final r = await Ai.chat(
        'Create a $lang placement test of exactly 20 multiple-choice questions: 4 each for CEFR levels '
        'A1, A2, B1, B2, C1, in that order (vocabulary, grammar, fill-in-the-blank and short reading). '
        'Each question has exactly 4 options and one correct option. Write questions in $lang. '
        'Output ONLY a JSON array like [{"level":"A1","q":"...","options":["...","...","...","..."],"answer":0}] '
        'where answer is the zero-based index of the correct option.',
        system: 'You are an experienced language examiner. Output valid JSON only.',
        maxTokens: 3500,
        temp: 0.5,
      );
      final out = <_PQ>[];
      for (final e in Ai.jsonList(r)) {
        if (e is! Map) continue;
        final lv = (e['level'] ?? '').toString().toUpperCase();
        final opts = (e['options'] as List? ?? []).map((x) => x.toString()).toList();
        final a = e['answer'] is num ? (e['answer'] as num).toInt() : -1;
        if (kLevels.contains(lv) && opts.length >= 2 && a >= 0 && a < opts.length) {
          out.add(_PQ(lv, (e['q'] ?? '').toString(), opts, a));
        }
      }
      if (out.length < 8) throw AiError(t('bad_ai_format'));
      if (mounted) {
        setState(() {
          qs = out;
          i = 0;
          phase = 2;
        });
      }
    } catch (e) {
      if (mounted) {
        toast(context, errText(e));
        setState(() => phase = 0);
      }
    }
  }

  void _pick(int k) {
    final q = qs[i];
    if (q.picked != null) return;
    setState(() => q.picked = k);
    Sfx.play(k == q.answer ? 'ok' : 'bad');
    Future.delayed(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      if (i + 1 >= qs.length) {
        _finish();
      } else {
        setState(() => i++);
      }
    });
  }

  void _finish() {
    // highest level reached while every level up to it scored at least 60%
    String lvl = 'A1';
    for (final l in kLevels) {
      final group = qs.where((q) => q.level == l).toList();
      if (group.isEmpty) break;
      final ok = group.where((q) => q.picked == q.answer).length;
      if (ok / group.length >= 0.6) {
        lvl = l;
      } else {
        break;
      }
    }
    final first = s.placement.isEmpty;
    s.placement = lvl;
    s.saveExtra();
    if (first) s.addCoins(10);
    Sfx.play('win');
    setState(() {
      result = lvl;
      phase = 3;
    });
  }

  Future<void> _suggest() async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    setState(() => busy = true);
    try {
      final tp = topic.text.trim();
      final r = await Ai.chat(
        'Suggest 15 useful ${langOf(s.frontLang).en} words for a learner at CEFR level $result'
        '${tp.isEmpty ? '' : ' on the topic "$tp"'}. For each give the word and its ${langOf(s.backLang).en} translation. '
        'Output ONLY a JSON array like [{"word":"...","translation":"..."}].',
        maxTokens: 900,
        temp: 0.7,
      );
      final out = <_Sug>[];
      for (final e in Ai.jsonList(r)) {
        if (e is! Map) continue;
        final w = (e['word'] ?? '').toString().trim();
        final tr = (e['translation'] ?? '').toString().trim();
        if (w.isNotEmpty && tr.isNotEmpty) out.add(_Sug(w, tr));
      }
      if (mounted) setState(() => sugs = out);
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _addSugs() async {
    final list = [
      for (final x in sugs)
        if (x.on) CardItem(id: s.newId(), front: x.word, back: x.translation),
    ];
    if (list.isEmpty) return;
    await s.addCards(list);
    Sfx.play('win');
    if (mounted) {
      toast(context, '${t('cards_added')}: ${list.length}');
      setState(() => sugs = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(title: t('placement'), child: _content());
  }

  Widget _content() {
    switch (phase) {
      case 1:
        return Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const PixelLoader(),
              const SizedBox(height: 12),
              tx(t('building_test'), bold: true),
            ],
          ),
        );
      case 2:
        return _quiz();
      case 3:
        return _result();
      default:
        return ListView(
          padding: const EdgeInsets.all(14),
          children: [
            infoBox(t('placement_help')),
            if (s.placement.isNotEmpty) ...[
              const SizedBox(height: 10),
              tx('${t('your_level')}: ${s.placement}', bold: true, size: 15),
            ],
            const SizedBox(height: 16),
            PixelButton(label: t('start'), icon: 'trophy', expand: true, onTap: _start),
          ],
        );
    }
  }

  Widget _quiz() {
    final q = qs[i];
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(children: [
          Expanded(child: PixelBar(value: i / qs.length, segs: 20, height: 10)),
          const SizedBox(width: 10),
          tx('${i + 1} / ${qs.length}', bold: true, color: C.gray),
        ]),
        const SizedBox(height: 14),
        PixelBox(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: Directionality(
              textDirection: s.frontLang.startsWith('ar') ? TextDirection.rtl : TextDirection.ltr,
              child: Text(q.q,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, height: 1.5)),
            ),
          ),
        ),
        const SizedBox(height: 12),
        for (int k = 0; k < q.options.length; k++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _pick(k),
              child: PixelBox(
                color: q.picked == null ? C.white : (k == q.picked ? C.ink : C.white),
                padding: const EdgeInsets.all(13),
                child: SizedBox(
                  width: double.infinity,
                  child: Text(q.options[k],
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: q.picked != null && k == q.picked ? C.cream : C.ink)),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _result() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const SizedBox(height: 8),
        const Center(child: Sprite('trophy', px: 8)),
        const SizedBox(height: 10),
        Center(child: tx(t('your_level'), bold: true, color: C.gray)),
        Center(child: Text(result, style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w900))),
        const SizedBox(height: 6),
        for (final l in kLevels)
          Builder(builder: (context) {
            final g = qs.where((q) => q.level == l).toList();
            if (g.isEmpty) return const SizedBox.shrink();
            final ok = g.where((q) => q.picked == q.answer).length;
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(children: [
                SizedBox(width: 34, child: tx(l, bold: true)),
                Expanded(child: PixelBar(value: ok / g.length, segs: 8, height: 10)),
                const SizedBox(width: 8),
                tx('$ok/${g.length}', size: 13, bold: true, color: C.gray),
              ]),
            );
          }),
        PixelTitle(t('suggest_words')),
        PixelField(controller: topic, hint: t('topic_optional')),
        const SizedBox(height: 10),
        PixelButton(
          label: t('suggest_words'),
          icon: 'sparkle',
          expand: true,
          busy: busy,
          onTap: _suggest,
        ),
        if (sugs.isNotEmpty) ...[
          const SizedBox(height: 10),
          for (final x in sugs)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: pixelCheck(x.on, '${x.word}  →  ${x.translation}', () => setState(() => x.on = !x.on)),
            ),
          const SizedBox(height: 8),
          PixelButton(
            label: '${t('create_cards')} (${sugs.where((x) => x.on).length})',
            icon: 'create',
            expand: true,
            onTap: _addSugs,
          ),
        ],
        const SizedBox(height: 10),
        PixelButton(label: t('retry'), filled: false, expand: true, onTap: _start),
      ],
    );
  }
}
