import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'cards_tab.dart';
import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Hands-free mode: reads cards aloud, word then translation, in a loop.
class ListenModeScreen extends StatefulWidget {
  const ListenModeScreen({super.key});
  @override
  State<ListenModeScreen> createState() => _ListenModeScreenState();
}

class _ListenModeScreenState extends State<ListenModeScreen> {
  final FlutterTts _tts = FlutterTts();
  late List<CardItem> list;
  int idx = 0;
  bool playing = false;
  bool showBack = false;
  int gapSec = 2;
  bool dueOnly = false;
  int _token = 0;

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _load();
    _tts.awaitSpeakCompletion(true);
  }

  @override
  void dispose() {
    _token++;
    _tts.stop();
    super.dispose();
  }

  void _load() {
    var l = List<CardItem>.of(s.scope);
    if (dueOnly) {
      final d = l.where((c) => c.isDue).toList();
      if (d.isNotEmpty) l = d;
    }
    l.shuffle();
    list = l;
    idx = 0;
  }

  Future<void> _say(String text, String lang) async {
    try {
      await _tts.setLanguage(lang);
      await _tts.setSpeechRate(s.speechRate);
      await _tts.speak(text.replaceAll(RegExp(r'[*_#`$]'), ' '));
    } catch (_) {}
  }

  Future<void> _run() async {
    final my = ++_token;
    await Speech.stop();
    bool alive() => mounted && playing && my == _token;
    while (alive()) {
      final c = list[idx];
      setState(() => showBack = false);
      await _say(c.front, s.frontLang);
      if (!alive()) break;
      await Future<void>.delayed(Duration(seconds: gapSec));
      if (!alive()) break;
      setState(() => showBack = true);
      await _say(c.back, s.backLang);
      if (!alive()) break;
      await Future<void>.delayed(Duration(seconds: gapSec));
      if (!alive()) break;
      setState(() => idx = (idx + 1) % list.length);
    }
  }

  void _toggle() {
    if (playing) {
      _token++;
      _tts.stop();
      setState(() => playing = false);
    } else {
      setState(() => playing = true);
      _run();
    }
  }

  void _skip(int d) {
    final was = playing;
    _token++;
    _tts.stop();
    setState(() {
      idx = (idx + d) % list.length;
      if (idx < 0) idx += list.length;
      showBack = false;
      playing = was;
    });
    if (was) _run();
  }

  @override
  Widget build(BuildContext context) {
    if (list.isEmpty) {
      return PixelPage(title: t('listen_mode'), child: Center(child: tx(t('no_cards'))));
    }
    final c = list[idx];
    return PixelPage(
      title: t('listen_mode'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('listen_help')),
          const SizedBox(height: 12),
          PixelChips<bool>(
            options: [(false, t('all_cards')), (true, t('due_only'))],
            value: dueOnly,
            onChanged: (v) {
              _token++;
              _tts.stop();
              setState(() {
                dueOnly = v;
                playing = false;
                _load();
              });
            },
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              tx(t('pause_between'), size: 13, color: C.dark),
              const SizedBox(width: 10),
              Expanded(
                child: PixelChips<int>(
                  options: const [(1, '1s'), (2, '2s'), (4, '4s')],
                  value: gapSec,
                  onChanged: (v) => setState(() => gapSec = v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          tx('${idx + 1} / ${list.length}', bold: true, color: C.gray),
          const SizedBox(height: 8),
          PixelBox(
            padding: const EdgeInsets.all(20),
            child: SizedBox(
              width: double.infinity,
              child: Column(
                children: [
                  if (c.image != null) ...[cardImage(c.image, 90), const SizedBox(height: 10)],
                  Text(c.front,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  Opacity(
                    opacity: showBack ? 1 : 0.15,
                    child: Text(c.back,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: C.dark)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: PixelButton(label: t('prev'), filled: false, expand: true, onTap: () => _skip(-1))),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: PixelButton(
                  label: playing ? t('pause') : t('start'),
                  icon: playing ? null : 'headphones',
                  expand: true,
                  onTap: _toggle,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(child: PixelButton(label: t('next'), filled: false, expand: true, onTap: () => _skip(1))),
            ],
          ),
        ],
      ),
    );
  }
}
