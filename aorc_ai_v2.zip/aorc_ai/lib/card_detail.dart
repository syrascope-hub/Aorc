import 'package:flutter/material.dart';

import 'cards_tab.dart';
import 'common.dart';
import 'rich.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// AI helper sheet for a single card: explain, mnemonic, examples, image, deck.
Future<void> showCardAi(BuildContext context, CardItem card) {
  return showDialog<void>(
    context: context,
    builder: (_) => _CardAiDialog(card),
  );
}

class _CardAiDialog extends StatefulWidget {
  final CardItem card;
  const _CardAiDialog(this.card);
  @override
  State<_CardAiDialog> createState() => _CardAiDialogState();
}

class _CardAiDialogState extends State<_CardAiDialog> {
  String? text;
  String? kind;
  String? busy;
  AppState get s => AppState.I;
  CardItem get c => widget.card;

  String get _ui => s.uiLang == 'ar' ? 'Arabic' : 'English';
  String get _front => langOf(s.frontLang).en;
  String get _back => langOf(s.backLang).en;

  Future<void> _run(String k) async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    setState(() => busy = k);
    try {
      switch (k) {
        case 'explain':
          text = await Ai.chat(
            'Explain the $_front word or phrase "${c.front}" (meaning: ${c.back}) to a learner. '
            'Give: part of speech, a short clear meaning, 3 synonyms, 2 example sentences each with a '
            '$_back translation, and one usage tip. Be concise. Write the explanations in $_ui.',
            system: 'You are a friendly language teacher.',
            maxTokens: 700,
          );
          kind = 'explain';
          break;
        case 'mnemonic':
          final m = await Ai.chat(
            'Create a short, vivid, memorable mnemonic to remember that the $_front word "${c.front}" '
            'means "${c.back}". Use a sound-alike in $_back or a funny mental image. '
            '2 or 3 sentences, written in $_back. Output only the mnemonic.',
            system: 'You are a creative memory coach.',
            maxTokens: 250,
            temp: 0.9,
          );
          c.mnemonic = m.trim();
          await s.saveCards();
          text = c.mnemonic;
          kind = 'mnemonic';
          break;
        case 'examples':
          text = await Ai.chat(
            'Write 3 new simple example sentences in $_front that use "${c.front}". '
            'Put the $_back translation on the next line after each sentence. Output only the sentences.',
            maxTokens: 350,
          );
          kind = 'examples';
          break;
        case 'image':
          final subject = (c.mnemonic ?? '').isNotEmpty ? '${c.front}: ${clip(c.mnemonic!, 120)}' : c.front;
          final bytes = await Ai.image(Ai.pixelPrompt(subject));
          c.image = await s.saveImage(c.id, bytes);
          await s.saveCards();
          kind = 'image';
          text = null;
          break;
      }
      Sfx.play('ok');
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = null);
    }
  }

  Widget _btn(String k, String icon, String label) => PixelButton(
        label: label,
        icon: icon,
        small: true,
        filled: false,
        busy: busy == k,
        onTap: busy == null ? () => _run(k) : null,
      );

  @override
  Widget build(BuildContext context) {
    final shownText = text ?? ((c.mnemonic ?? '').isNotEmpty && kind == null ? c.mnemonic : null);
    return Dialog(
      backgroundColor: C.cream,
      insetPadding: const EdgeInsets.all(14),
      shape: const RoundedRectangleBorder(side: BorderSide(color: C.ink, width: 3)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (c.image != null) ...[cardImage(c.image, 44), const SizedBox(width: 10)],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        tx(c.front, size: 20, bold: true),
                        tx(c.back, size: 14, color: C.dark),
                      ],
                    ),
                  ),
                  if (c.isLeech) const Sprite('skull', px: 3),
                ],
              ),
              if (c.isLeech) ...[
                const SizedBox(height: 8),
                tx(t('leech_note'), size: 12.5, color: C.dark, height: 1.4),
              ],
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _btn('explain', 'sparkle', t('ai_explain')),
                  _btn('mnemonic', 'bulb', t('ai_mnemonic')),
                  _btn('examples', 'create', t('ai_examples')),
                  _btn('image', 'camera', t('ai_mnemonic_img')),
                ],
              ),
              if (shownText != null && shownText.isNotEmpty) ...[
                const SizedBox(height: 12),
                PixelBox(
                  padding: const EdgeInsets.all(12),
                  child: SizedBox(
                    width: double.infinity,
                    child: Directionality(
                      textDirection: (kind == 'mnemonic' || kind == null) && s.backLang.startsWith('ar')
                          ? TextDirection.rtl
                          : (s.uiLang == 'ar' && kind == 'explain' ? TextDirection.rtl : TextDirection.ltr),
                      child: RichMath(shownText, size: 14.5),
                    ),
                  ),
                ),
                if (kind == 'examples') ...[
                  const SizedBox(height: 8),
                  PixelButton(
                    label: t('save_as_example'),
                    small: true,
                    filled: false,
                    onTap: () async {
                      c.example = text!.split('\n').where((l) => l.trim().isNotEmpty).first.trim();
                      await s.saveCards();
                      if (mounted) toast(context, t('saved'));
                    },
                  ),
                ],
              ],
              const SizedBox(height: 12),
              tx(t('move_to_deck'), size: 12.5, color: C.dark),
              const SizedBox(height: 6),
              PixelChips<String>(
                options: [for (final d in s.decks) (d.id, deckLabel(d))],
                value: c.deckId,
                onChanged: (v) async {
                  c.deckId = v;
                  await s.saveCards();
                  if (mounted) setState(() {});
                },
              ),
              const SizedBox(height: 14),
              PixelButton(
                label: t('close'),
                filled: false,
                expand: true,
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
