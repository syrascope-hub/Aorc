import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'common.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

// ───────────────────────── generic multiple-choice engine ─────────────────────────

enum McqMode { survival, speed, boss, fixed }

class McqResult {
  final int score, total, maxCombo, seconds;
  final bool won;
  const McqResult(this.score, this.total, this.maxCombo, this.seconds, this.won);
}

class McqEngine extends StatefulWidget {
  final McqMode mode;
  final List<CardItem> pool;
  final String title;
  final int total; // fixed mode: number of questions
  final int bossHp;
  final String bossSprite;
  final String bossName;

  /// Called once when the game ends; may return an extra line to display.
  final String? Function(McqResult) onDone;

  const McqEngine({
    super.key,
    required this.mode,
    required this.pool,
    required this.title,
    required this.onDone,
    this.total = 10,
    this.bossHp = 10,
    this.bossSprite = 'skull',
    this.bossName = '',
  });

  @override
  State<McqEngine> createState() => _McqEngineState();
}

class _McqEngineState extends State<McqEngine> {
  final _r = Random();
  late List<CardItem> order;
  int idx = 0, score = 0, lives = 3, combo = 0, maxCombo = 0, hp = 0, answered = 0;
  bool fwd = true, over = false, won = false;
  late List<String> options;
  late String correct, prompt;
  String? picked;
  double left = 10, qTime = 10, globalLeft = 60;
  Timer? _tick;
  String? extra;
  final Stopwatch _sw = Stopwatch();

  AppState get s => AppState.I;

  bool get _timed => widget.mode == McqMode.survival || widget.mode == McqMode.boss;
  bool get _lives => widget.mode == McqMode.survival || widget.mode == McqMode.boss;

  @override
  void initState() {
    super.initState();
    _begin();
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  void _begin() {
    order = List<CardItem>.of(widget.pool)..shuffle();
    idx = 0;
    score = 0;
    lives = 3;
    combo = 0;
    maxCombo = 0;
    answered = 0;
    hp = widget.bossHp;
    globalLeft = 60;
    over = false;
    won = false;
    extra = null;
    _sw
      ..reset()
      ..start();
    _make();
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(milliseconds: 100), (_) {
      if (!mounted || over) return;
      bool end = false, timeout = false;
      setState(() {
        if (widget.mode == McqMode.speed) {
          globalLeft -= 0.1;
          if (globalLeft <= 0) {
            globalLeft = 0;
            end = true;
          }
        } else if (_timed && picked == null) {
          left -= 0.1;
          if (left <= 0) {
            left = 0;
            timeout = true;
          }
        }
      });
      if (end) {
        _finish();
      } else if (timeout) {
        _answer(null);
      }
    });
  }

  int get _optionCount {
    if (widget.mode == McqMode.survival) {
      return score < 5 ? 3 : (score < 12 ? 4 : 5);
    }
    return 4;
  }

  void _make() {
    if (idx > 0 && idx % order.length == 0) order.shuffle();
    final c = order[idx % order.length];
    fwd = _r.nextBool();
    correct = fwd ? c.back : c.front;
    prompt = fwd ? c.front : c.back;
    final others = widget.pool
        .where((x) => x.id != c.id)
        .map((x) => fwd ? x.back : x.front)
        .where((x) => x != correct)
        .toSet()
        .toList()
      ..shuffle();
    options = [correct, ...others.take(_optionCount - 1)]..shuffle();
    picked = null;
    qTime = widget.mode == McqMode.survival ? max(4.0, 12 - score * 0.25) : 10;
    left = qTime;
  }

  void _answer(String? o) {
    if (picked != null || over) return;
    final ok = o != null && o == correct;
    setState(() {
      picked = o ?? '\u0000timeout';
      answered++;
      if (ok) {
        score++;
        combo++;
        maxCombo = max(maxCombo, combo);
        if (widget.mode == McqMode.boss) hp -= combo >= 3 ? 2 : 1;
      } else {
        combo = 0;
        if (_lives) lives--;
        if (widget.mode == McqMode.speed) globalLeft = max(0.5, globalLeft - 2);
      }
    });
    Sfx.play(ok ? 'ok' : 'bad');
    final wait = widget.mode == McqMode.speed ? 350 : 1000;
    Future.delayed(Duration(milliseconds: wait), () {
      if (!mounted || over) return;
      final end = (_lives && lives <= 0) ||
          (widget.mode == McqMode.boss && hp <= 0) ||
          (widget.mode == McqMode.fixed && answered >= widget.total);
      if (end) {
        _finish();
      } else {
        setState(() {
          idx++;
          _make();
        });
      }
    });
  }

  void _finish() {
    if (over) return;
    _tick?.cancel();
    _sw.stop();
    final w = widget.mode == McqMode.boss ? hp <= 0 : true;
    final res = McqResult(score, answered, maxCombo, _sw.elapsed.inSeconds, w);
    s.bumpMax('combo', maxCombo);
    String? line;
    try {
      line = widget.onDone(res);
    } catch (_) {}
    Sfx.play(w ? 'win' : 'bad');
    setState(() {
      over = true;
      won = w;
      extra = line;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: widget.title,
      child: over ? _result() : _body(),
    );
  }

  Widget _result() {
    final bossLost = widget.mode == McqMode.boss && !won;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Sprite(widget.mode == McqMode.boss ? (won ? 'trophy' : widget.bossSprite) : 'robot', px: 8),
            const SizedBox(height: 16),
            tx(widget.mode == McqMode.boss ? (won ? t('boss_won') : t('boss_lost')) : t('game_over'),
                size: 22, bold: true),
            const SizedBox(height: 8),
            tx(
              widget.mode == McqMode.fixed
                  ? '${t('score')}: $score / ${widget.total}'
                  : '${t('score')}: $score',
              size: 18,
              bold: true,
            ),
            const SizedBox(height: 4),
            tx('${t('best_combo')}: x$maxCombo', size: 14, color: C.gray, bold: true),
            if (extra != null) ...[
              const SizedBox(height: 10),
              tx(extra!, size: 14, bold: true, align: TextAlign.center, height: 1.5),
            ],
            const SizedBox(height: 20),
            if (widget.mode != McqMode.fixed)
              PixelButton(
                label: bossLost ? t('retry') : t('play_again'),
                icon: 'games',
                onTap: () => setState(_begin),
              ),
            const SizedBox(height: 10),
            PixelButton(
              label: t('back'),
              filled: false,
              onTap: () => Navigator.of(context).maybePop(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hearts() => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (int i = 0; i < 3; i++)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Sprite('heart', px: 3, tint: i < lives ? C.ink : C.light),
            ),
        ],
      );

  Widget _body() {
    final timeFrac = widget.mode == McqMode.speed
        ? globalLeft / 60
        : (_timed ? left / qTime : 1.0);
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
      children: [
        Row(
          children: [
            if (_lives) _hearts(),
            if (_lives) const SizedBox(width: 10),
            tx('${t('score')}: $score', bold: true, size: 15),
            const Spacer(),
            if (combo >= 2) tx('x$combo', bold: true, size: 16),
            if (widget.mode == McqMode.speed)
              tx('${globalLeft.ceil()}s', bold: true, size: 16),
            if (widget.mode == McqMode.fixed)
              tx('${min(answered + 1, widget.total)} / ${widget.total}', bold: true, color: C.gray),
          ],
        ),
        const SizedBox(height: 8),
        if (widget.mode == McqMode.boss) ...[
          Row(
            children: [
              Sprite(widget.bossSprite, px: 4),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    tx(widget.bossName, bold: true, size: 14),
                    const SizedBox(height: 4),
                    PixelBar(value: max(0, hp) / widget.bossHp, segs: 14, height: 12),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        if (widget.mode != McqMode.fixed) PixelBar(value: timeFrac, segs: 20, height: 8),
        const SizedBox(height: 14),
        PixelBox(
          padding: const EdgeInsets.all(18),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                tx(fwd ? t('pick_translation') : t('pick_word'), size: 12, color: C.gray, bold: true),
                const SizedBox(height: 8),
                Text(prompt,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, height: 1.25)),
                if (fwd) ...[
                  const SizedBox(height: 10),
                  SpeakBtn(prompt, s.frontLang),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        for (final o in options) _option(o),
      ],
    );
  }

  Widget _option(String o) {
    final answeredNow = picked != null;
    final isCorrect = o == correct;
    final isPicked = o == picked;
    Color bg = C.white;
    Color fg = C.ink;
    if (answeredNow && isCorrect) {
      bg = C.ink;
      fg = C.cream;
    } else if (answeredNow && isPicked) {
      bg = C.light;
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _answer(o),
        child: PixelBox(
          color: bg,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: SizedBox(
            width: double.infinity,
            child: Text(o,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: fg)),
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── wrappers ─────────────────────────

class SurvivalGame extends StatelessWidget {
  const SurvivalGame({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return McqEngine(
      mode: McqMode.survival,
      pool: s.scope,
      title: t('g_survival'),
      onDone: (r) {
        final prev = s.stat['survival_best'] ?? 0;
        final coins = r.score ~/ 2;
        s.bumpMax('survival_best', r.score);
        s.bump('games');
        if (coins > 0) s.addCoins(coins);
        return '${r.score > prev ? '${t('new_record')}\n' : ''}${t('best')}: ${max(prev, r.score)} · +$coins ${t('coins')}';
      },
    );
  }
}

class SpeedGame extends StatelessWidget {
  const SpeedGame({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return McqEngine(
      mode: McqMode.speed,
      pool: s.scope,
      title: t('g_speed'),
      onDone: (r) {
        final prev = s.stat['speed_best'] ?? 0;
        final coins = r.score ~/ 3;
        s.bumpMax('speed_best', r.score);
        s.bump('games');
        if (coins > 0) s.addCoins(coins);
        return '${r.score > prev ? '${t('new_record')}\n' : ''}${t('best')}: ${max(prev, r.score)} · +$coins ${t('coins')}';
      },
    );
  }
}

const List<String> kBossSprites = ['skull', 'ghost', 'alien', 'cat', 'crown'];

class BossGame extends StatelessWidget {
  const BossGame({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final level = (s.stat['boss'] ?? 0) + 1;
    final hp = min(40, 8 + 3 * level);
    return McqEngine(
      mode: McqMode.boss,
      pool: s.scope,
      title: t('g_boss'),
      bossHp: hp,
      bossSprite: kBossSprites[(level - 1) % kBossSprites.length],
      bossName: '${t('boss')} Lv.$level',
      onDone: (r) {
        s.bump('games');
        if (r.won) {
          final coins = 15 + 5 * level;
          s.bump('boss');
          s.addCoins(coins);
          return '+$coins ${t('coins')}';
        }
        return null;
      },
    );
  }
}

// ───────────────────────── scramble ─────────────────────────

class ScrambleGame extends StatefulWidget {
  const ScrambleGame({super.key});
  @override
  State<ScrambleGame> createState() => _ScrambleGameState();
}

class _ScrambleGameState extends State<ScrambleGame> {
  final _r = Random();
  late List<CardItem> order;
  int i = 0, score = 0;
  bool over = false, revealed = false, wrong = false;
  late String target;
  late List<String> tiles;
  List<int> used = [];
  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    var pool = s.scope.where((c) {
      final f = c.front.replaceAll(' ', '');
      return f.length >= 3 && f.length <= 14;
    }).toList();
    if (pool.isEmpty) pool = List<CardItem>.of(s.scope);
    pool.shuffle();
    order = pool.take(8).toList();
    i = 0;
    score = 0;
    over = false;
    _make();
  }

  void _make() {
    final c = order[i];
    target = c.front.replaceAll(' ', '');
    final chars = target.split('');
    var mixed = List<String>.of(chars);
    for (int k = 0; k < 6; k++) {
      mixed = List<String>.of(chars)..shuffle(_r);
      if (mixed.join() != target) break;
    }
    tiles = mixed;
    used = [];
    revealed = false;
    wrong = false;
  }

  String get _answer => used.map((k) => tiles[k]).join();

  void _tap(int k) {
    if (revealed || used.contains(k)) return;
    Sfx.play('tap');
    setState(() {
      used.add(k);
      wrong = false;
    });
    if (used.length == tiles.length) {
      final ok = normText(_answer) == normText(target);
      if (ok) {
        Sfx.play('ok');
        score++;
        Future.delayed(const Duration(milliseconds: 700), _next);
      } else {
        Sfx.play('bad');
        setState(() => wrong = true);
      }
    }
  }

  void _next() {
    if (!mounted) return;
    setState(() {
      if (i + 1 >= order.length) {
        over = true;
        final coins = score;
        s.bump('games');
        if (coins > 0) s.addCoins(coins);
        Sfx.play('win');
      } else {
        i++;
        _make();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('g_scramble'),
      child: over
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Sprite('dice', px: 8),
                    const SizedBox(height: 16),
                    tx(t('game_over'), size: 22, bold: true),
                    const SizedBox(height: 8),
                    tx('${t('score')}: $score / ${order.length} · +$score ${t('coins')}',
                        size: 17, bold: true, align: TextAlign.center),
                    const SizedBox(height: 20),
                    PixelButton(
                        label: t('play_again'), icon: 'games', onTap: () => setState(_start)),
                    const SizedBox(height: 10),
                    PixelButton(
                        label: t('back'),
                        filled: false,
                        onTap: () => Navigator.of(context).maybePop()),
                  ],
                ),
              ),
            )
          : _body(),
    );
  }

  Widget _body() {
    final c = order[i];
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
      children: [
        Row(children: [
          tx('${i + 1} / ${order.length}', bold: true, color: C.gray),
          const Spacer(),
          tx('${t('score')}: $score', bold: true),
        ]),
        const SizedBox(height: 12),
        PixelBox(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                tx(t('unscramble'), size: 12, color: C.gray, bold: true),
                const SizedBox(height: 8),
                Text(c.back,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                SpeakBtn(c.front, s.frontLang),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 6,
          runSpacing: 6,
          children: [
            for (int k = 0; k < tiles.length; k++)
              PixelBox(
                u: 2,
                shadow: false,
                color: revealed ? C.ink : (wrong ? C.light : C.white),
                padding: const EdgeInsets.all(0),
                child: SizedBox(
                  width: 34,
                  height: 40,
                  child: Center(
                    child: Text(
                      revealed
                          ? target[k]
                          : (k < used.length ? tiles[used[k]] : ''),
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: revealed ? C.cream : C.ink),
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: [
            for (int k = 0; k < tiles.length; k++)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _tap(k),
                child: Opacity(
                  opacity: used.contains(k) ? 0.25 : 1,
                  child: PixelBox(
                    color: C.cream,
                    padding: EdgeInsets.zero,
                    child: SizedBox(
                      width: 38,
                      height: 42,
                      child: Center(
                        child: Text(tiles[k],
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(
              child: PixelButton(
                label: t('undo'),
                filled: false,
                onTap: used.isEmpty || revealed
                    ? null
                    : () => setState(() {
                          used.removeLast();
                          wrong = false;
                        }),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PixelButton(
                label: revealed ? t('next') : t('show_answer'),
                onTap: () {
                  if (revealed) {
                    _next();
                  } else {
                    setState(() => revealed = true);
                  }
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ───────────────────────── cloze ─────────────────────────

class ClozeGame extends StatefulWidget {
  const ClozeGame({super.key});
  @override
  State<ClozeGame> createState() => _ClozeGameState();
}

class _ClozeGameState extends State<ClozeGame> {
  final _r = Random();
  late List<CardItem> order;
  int i = 0, score = 0;
  bool over = false, busy = false;
  late String sentence;
  late List<String> options;
  String? picked;
  AppState get s => AppState.I;

  RegExp _re(String front) =>
      RegExp(RegExp.escape(front), caseSensitive: false, unicode: true);

  List<CardItem> _eligible() => s.scope
      .where((c) => (c.example ?? '').isNotEmpty && _re(c.front).hasMatch(c.example!))
      .toList();

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    final el = _eligible()..shuffle();
    order = el.take(10).toList();
    i = 0;
    score = 0;
    over = false;
    if (order.length >= 3) _make();
  }

  void _make() {
    final c = order[i];
    sentence = c.example!.replaceFirst(_re(c.front), '_____');
    final others = s.scope
        .where((x) => x.id != c.id && x.front != c.front)
        .map((x) => x.front)
        .toSet()
        .toList()
      ..shuffle(_r);
    options = [c.front, ...others.take(3)]..shuffle(_r);
    picked = null;
  }

  void _pick(String o) {
    if (picked != null) return;
    final ok = o == order[i].front;
    setState(() {
      picked = o;
      if (ok) score++;
    });
    Sfx.play(ok ? 'ok' : 'bad');
    Future.delayed(const Duration(milliseconds: 1100), () {
      if (!mounted) return;
      setState(() {
        if (i + 1 >= order.length) {
          over = true;
          s.bump('games');
          if (score > 0) s.addCoins(score);
          Sfx.play('win');
        } else {
          i++;
          _make();
        }
      });
    });
  }

  Future<void> _generate() async {
    final need = s.scope.where((c) => (c.example ?? '').isEmpty).take(12).toList();
    if (need.isEmpty) return;
    setState(() => busy = true);
    try {
      final reply = await Ai.chat(
        'For each word below write one simple natural sentence in ${langOf(s.frontLang).en} '
        'that contains the word exactly as written. Output only a JSON array like '
        '[{"w":"word","s":"sentence"}].\n\nWords: ${need.map((c) => c.front).join(', ')}',
        system: 'You write clear example sentences for language learners.',
        maxTokens: 1500,
        temp: 0.5,
      );
      final list = Ai.jsonList(reply);
      int n = 0;
      for (final e in list) {
        if (e is! Map) continue;
        final w = (e['w'] ?? '').toString().trim();
        final sen = (e['s'] ?? '').toString().trim();
        for (final c in need) {
          if (c.front.toLowerCase() == w.toLowerCase() && _re(c.front).hasMatch(sen)) {
            c.example = sen;
            n++;
          }
        }
      }
      await s.saveCards();
      if (mounted) {
        toast(context, '${t('examples_added')}: $n');
        setState(_start);
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('g_cloze'),
      child: order.length < 3
          ? _needExamples()
          : (over ? _done() : _body()),
    );
  }

  Widget _needExamples() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('summary', px: 8),
            const SizedBox(height: 16),
            tx(t('cloze_need'), size: 15, bold: true, align: TextAlign.center, height: 1.5),
            const SizedBox(height: 16),
            PixelButton(
              label: t('gen_examples'),
              icon: 'sparkle',
              busy: busy,
              onTap: s.hfToken.trim().isEmpty
                  ? () => toast(context, t('need_token'))
                  : _generate,
            ),
          ],
        ),
      ),
    );
  }

  Widget _done() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('robot', px: 8),
            const SizedBox(height: 16),
            tx(t('game_over'), size: 22, bold: true),
            const SizedBox(height: 8),
            tx('${t('score')}: $score / ${order.length} · +$score ${t('coins')}',
                size: 17, bold: true, align: TextAlign.center),
            const SizedBox(height: 20),
            PixelButton(label: t('play_again'), icon: 'games', onTap: () => setState(_start)),
            const SizedBox(height: 10),
            PixelButton(
                label: t('back'), filled: false, onTap: () => Navigator.of(context).maybePop()),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    final c = order[i];
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
      children: [
        Row(children: [
          tx('${i + 1} / ${order.length}', bold: true, color: C.gray),
          const Spacer(),
          tx('${t('score')}: $score', bold: true),
        ]),
        const SizedBox(height: 12),
        PixelBox(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                tx(t('fill_blank'), size: 12, color: C.gray, bold: true),
                const SizedBox(height: 8),
                Directionality(
                  textDirection: s.frontLang.startsWith('ar') ? TextDirection.rtl : TextDirection.ltr,
                  child: Text(sentence,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, height: 1.5)),
                ),
                const SizedBox(height: 8),
                tx(c.back, size: 14, color: C.dark, align: TextAlign.center),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        for (final o in options)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _pick(o),
              child: PixelBox(
                color: picked != null && o == c.front
                    ? C.ink
                    : (picked == o ? C.light : C.white),
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
                child: SizedBox(
                  width: double.infinity,
                  child: Text(o,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: picked != null && o == c.front ? C.cream : C.ink)),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
