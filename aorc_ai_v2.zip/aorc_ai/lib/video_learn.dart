import 'package:flutter/material.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class _Line {
  final int sec;
  final String text;
  _Line(this.sec, this.text);
}

class _Vocab {
  final String word, translation;
  bool on = true;
  _Vocab(this.word, this.translation);
}

/// Learn from a YouTube video's captions: tap words to save them, get vocabulary and a quiz.
class VideoLearnScreen extends StatefulWidget {
  const VideoLearnScreen({super.key});
  @override
  State<VideoLearnScreen> createState() => _VideoLearnScreenState();
}

class _VideoLearnScreenState extends State<VideoLearnScreen> {
  final link = TextEditingController();
  bool busy = false;
  bool vocabBusy = false;
  String title = '';
  List<_Line> lines = [];
  List<_Vocab> vocab = [];

  AppState get s => AppState.I;

  @override
  void dispose() {
    link.dispose();
    super.dispose();
  }

  String? _ytId(String u) {
    final m = RegExp(r'(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})').firstMatch(u);
    return m?.group(1);
  }

  String get _fullText => lines.map((l) => l.text).join(' ');

  Future<void> _load() async {
    final id = _ytId(link.text.trim());
    if (id == null) {
      toast(context, t('bad_link'));
      return;
    }
    setState(() {
      busy = true;
      lines = [];
      vocab = [];
    });
    final yt = YoutubeExplode();
    try {
      final video = await yt.videos.get(id);
      final manifest = await yt.videos.closedCaptions.getManifest(id);
      if (manifest.tracks.isEmpty) throw AiError(t('no_captions'));
      final want = s.frontLang.split('-').first;
      var track = manifest.tracks.first;
      for (final tr in manifest.tracks) {
        if (tr.language.code.toLowerCase().startsWith(want)) {
          track = tr;
          break;
        }
      }
      final cc = await yt.videos.closedCaptions.get(track);
      final out = <_Line>[];
      var buf = <String>[];
      int start = 0;
      for (final c in cc.captions) {
        final txt = c.text.replaceAll('\n', ' ').trim();
        if (txt.isEmpty) continue;
        if (buf.isEmpty) start = c.offset.inSeconds;
        buf.add(txt);
        if (buf.join(' ').split(' ').length >= 7) {
          out.add(_Line(start, buf.join(' ')));
          buf = <String>[];
        }
      }
      if (buf.isNotEmpty) out.add(_Line(start, buf.join(' ')));
      if (out.isEmpty) throw AiError(t('no_captions'));
      if (mounted) {
        setState(() {
          title = video.title;
          lines = out.take(300).toList();
        });
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      yt.close();
      if (mounted) setState(() => busy = false);
    }
  }

  String _clock(int sec) =>
      '${(sec ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}';

  void _openLine(_Line l) {
    Speech.speak(l.text, s.frontLang);
    final words = l.text
        .split(RegExp(r'\s+'))
        .map((w) => w.replaceAll(RegExp(r'^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$', unicode: true), ''))
        .where((w) => w.isNotEmpty)
        .toList();
    showPixelDialog(
      context,
      t('tap_word'),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          tx(l.text, size: 15, height: 1.5),
          const SizedBox(height: 12),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final w in words)
                GestureDetector(
                  onTap: () => _word(w, l.text),
                  child: PixelBox(
                    u: 2,
                    shadow: false,
                    color: C.creamDeep,
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    child: tx(w, size: 14, bold: true),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _word(String w, String context0) async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    Speech.speak(w, s.frontLang);
    try {
      final r = await Ai.translateLines([w],
          from: langOf(s.frontLang).en, to: langOf(s.backLang).en);
      final tr = r.isEmpty ? '' : r.first;
      if (!mounted || tr.isEmpty) return;
      final add = await confirmDialog(context, '$w  →  $tr\n\n${t('add_card')}?');
      if (add) {
        await s.addCard(CardItem(id: s.newId(), front: w, back: tr, example: context0));
        if (mounted) toast(context, t('word_added'));
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    }
  }

  Future<void> _vocab() async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    setState(() => vocabBusy = true);
    try {
      final r = await Ai.chat(
        'From this transcript pick the 12 most useful vocabulary words or short phrases for a learner '
        '(skip names and very easy words). Give each in ${langOf(s.frontLang).en} and translate it to '
        '${langOf(s.backLang).en}. Output ONLY a JSON array like [{"word":"...","translation":"..."}].\n\n'
        'Transcript:\n${clip(_fullText, 9000)}',
        maxTokens: 900,
        temp: 0.3,
      );
      final out = <_Vocab>[];
      for (final e in Ai.jsonList(r)) {
        if (e is! Map) continue;
        final w = (e['word'] ?? '').toString().trim();
        final tr = (e['translation'] ?? '').toString().trim();
        if (w.isNotEmpty && tr.isNotEmpty) out.add(_Vocab(w, tr));
      }
      if (mounted) setState(() => vocab = out);
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => vocabBusy = false);
    }
  }

  Future<void> _addVocab() async {
    final list = [
      for (final v in vocab)
        if (v.on) CardItem(id: s.newId(), front: v.word, back: v.translation),
    ];
    if (list.isEmpty) return;
    await s.addCards(list);
    Sfx.play('win');
    if (mounted) {
      toast(context, '${t('cards_added')}: ${list.length}');
      setState(() => vocab = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('video_learn'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('video_help')),
          const SizedBox(height: 12),
          PixelField(controller: link, hint: 'https://youtu.be/...', dir: TextDirection.ltr),
          const SizedBox(height: 10),
          PixelButton(
            label: t('load_video'),
            icon: 'create',
            expand: true,
            busy: busy,
            onTap: _load,
          ),
          if (lines.isNotEmpty) ...[
            PixelTitle(title),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: t('video_vocab'),
                    icon: 'sparkle',
                    small: true,
                    filled: false,
                    expand: true,
                    busy: vocabBusy,
                    onTap: _vocab,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: PixelButton(
                    label: t('video_quiz'),
                    icon: 'quiz',
                    small: true,
                    filled: false,
                    expand: true,
                    onTap: () {
                      s.requestQuiz(clip(_fullText, 8000));
                      Navigator.of(context).popUntil((r) => r.isFirst);
                    },
                  ),
                ),
              ],
            ),
            if (vocab.isNotEmpty) ...[
              PixelTitle(t('found_words')),
              for (final v in vocab)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: pixelCheck(v.on, '${v.word}  →  ${v.translation}', () => setState(() => v.on = !v.on)),
                ),
              const SizedBox(height: 8),
              PixelButton(
                label: '${t('create_cards')} (${vocab.where((v) => v.on).length})',
                icon: 'create',
                expand: true,
                onTap: _addVocab,
              ),
            ],
            PixelTitle(t('video_lines')),
            for (final l in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _openLine(l),
                  child: PixelBox(
                    u: 2,
                    padding: const EdgeInsets.all(9),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        tx(_clock(l.sec), size: 12, bold: true, color: C.gray),
                        const SizedBox(width: 10),
                        Expanded(child: tx(l.text, size: 14.5, height: 1.4)),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }
}
