import 'package:flutter/material.dart';

import 'cards_tab.dart';
import 'create_tab.dart';
import 'games_tab.dart';
import 'progress.dart';
import 'quiz_tab.dart';
import 'services.dart';
import 'settings_screen.dart';
import 'state.dart';
import 'stories_tab.dart';
import 'strings.dart';
import 'summarize_tab.dart';
import 'theme.dart';
import 'more_screen.dart';

class HomeShell extends StatelessWidget {
  final bool reveal;
  const HomeShell({super.key, this.reveal = false});

  static const List<(String, String)> _tabs = [
    ('create', 'tab_create'),
    ('cards', 'tab_cards'),
    ('games', 'tab_games'),
    ('summary', 'tab_sum'),
    ('quiz', 'tab_quiz'),
    ('stories', 'tab_stories'),
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          backgroundColor: C.cream,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: AppState.I,
              builder: (context, _) => ValueListenableBuilder<int>(
                valueListenable: AppState.I.tab,
                builder: (context, idx, _) {
                  return Column(
                    children: [
                      _TopBar(title: t(_tabs[idx].$2)),
                      Expanded(
                        child: Stack(
                          children: [
                            IndexedStack(
                              index: idx,
                              children: const [
                                CreateTab(),
                                CardsTab(),
                                GamesTab(),
                                SummarizeTab(),
                                QuizTab(),
                                StoriesTab(),
                              ],
                            ),
                            PixelRevealOverlay(
                              key: ValueKey('reveal$idx'),
                              color: C.cream,
                              ms: 380,
                              cols: 7,
                            ),
                          ],
                        ),
                      ),
                      _NavBar(index: idx, tabs: _tabs),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
        if (reveal)
          const PixelRevealOverlay(
            key: ValueKey('firstReveal'),
            color: C.ink,
            ms: 800,
            cols: 9,
          ),
      ],
    );
  }
}

class _TopBar extends StatelessWidget {
  final String title;
  const _TopBar({required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: const BoxDecoration(
        color: C.cream,
        border: Border(bottom: BorderSide(color: C.ink, width: 3)),
      ),
      child: Row(
        children: [
          Sprite(AppState.I.mascot, px: 3),
          const SizedBox(width: 8),
          const PixelFont('AORC AI', scale: 3),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: C.gray),
            ),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const MoreScreen()),
              );
            },
            child: const PixelBox(
              padding: EdgeInsets.all(7),
              child: Sprite('more', px: 2.5),
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProgressScreen()),
              );
            },
            child: PixelBox(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Sprite('flame', px: 2.5),
                  const SizedBox(width: 5),
                  tx('${AppState.I.streak}', bold: true, size: 14),
                ],
              ),
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
            child: const PixelBox(
              padding: EdgeInsets.all(7),
              child: Sprite('gear', px: 2.5),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int index;
  final List<(String, String)> tabs;
  const _NavBar({required this.index, required this.tabs});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: C.white,
        border: Border(top: BorderSide(color: C.ink, width: 3)),
      ),
      padding: const EdgeInsets.fromLTRB(4, 6, 4, 6),
      child: Row(
        children: [
          for (int i = 0; i < tabs.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  if (i != index) {
                    Sfx.play('flip');
                    AppState.I.tab.value = i;
                  }
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  color: i == index ? C.ink : Colors.transparent,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Sprite(tabs[i].$1, px: 2.4, tint: i == index ? C.cream : C.ink),
                      const SizedBox(height: 3),
                      Text(
                        t(tabs[i].$2),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                          color: i == index ? C.cream : C.ink,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
