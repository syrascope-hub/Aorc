import 'package:flutter/material.dart';

import 'common.dart';
import 'rich.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class _PQ {
  final String q;
  final List<String> options;
  final int answer;
  int? picked;
  _PQ(this.q, this.options, this.answer);
}

/// One smart lesson per day built from the learner's weakest words.
class DailyPackScreen extends StatefulWidget {
  const DailyPackScreen({super.key});
  @override
  State<DailyPackScreen> createState() => _DailyPackScreenState();
}

class _DailyPackScreenState extends State<DailyPackScreen> {
  bool busy = false;
  bool rewarded = false;
  List<CardItem> words = [];
  String title = '';
  String paragraph = '';
  List<_PQ> qs = [];

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    if (s.hfToken.trim().isNotEmpty && s.scope.length >= 3) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _gen());
    }
  }

  Future<void> _gen() async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    words = weakestCards(s.scope, 5);
    if (words.length < 3) {
      toast(context, '${t('need_cards_n')} 3 (${t('you_have')} ${words.length})');
      return;
    }
    setState(() {
      busy = true;
      qs = [];
      paragraph = '';
      rewarded = false;
    });
    try {
      final lvl = s.placement.isEmpty ? 'B1' : s.placement;
      final r = await Ai.chat(
        'Write a short engaging paragraph (80 to 110 words) in ${langOf(s.frontLang).en} at CEFR level $lvl that '
        'naturally uses all of these words, wrapping each used word in ** **: ${words.map((c) => c.front).join(', ')}. '
        'Then write 2 multiple-choice comprehension questions about the paragraph, 3 options each. '
        'Output ONLY JSON: {"title":"...","text":"...","questions":[{"q":"...","options":["...","...","..."],"answer":0}]} '
        'where answer is the zero-based index of the correct option.',
        system: 'You create daily mini-lessons for language learners. Output valid JSON only.',
        maxTokens: 1200,
      );
      final j = Ai.jsonObject(r);
      final list = <_PQ>[];
      for (final e in (j['questions'] as List? ?? [])) {
        if (e is! Map) continue;
        final opts = (e['options'] as List? ?? []).map((x) => x.toString()).toList();
        final a = (e['answer'] is num) ? (e['answer'] as num).toInt() : 0;
        if (opts.length >= 2 && a >= 0 && a < opts.length) {
          list.add(_PQ((e['q'] ?? '').toString(), opts, a));
        }
      }
      final text = (j['text'] ?? '').toString();
      if (text.isEmpty) throw AiError(t('bad_ai_format'));
      if (mounted) {
        setState(() {
          title = (j['title'] ?? '').toString();
          paragraph = text;
          qs = list;
        });
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _pick(_PQ q, int i) {
    if (q.picked != null) return;
    setState(() => q.picked = i);
    Sfx.play(i == q.answer ? 'ok' : 'bad');
    if (!rewarded && qs.isNotEmpty && qs.every((x) => x.picked != null)) {
      rewarded = true;
      s.bump('packs');
      s.addCoins(5);
      Sfx.play('win');
      toast(context, '${t('pack_done')} +5 ${t('coins')}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('daily_pack'),
      actions: [coinChip()],
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('daily_pack_help')),
          const SizedBox(height: 12),
          PixelButton(
            label: paragraph.isEmpty ? t('make_pack') : t('regenerate'),
            icon: 'sparkle',
            expand: true,
            busy: busy,
            onTap: _gen,
          ),
          if (paragraph.isNotEmpty) ...[
            const SizedBox(height: 14),
            PixelBox(
              padding: const EdgeInsets.all(14),
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (title.isNotEmpty) ...[tx(title, size: 19, bold: true), const SizedBox(height: 8)],
                    Directionality(
                      textDirection: s.frontLang.startsWith('ar') ? TextDirection.rtl : TextDirection.ltr,
                      child: RichMath(paragraph, size: 16),
                    ),
                    const SizedBox(height: 10),
                    SpeakBtn(paragraph, s.frontLang),
                  ],
                ),
              ),
            ),
            PixelTitle(t('pack_words')),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in words)
                  PixelBox(
                    u: 2,
                    shadow: false,
                    color: C.creamDeep,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    child: tx('${c.front} = ${c.back}', size: 13, bold: true),
                  ),
              ],
            ),
            for (final q in qs) ...[
              PixelTitle(q.q),
              for (int i = 0; i < q.options.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _pick(q, i),
                    child: PixelBox(
                      color: q.picked != null && i == q.answer
                          ? C.ink
                          : (q.picked == i ? C.light : C.white),
                      padding: const EdgeInsets.all(12),
                      child: SizedBox(
                        width: double.infinity,
                        child: Text(q.options[i],
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: q.picked != null && i == q.answer ? C.cream : C.ink)),
                      ),
                    ),
                  ),
                ),
            ],
          ],
        ],
      ),
    );
  }
}
