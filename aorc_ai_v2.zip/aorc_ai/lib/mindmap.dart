import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class _Item {
  final String term, def;
  _Item(this.term, this.def);
}

class _Branch {
  final String title;
  final List<_Item> items;
  _Branch(this.title, this.items);
}

/// AI mind map of a topic or text, convertible into flashcards.
class MindMapScreen extends StatefulWidget {
  const MindMapScreen({super.key});
  @override
  State<MindMapScreen> createState() => _MindMapScreenState();
}

class _MindMapScreenState extends State<MindMapScreen> {
  final input = TextEditingController();
  bool busy = false;
  String center = '';
  List<_Branch> branches = [];

  AppState get s => AppState.I;

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _gen() async {
    final src = input.text.trim();
    if (src.isEmpty) {
      toast(context, t('need_text'));
      return;
    }
    setState(() => busy = true);
    try {
      final r = await Ai.chat(
        'Create a mind map for the topic or text below, in the same language as the input '
        '(if it is just a topic, use ${s.uiLang == 'ar' ? 'Arabic' : 'English'}). '
        'Use 4 to 6 branches and 2 to 4 items per branch. Each item has a short "term" and a one-sentence "def". '
        'Output ONLY JSON: {"center":"...","branches":[{"title":"...","items":[{"term":"...","def":"..."}]}]}\n\n'
        'Input:\n${clip(src, 7000)}',
        system: 'You are an expert at organizing knowledge into clear mind maps.',
        maxTokens: 1800,
        temp: 0.4,
      );
      final j = Ai.jsonObject(r);
      final bs = <_Branch>[];
      for (final b in (j['branches'] as List? ?? [])) {
        if (b is! Map) continue;
        final items = <_Item>[];
        for (final it in (b['items'] as List? ?? [])) {
          if (it is! Map) continue;
          final term = (it['term'] ?? '').toString().trim();
          final def = (it['def'] ?? '').toString().trim();
          if (term.isNotEmpty && def.isNotEmpty) items.add(_Item(term, def));
        }
        final title = (b['title'] ?? '').toString().trim();
        if (title.isNotEmpty && items.isNotEmpty) bs.add(_Branch(title, items));
      }
      if (bs.isEmpty) throw AiError(t('bad_ai_format'));
      if (mounted) {
        setState(() {
          center = (j['center'] ?? src).toString();
          branches = bs;
        });
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _toCards() async {
    final d = await s.addDeck(clip(center, 30));
    final list = [
      for (final b in branches)
        for (final it in b.items)
          CardItem(id: s.newId(), front: it.term, back: it.def, deckId: d.id),
    ];
    await s.addCards(list);
    Sfx.play('win');
    if (mounted) toast(context, '${t('cards_added')}: ${list.length}');
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('mindmap'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('mindmap_help')),
          const SizedBox(height: 12),
          PixelField(controller: input, hint: t('mindmap_hint'), minLines: 3, maxLines: 8),
          const SizedBox(height: 12),
          PixelButton(
            label: t('make_map'),
            icon: 'mind',
            expand: true,
            busy: busy,
            onTap: _gen,
          ),
          if (branches.isNotEmpty) ...[
            const SizedBox(height: 16),
            Center(
              child: PixelBox(
                color: C.ink,
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                child: Text(center,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: C.cream, fontSize: 18, fontWeight: FontWeight.w900)),
              ),
            ),
            for (final b in branches) _branch(b),
            const SizedBox(height: 14),
            PixelButton(
              label: t('map_to_cards'),
              icon: 'cards',
              expand: true,
              onTap: _toCards,
            ),
          ],
        ],
      ),
    );
  }

  Widget _branch(_Branch b) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(top: 4),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(width: 4, margin: const EdgeInsetsDirectional.only(start: 20), color: C.ink),
            const SizedBox(width: 10),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: PixelBox(
                  padding: const EdgeInsets.all(10),
                  child: SizedBox(
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        tx(b.title, size: 16, bold: true),
                        const SizedBox(height: 6),
                        for (final it in b.items)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 5),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Container(width: 6, height: 6, color: C.ink),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text.rich(
                                    TextSpan(children: [
                                      TextSpan(
                                          text: '${it.term}: ',
                                          style: const TextStyle(fontWeight: FontWeight.w900)),
                                      TextSpan(text: it.def),
                                    ]),
                                    style: const TextStyle(fontSize: 13.5, height: 1.4, fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
