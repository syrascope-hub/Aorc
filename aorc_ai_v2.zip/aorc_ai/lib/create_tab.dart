import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class CreateTab extends StatefulWidget {
  const CreateTab({super.key});
  @override
  State<CreateTab> createState() => _CreateTabState();
}

class _CreateTabState extends State<CreateTab> {
  int mode = 0; // 0 manual, 1 from text
  final front = TextEditingController();
  final back = TextEditingController();
  final example = TextEditingController();
  final bulk = TextEditingController();
  bool genImg = true;
  bool busy = false;
  bool previewBusy = false;
  String progress = '';
  Uint8List? preview;

  AppState get s => AppState.I;

  @override
  void dispose() {
    front.dispose();
    back.dispose();
    example.dispose();
    bulk.dispose();
    super.dispose();
  }

  Future<void> _translateBack() async {
    final f = front.text.trim();
    if (f.isEmpty) {
      toast(context, t('need_front'));
      return;
    }
    setState(() => busy = true);
    try {
      final r = await Ai.translateLines([f],
          from: langOf(s.frontLang).en, to: langOf(s.backLang).en);
      if (r.isNotEmpty && r.first.isNotEmpty) back.text = r.first;
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _makePreview() async {
    final f = front.text.trim();
    if (f.isEmpty) {
      toast(context, t('need_front'));
      return;
    }
    setState(() => previewBusy = true);
    try {
      final b = await Ai.image(Ai.pixelPrompt(f));
      if (mounted) setState(() => preview = b);
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => previewBusy = false);
    }
  }

  Future<void> _saveManual() async {
    final f = front.text.trim();
    var b = back.text.trim();
    if (f.isEmpty) {
      toast(context, t('need_front'));
      return;
    }
    if (b.isEmpty && s.hfToken.trim().isEmpty) {
      toast(context, t('need_back'));
      return;
    }
    setState(() {
      busy = true;
      progress = '';
    });
    try {
      if (b.isEmpty) {
        final r = await Ai.translateLines([f],
            from: langOf(s.frontLang).en, to: langOf(s.backLang).en);
        b = r.isNotEmpty ? r.first : '';
        if (b.isEmpty) throw AiError(t('bad_ai_format'));
      }
      final id = s.newId();
      String? img;
      if (preview != null) {
        img = await s.saveImage(id, preview!);
      } else if (genImg && s.hfToken.trim().isNotEmpty) {
        try {
          final bytes = await Ai.image(Ai.pixelPrompt(f));
          img = await s.saveImage(id, bytes);
        } catch (e) {
          if (mounted) toast(context, errText(e));
        }
      }
      final ex = example.text.trim();
      await s.addCard(CardItem(
        id: id,
        front: f,
        back: b,
        image: img,
        example: ex.isEmpty ? null : ex,
      ));
      Sfx.play('ok');
      front.clear();
      back.clear();
      example.clear();
      preview = null;
      if (mounted) toast(context, t('card_saved'));
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _saveBulk() async {
    final rows = parseCardLines(bulk.text);
    if (rows.isEmpty) {
      toast(context, t('need_text'));
      return;
    }
    final hasToken = s.hfToken.trim().isNotEmpty;
    final missing = <int>[];
    for (int i = 0; i < rows.length; i++) {
      if (rows[i][1].isEmpty) missing.add(i);
    }
    if (missing.isNotEmpty && !hasToken) {
      toast(context, t('need_back_bulk'));
      return;
    }
    setState(() {
      busy = true;
      progress = '';
    });
    int saved = 0;
    try {
      if (missing.isNotEmpty) {
        setState(() => progress = t('translating'));
        final tr = await Ai.translateLines(
          missing.map((i) => rows[i][0]).toList(),
          from: langOf(s.frontLang).en,
          to: langOf(s.backLang).en,
        );
        for (int k = 0; k < missing.length; k++) {
          rows[missing[k]][1] = tr[k];
        }
      }
      for (int i = 0; i < rows.length; i++) {
        if (!mounted) return;
        setState(() => progress = '${i + 1} / ${rows.length}');
        final f = rows[i][0];
        final b = rows[i][1];
        if (b.isEmpty) continue;
        final id = s.newId();
        String? img;
        if (genImg && hasToken) {
          try {
            final bytes = await Ai.image(Ai.pixelPrompt(f));
            img = await s.saveImage(id, bytes);
          } catch (e) {
            if (mounted) toast(context, errText(e));
          }
        }
        await s.addCard(CardItem(id: id, front: f, back: b, image: img));
        saved++;
      }
      Sfx.play('win');
      bulk.clear();
      if (mounted) toast(context, '${t('cards_added')}: $saved');
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() {
        busy = false;
        progress = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final noToken = s.hfToken.trim().isEmpty;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        PixelChips<int>(
          options: [(0, t('manual')), (1, t('from_text'))],
          value: mode,
          onChanged: (v) => setState(() => mode = v),
        ),
        const SizedBox(height: 12),
        if (noToken)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: PixelBox(
              color: C.creamDeep,
              child: tx(t('token_hint'), size: 13, height: 1.4),
            ),
          ),
        if (mode == 0) ..._manual() else ..._fromText(),
        if (progress.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Center(child: tx(progress, bold: true)),
          ),
      ],
    );
  }

  List<Widget> _manual() {
    return [
      PixelTitle('${t('front')} (${langName(s.frontLang)})'),
      PixelField(controller: front, hint: t('front_hint')),
      PixelTitle('${t('back_side')} (${langName(s.backLang)})'),
      PixelField(
        controller: back,
        hint: t('back_hint'),
        suffix: GestureDetector(
          onTap: busy ? null : _translateBack,
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 6),
            child: Sprite('sparkle', px: 2.5),
          ),
        ),
      ),
      PixelTitle(t('example_opt')),
      PixelField(controller: example, hint: t('example_hint'), maxLines: 3),
      const SizedBox(height: 14),
      Row(
        children: [
          Expanded(
            child: PixelButton(
              label: t('ai_image'),
              icon: 'sparkle',
              filled: false,
              busy: previewBusy,
              onTap: busy ? null : _makePreview,
            ),
          ),
        ],
      ),
      if (preview != null) ...[
        const SizedBox(height: 10),
        Center(
          child: PixelBox(
            padding: const EdgeInsets.all(6),
            child: Image.memory(preview!,
                width: 160, height: 160, fit: BoxFit.cover, filterQuality: FilterQuality.none),
          ),
        ),
        const SizedBox(height: 6),
        Center(
          child: PixelButton(
            label: t('remove_image'),
            icon: 'trash',
            small: true,
            filled: false,
            onTap: () => setState(() => preview = null),
          ),
        ),
      ] else ...[
        const SizedBox(height: 8),
        _switchRow(),
      ],
      const SizedBox(height: 16),
      PixelButton(
        label: t('save_card'),
        icon: 'check',
        expand: true,
        busy: busy,
        onTap: _saveManual,
      ),
    ];
  }

  Widget _switchRow() {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => genImg = !genImg),
      child: Row(
        children: [
          PixelBox(
            u: 2,
            shadow: false,
            color: genImg ? C.ink : C.white,
            padding: const EdgeInsets.all(5),
            child: SizedBox(
              width: 10,
              height: 10,
              child: genImg ? const Sprite('check', px: 1.6, tint: C.cream) : null,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(child: tx(t('auto_image'), size: 13)),
        ],
      ),
    );
  }

  List<Widget> _fromText() {
    final rows = parseCardLines(bulk.text);
    return [
      PixelTitle(t('bulk_title')),
      tx(t('bulk_help'), size: 13, color: C.dark, height: 1.5),
      const SizedBox(height: 8),
      PixelField(
        controller: bulk,
        hint: 'apple, تفاحة\nbook, كتاب\nsun',
        minLines: 7,
        maxLines: 14,
        onChanged: (_) => setState(() {}),
      ),
      const SizedBox(height: 8),
      tx('${t('detected')}: ${rows.length}', size: 13, bold: true, color: C.gray),
      const SizedBox(height: 8),
      _switchRow(),
      const SizedBox(height: 16),
      PixelButton(
        label: t('create_cards'),
        icon: 'create',
        expand: true,
        busy: busy,
        onTap: _saveBulk,
      ),
    ];
  }
}
