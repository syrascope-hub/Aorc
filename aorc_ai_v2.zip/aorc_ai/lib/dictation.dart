import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Listen to a sentence and type it; words are marked right or wrong.
class DictationScreen extends StatefulWidget {
  const DictationScreen({super.key});
  @override
  State<DictationScreen> createState() => _DictationScreenState();
}

class _DictationScreenState extends State<DictationScreen> {
  final input = TextEditingController();
  List<String> sentences = [];
  int i = 0;
  bool started = false;
  bool busy = false;
  bool checked = false;
  bool finished = false;
  double acc = 0;
  final List<double> scores = [];
  String level = 'A2';

  AppState get s => AppState.I;

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  List<String> _fromCards() {
    final out = <String>[];
    for (final c in s.scope) {
      final e = (c.example ?? '').trim();
      if (e.split(' ').length >= 3) out.add(e);
    }
    out.shuffle();
    return out.take(8).toList();
  }

  Future<void> _start() async {
    var list = _fromCards();
    if (list.length < 5) {
      if (s.hfToken.trim().isEmpty && list.isEmpty) {
        toast(context, t('need_token'));
        return;
      }
      if (s.hfToken.trim().isNotEmpty) {
        setState(() => busy = true);
        try {
          final words = randomCards(s.scope, 8).map((c) => c.front).toList();
          final r = await Ai.chat(
            'Write 8 natural sentences in ${langOf(s.frontLang).en} at CEFR level $level, each 6 to 12 words, '
            '${words.isEmpty ? '' : 'using these words when possible: ${words.join(', ')}. '}'
            'Output ONLY a JSON array of strings.',
            maxTokens: 700,
            temp: 0.6,
          );
          final extra = Ai.jsonList(r).map((e) => e.toString().trim()).where((e) => e.isNotEmpty);
          list = [...list, ...extra].take(8).toList();
        } catch (e) {
          if (mounted) toast(context, errText(e));
        } finally {
          if (mounted) setState(() => busy = false);
        }
      }
    }
    if (list.isEmpty || !mounted) return;
    setState(() {
      sentences = list;
      i = 0;
      scores.clear();
      started = true;
      finished = false;
      checked = false;
      input.clear();
    });
    Speech.speak(sentences[0], s.frontLang);
  }

  List<String> _tokens(String x) =>
      normText(x).split(' ').where((w) => w.isNotEmpty).toList();

  void _check() {
    final target = _tokens(sentences[i]);
    final got = _tokens(input.text);
    final pool = List<String>.of(got);
    int ok = 0;
    for (final w in target) {
      final k = pool.indexOf(w);
      if (k >= 0) {
        ok++;
        pool.removeAt(k);
      }
    }
    acc = target.isEmpty ? 0 : ok / target.length;
    scores.add(acc);
    Sfx.play(acc >= 0.8 ? 'ok' : 'bad');
    setState(() => checked = true);
  }

  void _next() {
    if (i + 1 >= sentences.length) {
      final avg = scores.reduce((a, b) => a + b) / scores.length;
      s.bump('games');
      s.addCoins((avg * sentences.length).round());
      Sfx.play('win');
      setState(() => finished = true);
      return;
    }
    setState(() {
      i++;
      checked = false;
      input.clear();
    });
    Speech.speak(sentences[i], s.frontLang);
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('dictation'),
      actions: [coinChip()],
      child: !started ? _intro() : (finished ? _done() : _body()),
    );
  }

  Widget _intro() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        infoBox(t('dictation_help')),
        PixelTitle(t('level')),
        PixelChips<String>(
          options: const [('A1', 'A1'), ('A2', 'A2'), ('B1', 'B1'), ('B2', 'B2')],
          value: level,
          onChanged: (v) => setState(() => level = v),
        ),
        const SizedBox(height: 18),
        PixelButton(label: t('start'), icon: 'headphones', expand: true, busy: busy, onTap: _start),
      ],
    );
  }

  Widget _done() {
    final avg = scores.isEmpty ? 0.0 : scores.reduce((a, b) => a + b) / scores.length;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('trophy', px: 8),
            const SizedBox(height: 14),
            tx('${(avg * 100).round()}%', size: 30, bold: true),
            const SizedBox(height: 4),
            tx('+${(avg * sentences.length).round()} ${t('coins')}', bold: true),
            const SizedBox(height: 18),
            PixelButton(label: t('play_again'), icon: 'headphones', onTap: _start),
            const SizedBox(height: 10),
            PixelButton(
                label: t('back'), filled: false, onTap: () => Navigator.of(context).maybePop()),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    final got = _tokens(input.text).toList();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(children: [
          Expanded(child: PixelBar(value: i / sentences.length, segs: 10, height: 10)),
          const SizedBox(width: 10),
          tx('${i + 1} / ${sentences.length}', bold: true, color: C.gray),
        ]),
        const SizedBox(height: 16),
        Center(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => Speech.speak(sentences[i], s.frontLang),
            child: const PixelBox(
              padding: EdgeInsets.all(20),
              child: Sprite('speaker', px: 6),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Center(child: tx(t('replay'), bold: true, color: C.gray, size: 13)),
        const SizedBox(height: 14),
        PixelField(
          controller: input,
          hint: t('dict_type'),
          minLines: 3,
          maxLines: 5,
          dir: s.frontLang.startsWith('ar') ? TextDirection.rtl : TextDirection.ltr,
        ),
        const SizedBox(height: 12),
        if (!checked)
          PixelButton(label: t('check'), icon: 'check', expand: true, onTap: _check)
        else ...[
          PixelBox(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  tx('${t('accuracy')}: ${(acc * 100).round()}%', bold: true, size: 15),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final w in sentences[i].split(RegExp(r'\s+')))
                        Builder(builder: (context) {
                          final ok = got.remove(normText(w));
                          return PixelBox(
                            u: 2,
                            shadow: false,
                            color: ok ? C.white : C.ink,
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: Text(w,
                                style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    color: ok ? C.ink : C.cream)),
                          );
                        }),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          PixelButton(label: t('next'), expand: true, onTap: _next),
        ],
      ],
    );
  }
}
