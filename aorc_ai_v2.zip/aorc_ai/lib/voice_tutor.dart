import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'stt.dart';
import 'strings.dart';
import 'theme.dart';

class _Line {
  final bool user;
  final String text;
  _Line(this.user, this.text);
}

/// Hands-free spoken conversation: you talk, the AI answers aloud, repeat.
class VoiceTutorScreen extends StatefulWidget {
  const VoiceTutorScreen({super.key});
  @override
  State<VoiceTutorScreen> createState() => _VoiceTutorScreenState();
}

class _VoiceTutorScreenState extends State<VoiceTutorScreen> {
  final FlutterTts _tts = FlutterTts();
  final scroll = ScrollController();
  final List<_Line> lines = [];
  final List<Map<String, String>> history = [];
  String level = 'A2';
  String state = 'idle'; // idle | listen | think | speak
  String partial = '';
  int _token = 0;

  AppState get s => AppState.I;
  bool get _active => state != 'idle';

  @override
  void initState() {
    super.initState();
    _tts.awaitSpeakCompletion(true);
  }

  @override
  void dispose() {
    _token++;
    Stt.stop();
    _tts.stop();
    scroll.dispose();
    super.dispose();
  }

  String get _system {
    final lang = langOf(s.frontLang).en;
    final words = randomCards(s.scope, 5).map((c) => c.front).toList();
    return 'You are a friendly spoken-conversation tutor for a $lang learner at CEFR level $level. '
        'Speak only $lang. Keep every reply to 1 or 2 short sentences, natural and easy to say aloud, '
        'with no lists, no emojis and no markdown, and end with a simple question. '
        '${words.isEmpty ? '' : 'When natural, bring up these words: ${words.join(', ')}. '}'
        'If the learner makes a clear mistake, gently repeat the correct form inside your reply.';
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent + 100,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _say(String text) async {
    try {
      await _tts.setLanguage(s.frontLang);
      await _tts.setSpeechRate(s.speechRate);
      await _tts.speak(text);
    } catch (_) {}
  }

  Future<void> _start() async {
    if (s.hfToken.trim().isEmpty) {
      toast(context, t('need_token'));
      return;
    }
    if (!await Stt.init()) {
      if (mounted) toast(context, t('stt_unavailable'));
      return;
    }
    await Speech.stop();
    final my = ++_token;
    lines.clear();
    history
      ..clear()
      ..add({'role': 'system', 'content': _system})
      ..add({'role': 'user', 'content': '(Greet me and ask a first question.)'});
    setState(() => state = 'think');
    int empty = 0;
    bool first = true;
    while (mounted && my == _token) {
      if (!first) {
        // listen
        setState(() {
          state = 'listen';
          partial = '';
        });
        final done = Completer<String>();
        final ok = await Stt.start(s.frontLang, (text, fin) {
          if (!mounted) return;
          if (fin) {
            if (!done.isCompleted) done.complete(text);
          } else {
            setState(() => partial = text);
          }
        });
        if (!ok) break;
        final heard = await done.future.timeout(const Duration(seconds: 30), onTimeout: () => '');
        await Stt.stop();
        if (!mounted || my != _token) break;
        if (heard.trim().isEmpty) {
          empty++;
          if (empty >= 3) break;
          continue;
        }
        empty = 0;
        setState(() => lines.add(_Line(true, heard.trim())));
        history.add({'role': 'user', 'content': heard.trim()});
        s.bump('chat');
        _toEnd();
      }
      first = false;
      // think
      setState(() => state = 'think');
      String reply;
      try {
        reply = await Ai.chatMessages(history, maxTokens: 160, temp: 0.8);
      } catch (e) {
        if (mounted) toast(context, errText(e));
        break;
      }
      if (!mounted || my != _token) break;
      history.add({'role': 'assistant', 'content': reply});
      setState(() {
        lines.add(_Line(false, reply));
        state = 'speak';
      });
      _toEnd();
      await _say(reply);
    }
    if (mounted && my == _token) setState(() => state = 'idle');
  }

  Future<void> _stop() async {
    _token++;
    await Stt.stop();
    await _tts.stop();
    if (mounted) setState(() => state = 'idle');
  }

  String get _stateLabel {
    switch (state) {
      case 'listen':
        return t('state_listen');
      case 'think':
        return t('state_think');
      case 'speak':
        return t('state_speak');
    }
    return t('voice_help');
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('voice_tutor'),
      actions: [coinChip()],
      child: Column(
        children: [
          Expanded(
            child: ListView(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
              children: [
                if (lines.isEmpty) infoBox(t('voice_help')),
                for (final l in lines)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Align(
                      alignment: l.user
                          ? AlignmentDirectional.centerEnd
                          : AlignmentDirectional.centerStart,
                      child: ConstrainedBox(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                        child: PixelBox(
                          color: l.user ? C.ink : C.white,
                          padding: const EdgeInsets.all(10),
                          child: Text(l.text,
                              style: TextStyle(
                                  fontSize: 15,
                                  height: 1.4,
                                  fontWeight: FontWeight.w600,
                                  color: l.user ? C.cream : C.ink)),
                        ),
                      ),
                    ),
                  ),
                if (state == 'listen' && partial.isNotEmpty)
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: tx('$partial…', color: C.gray, bold: true),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 14),
            child: Column(
              children: [
                if (!_active)
                  PixelChips<String>(
                    options: const [('A1', 'A1'), ('A2', 'A2'), ('B1', 'B1'), ('B2', 'B2')],
                    value: level,
                    onChanged: (v) => setState(() => level = v),
                  ),
                const SizedBox(height: 10),
                if (_active) ...[
                  tx(_stateLabel, bold: true, color: C.gray),
                  const SizedBox(height: 8),
                ],
                PixelButton(
                  label: _active ? t('end_call') : t('start_call'),
                  icon: _active ? null : 'mic',
                  expand: true,
                  filled: !_active,
                  onTap: _active ? _stop : _start,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
