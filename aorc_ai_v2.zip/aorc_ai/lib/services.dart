import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

import 'state.dart';
import 'strings.dart';

// ───────────────────────── Sound effects (8-bit, generated) ─────────────────────────

class Sfx {
  static final Map<String, Uint8List> _cache = {};

  static const Map<String, List<List<double>>> _notes = {
    'tap': [
      [880, 0.04]
    ],
    'flip': [
      [520, 0.04],
      [780, 0.05]
    ],
    'ok': [
      [660, 0.07],
      [880, 0.07],
      [1320, 0.12]
    ],
    'bad': [
      [300, 0.12],
      [200, 0.2]
    ],
    'start': [
      [440, 0.08],
      [660, 0.08],
      [880, 0.08],
      [1100, 0.16]
    ],
    'win': [
      [660, 0.08],
      [880, 0.08],
      [1100, 0.08],
      [880, 0.08],
      [1320, 0.2]
    ],
  };

  static Future<void> play(String name) async {
    if (!AppState.I.sfx) return;
    try {
      final bytes = _cache.putIfAbsent(name, () => _tone(_notes[name] ?? _notes['tap']!));
      final p = AudioPlayer();
      p.onPlayerComplete.listen((_) => p.dispose());
      await p.play(BytesSource(bytes), volume: 0.45);
    } catch (_) {}
  }

  static Uint8List _tone(List<List<double>> notes) {
    const rate = 22050;
    final samples = <int>[];
    for (final n in notes) {
      final f = n[0];
      final cnt = (rate * n[1]).round();
      for (int i = 0; i < cnt; i++) {
        final env = 1 - i / cnt;
        final phase = (i * f / rate) % 1.0;
        final v = (f == 0 ? 0.0 : (phase < 0.5 ? 1.0 : -1.0)) * env * 0.35;
        samples.add((v * 32767).round());
      }
    }
    final data = ByteData(44 + samples.length * 2);
    void tag(int o, String s) {
      for (int i = 0; i < 4; i++) {
        data.setUint8(o + i, s.codeUnitAt(i));
      }
    }

    tag(0, 'RIFF');
    data.setUint32(4, 36 + samples.length * 2, Endian.little);
    tag(8, 'WAVE');
    tag(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, rate, Endian.little);
    data.setUint32(28, rate * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    tag(36, 'data');
    data.setUint32(40, samples.length * 2, Endian.little);
    for (int i = 0; i < samples.length; i++) {
      data.setInt16(44 + i * 2, samples[i], Endian.little);
    }
    return data.buffer.asUint8List();
  }
}

// ───────────────────────── Speech (two engines) ─────────────────────────

class Speech {
  static final FlutterTts _tts = FlutterTts();
  static AudioPlayer? _online;

  static Future<void> stop() async {
    try {
      await _tts.stop();
      await _online?.stop();
    } catch (_) {}
  }

  static Future<void> speak(String text, String lang) async {
    final s = AppState.I;
    var txt = text.replaceAll(RegExp(r'[*_#`$]'), ' ').trim();
    if (txt.isEmpty) return;
    if (txt.length > 3500) txt = txt.substring(0, 3500);
    await stop();
    if (s.ttsEngine == 'online') {
      if (await _speakOnline(txt, lang)) return;
    }
    try {
      await _tts.setLanguage(lang);
      await _tts.setSpeechRate(s.speechRate);
      await _tts.setPitch(1.0);
      await _tts.speak(txt);
    } catch (_) {}
  }

  static Future<bool> _speakOnline(String text, String lang) async {
    try {
      final code = lang.split('-').first;
      final chunk = text.length > 190 ? text.substring(0, 190) : text;
      final uri = Uri.parse(
          'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$code&q=${Uri.encodeComponent(chunk)}');
      final r = await http
          .get(uri, headers: {'User-Agent': 'Mozilla/5.0'})
          .timeout(const Duration(seconds: 12));
      if (r.statusCode != 200 || r.bodyBytes.length < 200) return false;
      _online ??= AudioPlayer();
      await _online!.play(BytesSource(r.bodyBytes, mimeType: 'audio/mpeg'));
      return true;
    } catch (_) {
      return false;
    }
  }
}

// ───────────────────────── AI (Hugging Face) ─────────────────────────

class AiError implements Exception {
  final String msg;
  AiError(this.msg);
  @override
  String toString() => msg;
}

String errText(Object e) {
  if (e is AiError) return e.msg;
  if (e is TimeoutException) return t('timeout');
  final s = e.toString();
  return '${t('net_error')}: ${s.length > 120 ? s.substring(0, 120) : s}';
}

String clip(String s, int n) => s.length > n ? s.substring(0, n) : s;

class Ai {
  static String _short(String b) => b.length > 220 ? b.substring(0, 220) : b;

  static void _needToken() {
    if (AppState.I.hfToken.trim().isEmpty) throw AiError(t('need_token'));
  }

  static Future<String> chat(
    String user, {
    String system = '',
    int maxTokens = 1800,
    double temp = 0.7,
  }) {
    return chatMessages(
      [
        if (system.isNotEmpty) {'role': 'system', 'content': system},
        {'role': 'user', 'content': user},
      ],
      maxTokens: maxTokens,
      temp: temp,
    );
  }

  /// Multi-turn chat. [messages] use roles system / user / assistant.
  static Future<String> chatMessages(
    List<Map<String, String>> messages, {
    int maxTokens = 1800,
    double temp = 0.7,
  }) async {
    return _complete(AppState.I.textModel.trim(), messages, maxTokens, temp);
  }

  /// Asks a vision model about a JPEG/PNG image.
  static Future<String> vision(
    Uint8List bytes,
    String prompt, {
    int maxTokens = 1200,
    double temp = 0.2,
  }) async {
    final b64 = base64Encode(bytes);
    return _complete(
      AppState.I.visionModel.trim(),
      [
        {
          'role': 'user',
          'content': [
            {'type': 'text', 'text': prompt},
            {
              'type': 'image_url',
              'image_url': {'url': 'data:image/jpeg;base64,$b64'},
            },
          ],
        }
      ],
      maxTokens,
      temp,
    );
  }

  static Future<String> _complete(
    String model,
    List<Map<String, dynamic>> messages,
    int maxTokens,
    double temp,
  ) async {
    _needToken();
    final s = AppState.I;
    final r = await http
        .post(
          Uri.parse('https://router.huggingface.co/v1/chat/completions'),
          headers: {
            'Authorization': 'Bearer ${s.hfToken.trim()}',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'model': model,
            'messages': messages,
            'max_tokens': maxTokens,
            'temperature': temp,
          }),
        )
        .timeout(const Duration(seconds: 120));
    final body = utf8.decode(r.bodyBytes, allowMalformed: true);
    if (r.statusCode != 200) {
      throw AiError('HTTP ${r.statusCode}: ${_short(body)}');
    }
    try {
      final j = jsonDecode(body);
      final c = j['choices'][0]['message']['content'];
      return (c as String).trim();
    } catch (_) {
      throw AiError(_short(body));
    }
  }

  static String pixelPrompt(String subject) =>
      'pixel art icon of "$subject", 16-bit retro game style, centered, simple, clean plain light background';

  static Future<Uint8List> image(String prompt) async {
    _needToken();
    final s = AppState.I;
    final uri = Uri.parse(
        'https://router.huggingface.co/hf-inference/models/${s.imageModel.trim()}');
    final r = await http
        .post(
          uri,
          headers: {
            'Authorization': 'Bearer ${s.hfToken.trim()}',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({'inputs': prompt}),
        )
        .timeout(const Duration(seconds: 150));
    final ct = r.headers['content-type'] ?? '';
    if (r.statusCode == 200 && ct.startsWith('image')) return r.bodyBytes;
    throw AiError(
        'HTTP ${r.statusCode}: ${_short(utf8.decode(r.bodyBytes, allowMalformed: true))}');
  }

  /// Extracts the first JSON array found in [s].
  static List<dynamic> jsonList(String s) {
    final a = s.indexOf('[');
    final b = s.lastIndexOf(']');
    if (a < 0 || b <= a) throw AiError(t('bad_ai_format'));
    try {
      return jsonDecode(s.substring(a, b + 1)) as List<dynamic>;
    } catch (_) {
      throw AiError(t('bad_ai_format'));
    }
  }

  /// Extracts the first JSON object found in [s].
  static Map<String, dynamic> jsonObject(String s) {
    final a = s.indexOf('{');
    final b = s.lastIndexOf('}');
    if (a < 0 || b <= a) throw AiError(t('bad_ai_format'));
    try {
      return Map<String, dynamic>.from(jsonDecode(s.substring(a, b + 1)) as Map);
    } catch (_) {
      throw AiError(t('bad_ai_format'));
    }
  }

  /// Translates each entry of [lines]; result has the same length.
  static Future<List<String>> translateLines(
    List<String> lines, {
    required String from,
    required String to,
  }) async {
    final out = <String>[];
    for (int i = 0; i < lines.length; i += 25) {
      final chunk = lines.sublist(i, i + 25 > lines.length ? lines.length : i + 25);
      final reply = await chat(
        'Translate each of the following lines from $from to $to. '
        'Output exactly one translation per line, in the same order, '
        'with no numbering, no quotes and no extra text.\n\n${chunk.join('\n')}',
        system: 'You are a precise bilingual dictionary.',
        maxTokens: 800,
        temp: 0.2,
      );
      final got = reply
          .split('\n')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
      for (int k = 0; k < chunk.length; k++) {
        out.add(k < got.length ? got[k] : '');
      }
    }
    return out;
  }
}

/// Parses "word, translation" lines. Missing translations are returned as ''.
List<List<String>> parseCardLines(String text) {
  final out = <List<String>>[];
  final sep = RegExp(r'\s*(?:,|،|;|؛|\t|=|:|\s[-–—]\s|\|)\s*');
  for (final raw in text.split('\n')) {
    final line = raw.trim();
    if (line.isEmpty) continue;
    final m = sep.firstMatch(line);
    if (m == null) {
      out.add([line, '']);
    } else {
      out.add([line.substring(0, m.start).trim(), line.substring(m.end).trim()]);
    }
  }
  return out.where((e) => e[0].isNotEmpty).toList();
}

/// Splits "# Title\nbody" into (title, body). Title is '' when absent.
(String, String) splitTitle(String s) {
  final lines = s.trim().split('\n');
  if (lines.isNotEmpty && lines.first.trim().startsWith('#')) {
    final title = lines.first.replaceFirst(RegExp(r'^\s*#+\s*'), '').replaceAll('*', '').trim();
    return (title, lines.skip(1).join('\n').trim());
  }
  return ('', s.trim());
}
