import 'package:flutter/material.dart';

import 'backup.dart';
import 'challenge.dart';
import 'chat_screen.dart';
import 'common.dart';
import 'daily_pack.dart';
import 'decks.dart';
import 'focus.dart';
import 'games2.dart';
import 'insights.dart';
import 'lessons.dart';
import 'listen_mode.dart';
import 'mindmap.dart';
import 'notifications.dart';
import 'pet.dart';
import 'placement.dart';
import 'pronounce.dart';
import 'quests.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'vision_card.dart';
import 'video_learn.dart';
import 'dictation.dart';
import 'voice_tutor.dart';
import 'word_rain.dart';

/// Hub with every extra feature, opened from the top bar.
class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    void go(Widget page, {int need = 0}) {
      if (need > 0 && !needCards(context, need)) return;
      pushPage(context, page);
    }

    return PixelPage(
      title: t('more'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 24),
          children: [
            PixelTitle(t('sec_rewards')),
            menuTile('heart', t('pet'), t('pet_d'), () => go(const PetScreen()),
                badge: s.hasPet ? s.petName : null),
            menuTile('tasks', t('quests'), t('quests_d'), () => go(const QuestsScreen())),
            menuTile('trophy', t('achievements'), t('achievements_d'), () => go(const AchievementsScreen())),
            menuTile('shop', t('shop'), t('shop_d'), () => go(const ShopScreen())),
            PixelTitle(t('sec_ai')),
            menuTile('sparkle', t('daily_pack'), t('daily_pack_d'), () => go(const DailyPackScreen(), need: 3)),
            menuTile('chat', t('chat'), t('chat_d'), () => go(const ChatScreen(), need: 3)),
            menuTile('mic', t('pronounce'), t('pronounce_d'), () => go(const PronounceScreen(), need: 1)),
            menuTile('camera', t('photo_cards'), t('photo_cards_d'), () => go(const VisionCardScreen())),
            menuTile('chat', t('voice_tutor'), t('voice_tutor_d'), () => go(const VoiceTutorScreen(), need: 1)),
            menuTile('create', t('video_learn'), t('video_learn_d'), () => go(const VideoLearnScreen())),
            menuTile('headphones', t('dictation'), t('dictation_d'), () => go(const DictationScreen())),
            menuTile('summary', t('lessons'), t('lessons_d'), () => go(const LessonsScreen())),
            menuTile('mind', t('mindmap'), t('mindmap_d'), () => go(const MindMapScreen())),
            menuTile('trophy', t('placement'), t('placement_d'), () => go(const PlacementScreen()),
                badge: s.placement.isEmpty ? null : s.placement),
            PixelTitle(t('sec_play')),
            menuTile('heart', t('g_survival'), t('g_survival_d'), () => go(const SurvivalGame(), need: 4)),
            menuTile('bolt', t('g_speed'), t('g_speed_d'), () => go(const SpeedGame(), need: 4)),
            menuTile('skull', t('g_boss'), t('g_boss_d'), () => go(const BossGame(), need: 4),
                badge: 'Lv.${(s.stat['boss'] ?? 0) + 1}'),
            menuTile('summary', t('g_cloze'), t('g_cloze_d'), () => go(const ClozeGame(), need: 3)),
            menuTile('games', t('g_rain'), t('g_rain_d'), () => go(const WordRainGame(), need: 4)),
            menuTile('dice', t('g_scramble'), t('g_scramble_d'), () => go(const ScrambleGame(), need: 3)),
            menuTile('games', t('challenge'), t('challenge_d'), () => go(const ChallengeScreen())),
            PixelTitle(t('sec_study')),
            menuTile('headphones', t('listen_mode'), t('listen_mode_d'), () => go(const ListenModeScreen(), need: 1)),
            menuTile('timer', t('focus'), t('focus_d'), () => go(const FocusScreen())),
            menuTile('chart', t('insights'), t('insights_d'), () => go(const InsightsScreen())),
            PixelTitle(t('sec_data')),
            menuTile('folder', t('decks'), t('decks_d'), () => go(const DecksScreen())),
            menuTile('save', t('backup'), t('backup_d'), () => go(const BackupScreen())),
            menuTile('bell', t('reminder'), t('reminder_d'), () => go(const ReminderScreen()),
                badge: s.reminderOn ? t('on') : null),
          ],
        ),
      ),
    );
  }
}
