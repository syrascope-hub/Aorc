import 'package:flutter/material.dart';

import 'splash.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'notifications.dart';
import 'services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppState.I.load();
  // Warm up speech in the background so the first word plays instantly.
  Speech.warm(AppState.I.frontLang);
  try {
    await Notifier.init();
    await Notifier.apply();
  } catch (_) {}
  runApp(const AorcApp());
}

class AorcApp extends StatelessWidget {
  const AorcApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.I,
      builder: (context, _) {
        final rtl = AppState.I.uiLang == 'ar';
        return MaterialApp(
          title: t('app_name'),
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          builder: (context, child) => Directionality(
            textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
            child: child ?? const SizedBox.shrink(),
          ),
          home: const SplashScreen(),
        );
      },
    );
  }
}
