import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'decks.dart';
import 'card_detail.dart';
import 'common.dart';

Widget cardImage(String? path, double size) {
  if (path == null) return SizedBox(width: size, height: size);
  return Image.file(
    File(path),
    width: size,
    height: size,
    fit: BoxFit.cover,
    filterQuality: FilterQuality.medium,
    errorBuilder: (_, __, ___) => SizedBox(width: size, height: size),
  );
}

class CardsTab extends StatefulWidget {
  const CardsTab({super.key});
  @override
  State<CardsTab> createState() => _CardsTabState();
}

class _CardsTabState extends State<CardsTab> {
  int view = 0; // 0 study, 1 list
  int idx = 0;
  bool flipped = false;
  final List<String> _ids = [];
  final search = TextEditingController();

  AppState get s => AppState.I;

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  List<CardItem> _deck() {
    final scoped = s.scope;
    final byId = {for (final c in scoped) c.id: c};
    _ids.removeWhere((i) => !byId.containsKey(i));
    final known = _ids.toSet();
    for (final c in scoped) {
      if (!known.contains(c.id)) _ids.add(c.id);
    }
    return _ids.map((i) => byId[i]!).toList();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final deck = _deck();
        if (idx >= deck.length) idx = deck.isEmpty ? 0 : deck.length - 1;
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
              child: Row(
                children: [
                  Expanded(
                    child: PixelChips<int>(
                      options: [(0, t('study')), (1, t('list'))],
                      value: view,
                      onChanged: (v) => setState(() => view = v),
                    ),
                  ),
                  tx('${deck.length}', bold: true, size: 15),
                  const SizedBox(width: 4),
                  const Sprite('cards', px: 2),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(14, 0, 14, 6),
              child: DeckBar(),
            ),
            if (deck.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
                child: _dueBar(),
              ),
            Expanded(
              child: deck.isEmpty
                  ? _empty()
                  : (view == 0 ? _study(deck) : _list(deck)),
            ),
          ],
        );
      },
    );
  }

  Widget _dueBar() {
    final n = s.dueCount;
    final active = n > 0;
    final fg = active ? C.cream : C.ink;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Sfx.play('tap');
        if (!active) {
          toast(context, t('nothing_due'));
          return;
        }
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ReviewScreen()),
        );
      },
      child: PixelBox(
        color: active ? C.ink : C.white,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        child: Row(
          children: [
            Sprite('sparkle', px: 2.4, tint: fg),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                active ? '${t('srs_review')} · ${t('review_due')}: $n' : t('nothing_due'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 13.5),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _empty() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('robot', px: 7),
            const SizedBox(height: 16),
            tx(t('no_cards'), size: 15, bold: true, align: TextAlign.center, height: 1.5),
            const SizedBox(height: 14),
            PixelButton(
              label: t('tab_create'),
              icon: 'create',
              onTap: () => AppState.I.tab.value = 0,
            ),
          ],
        ),
      ),
    );
  }

  // ───────────── study ─────────────

  void _go(int delta, List<CardItem> deck) {
    setState(() {
      idx = (idx + delta) % deck.length;
      if (idx < 0) idx += deck.length;
      flipped = false;
    });
  }

  Future<void> _rate(CardItem c, bool knew, List<CardItem> deck) async {
    if (knew) {
      c.right++;
      c.box = min(5, c.box + 1);
      Sfx.play('ok');
    } else {
      c.wrong++;
      c.box = 0;
      Sfx.play('bad');
    }
    await s.saveCards();
    if (mounted) _go(1, deck);
  }

  Widget _study(List<CardItem> deck) {
    final c = deck[idx];
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 20),
      children: [
        Row(
          children: [
            tx('${idx + 1} / ${deck.length}', bold: true, color: C.gray),
            const Spacer(),
            PixelButton(
              label: t('shuffle'),
              small: true,
              filled: false,
              onTap: () => setState(() {
                _ids.shuffle();
                idx = 0;
                flipped = false;
              }),
            ),
          ],
        ),
        const SizedBox(height: 10),
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Sfx.play('flip');
            setState(() => flipped = !flipped);
          },
          child: TweenAnimationBuilder<double>(
            key: ValueKey(c.id),
            tween: Tween<double>(begin: 0, end: flipped ? pi : 0),
            duration: const Duration(milliseconds: 320),
            builder: (context, a, _) {
              final showBack = a > pi / 2;
              return Transform(
                alignment: Alignment.center,
                transform: Matrix4.identity()
                  ..setEntry(3, 2, 0.0012)
                  ..rotateY(a),
                child: showBack
                    ? Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()..rotateY(pi),
                        child: _face(c, true),
                      )
                    : _face(c, false),
              );
            },
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: PixelButton(
                label: t('dont_know'),
                filled: false,
                onTap: () => _rate(c, false, deck),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PixelButton(
                label: t('know'),
                icon: 'check',
                onTap: () => _rate(c, true, deck),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: PixelButton(
                label: t('prev'),
                small: true,
                filled: false,
                onTap: () => _go(-1, deck),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PixelButton(
                label: t('next'),
                small: true,
                filled: false,
                onTap: () => _go(1, deck),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _face(CardItem c, bool back) {
    final fg = back ? C.cream : C.ink;
    return SizedBox(
      height: 340,
      child: PixelBox(
        color: back ? C.ink : C.white,
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (!back && c.image != null) ...[
                PixelBox(
                  padding: const EdgeInsets.all(4),
                  u: 2,
                  child: cardImage(c.image, 120),
                ),
                const SizedBox(height: 14),
              ],
              Flexible(
                child: SingleChildScrollView(
                  child: Text(
                    back ? c.back : c.front,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: fg, height: 1.25),
                  ),
                ),
              ),
              if (back && (c.example ?? '').isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  c.example!,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: C.light, fontWeight: FontWeight.w600),
                ),
              ],
              const SizedBox(height: 14),
              SpeakBtn(back ? c.back : c.front, back ? s.backLang : s.frontLang),
              const SizedBox(height: 10),
              Text(
                t('tap_flip'),
                style: TextStyle(fontSize: 11, color: back ? C.gray : C.gray, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ───────────── list ─────────────

  Widget _list(List<CardItem> deck) {
    final q = search.text.trim().toLowerCase();
    final shown = q.isEmpty
        ? deck
        : deck
            .where((c) => c.front.toLowerCase().contains(q) || c.back.toLowerCase().contains(q))
            .toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
          child: PixelField(
            controller: search,
            hint: t('search'),
            onChanged: (_) => setState(() {}),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
            itemCount: shown.length,
            itemBuilder: (context, i) {
              final c = shown[i];
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _edit(c),
                  child: PixelBox(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      children: [
                        if (c.image != null) ...[
                          cardImage(c.image, 46),
                          const SizedBox(width: 10),
                        ],
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              tx(c.front, size: 16, bold: true),
                              const SizedBox(height: 2),
                              tx(c.back, size: 14, color: C.dark),
                            ],
                          ),
                        ),
                        if (c.isLeech) ...[
                          const Sprite('skull', px: 2.4),
                          const SizedBox(width: 6),
                        ],
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () => showCardAi(context, c),
                          child: const Padding(
                            padding: EdgeInsets.all(4),
                            child: Sprite('sparkle', px: 2.4),
                          ),
                        ),
                        const SizedBox(width: 4),
                        SpeakBtn(c.front, s.frontLang),
                        const SizedBox(width: 6),
                        SpeakBtn(c.back, s.backLang),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _edit(CardItem c) async {
    final f = TextEditingController(text: c.front);
    final b = TextEditingController(text: c.back);
    final e = TextEditingController(text: c.example ?? '');
    bool regen = false;
    Uint8List? picked; // optional picture chosen from the gallery
    bool removeImg = false;
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Dialog(
          backgroundColor: C.cream,
          insetPadding: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(
            side: BorderSide(color: C.ink, width: 3),
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  PixelTitle(t('edit_card')),
                  PixelField(controller: f),
                  const SizedBox(height: 8),
                  PixelField(controller: b),
                  const SizedBox(height: 8),
                  PixelField(controller: e, hint: t('example_opt'), maxLines: 3),
                  const SizedBox(height: 10),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => setD(() => regen = !regen),
                    child: Row(
                      children: [
                        PixelBox(
                          u: 2,
                          shadow: false,
                          color: regen ? C.ink : C.white,
                          padding: const EdgeInsets.all(5),
                          child: SizedBox(
                            width: 10,
                            height: 10,
                            child: regen ? Sprite('check', px: 1.6, tint: C.cream) : null,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(child: tx(t('regen_image'), size: 13)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      if (picked != null)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 10),
                          child: PixelBox(
                            padding: const EdgeInsets.all(3),
                            child: Image.memory(picked!,
                                width: 56, height: 56, fit: BoxFit.cover),
                          ),
                        )
                      else if (c.image != null && !removeImg)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 10),
                          child: PixelBox(
                            padding: const EdgeInsets.all(3),
                            child: cardImage(c.image, 56),
                          ),
                        ),
                      Expanded(
                        child: PixelButton(
                          label: t('from_gallery'),
                          icon: 'folder',
                          small: true,
                          filled: false,
                          expand: true,
                          onTap: () async {
                            final bytes = await pickGalleryImage(ctx);
                            if (bytes != null) {
                              setD(() {
                                picked = bytes;
                                removeImg = false;
                                regen = false;
                              });
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  if (picked != null || (c.image != null && !removeImg)) ...[
                    const SizedBox(height: 8),
                    PixelButton(
                      label: t('remove_image'),
                      icon: 'trash',
                      small: true,
                      filled: false,
                      expand: true,
                      onTap: () => setD(() {
                        picked = null;
                        removeImg = true;
                      }),
                    ),
                  ],
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      PixelButton(
                        icon: 'trash',
                        filled: false,
                        onTap: () => Navigator.pop(ctx, 'delete'),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: PixelButton(
                          label: t('save'),
                          onTap: () => Navigator.pop(ctx, 'save'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    final newFront = f.text.trim();
    final newBack = b.text.trim();
    final newEx = e.text.trim();
    if (res == 'delete') {
      await s.deleteCard(c);
    } else if (res == 'save' && newFront.isNotEmpty && newBack.isNotEmpty) {
      c.front = newFront;
      c.back = newBack;
      c.example = newEx.isEmpty ? null : newEx;
      await s.saveCards();
      if (picked != null) {
        c.image = await s.saveImage(c.id, picked!);
        await s.saveCards();
      } else if (removeImg && c.image != null) {
        await s.removeCardImage(c);
      }
      if (regen && mounted) {
        try {
          final bytes = await Ai.image(Ai.pixelPrompt(newFront));
          c.image = await s.saveImage(c.id, bytes);
          await s.saveCards();
        } catch (err) {
          if (mounted) toast(context, errText(err));
        }
      }
    }
  }
}
