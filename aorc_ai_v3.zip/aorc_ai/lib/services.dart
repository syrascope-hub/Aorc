import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

import 'providers.dart';
import 'state.dart';
import 'strings.dart';

// ───────────────────────── Sound effects (8-bit, generated) ─────────────────────────

class Sfx {
  static final Map<String, Uint8List> _cache = {};

  static const Map<String, List<List<double>>> _notes = {
    'tap': [
      [880, 0.04]
    ],
    'flip': [
      [520, 0.04],
      [780, 0.05]
    ],
    'ok': [
      [660, 0.07],
      [880, 0.07],
      [1320, 0.12]
    ],
    'bad': [
      [300, 0.12],
      [200, 0.2]
    ],
    'start': [
      [440, 0.08],
      [660, 0.08],
      [880, 0.08],
      [1100, 0.16]
    ],
    'win': [
      [660, 0.08],
      [880, 0.08],
      [1100, 0.08],
      [880, 0.08],
      [1320, 0.2]
    ],
  };

  static final List<AudioPlayer> _pool = [];
  static int _pi = 0;

  static Future<void> play(String name) async {
    if (!AppState.I.sfx) return;
    try {
      final bytes = _cache.putIfAbsent(name, () => _tone(_notes[name] ?? _notes['tap']!));
      if (_pool.isEmpty) {
        for (int i = 0; i < 3; i++) {
          _pool.add(AudioPlayer());
        }
      }
      final p = _pool[_pi++ % _pool.length];
      unawaited(p.play(BytesSource(bytes), volume: 0.45).catchError((_) {}));
    } catch (_) {}
  }

  static Uint8List _tone(List<List<double>> notes) {
    const rate = 22050;
    final samples = <int>[];
    for (final n in notes) {
      final f = n[0];
      final cnt = (rate * n[1]).round();
      for (int i = 0; i < cnt; i++) {
        final env = 1 - i / cnt;
        final phase = (i * f / rate) % 1.0;
        final v = (f == 0 ? 0.0 : (phase < 0.5 ? 1.0 : -1.0)) * env * 0.35;
        samples.add((v * 32767).round());
      }
    }
    final data = ByteData(44 + samples.length * 2);
    void tag(int o, String s) {
      for (int i = 0; i < 4; i++) {
        data.setUint8(o + i, s.codeUnitAt(i));
      }
    }

    tag(0, 'RIFF');
    data.setUint32(4, 36 + samples.length * 2, Endian.little);
    tag(8, 'WAVE');
    tag(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, rate, Endian.little);
    data.setUint32(28, rate * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    tag(36, 'data');
    data.setUint32(40, samples.length * 2, Endian.little);
    for (int i = 0; i < samples.length; i++) {
      data.setInt16(44 + i * 2, samples[i], Endian.little);
    }
    return data.buffer.asUint8List();
  }
}

// ───────────────────────── Speech (two engines) ─────────────────────────

class Speech {
  static final FlutterTts _tts = FlutterTts();
  static AudioPlayer? _online;
  static final http.Client _hc = http.Client();

  // Decoded online clips, reused so replaying a word is instant.
  static final Map<String, Uint8List> _cache = {};
  static final List<String> _order = [];

  static bool _ready = false;
  static bool _sysSpeaking = false;
  static String? _lang;
  static double? _rate;
  static int _gen = 0; // bumped on every request so older ones can bail out

  /// Prepares the engine once (call early, e.g. from main) so the first word is fast.
  static Future<void> init() async {
    if (_ready) return;
    _ready = true;
    try {
      _tts.setStartHandler(() => _sysSpeaking = true);
      _tts.setCompletionHandler(() => _sysSpeaking = false);
      _tts.setCancelHandler(() => _sysSpeaking = false);
      _tts.setErrorHandler((_) => _sysSpeaking = false);
      await _tts.awaitSpeakCompletion(false);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
    } catch (_) {}
    try {
      await _tts.setQueueMode(0); // Android: new speech replaces the old immediately
    } catch (_) {}
  }

  /// Pre-selects [lang] and rate so the next [speak] has nothing left to set up.
  static Future<void> warm(String lang) async {
    await init();
    try {
      final s = AppState.I;
      if (_lang != lang) {
        await _tts.setLanguage(lang);
        _lang = lang;
      }
      if (_rate != s.speechRate) {
        await _tts.setSpeechRate(s.speechRate);
        _rate = s.speechRate;
      }
    } catch (_) {}
  }

  static Future<void> stop() async {
    _gen++;
    try {
      if (_sysSpeaking) await _tts.stop();
      await _online?.stop();
    } catch (_) {}
  }

  static Future<void> speak(String text, String lang) async {
    final s = AppState.I;
    var txt = text.replaceAll(RegExp(r'[*_#`$]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (txt.isEmpty) return;
    if (txt.length > 3500) txt = txt.substring(0, 3500);
    final gen = ++_gen;
    // Silence whatever is playing without waiting for it.
    if (_online != null) unawaited(_online!.stop().catchError((_) {}));
    if (_sysSpeaking) unawaited(_tts.stop().catchError((_) {}));
    if (s.ttsEngine == 'online') {
      if (await _speakOnline(txt, lang, gen)) return;
      if (gen != _gen) return;
    }
    await warm(lang);
    if (gen != _gen) return;
    try {
      await _tts.speak(txt);
    } catch (_) {}
  }

  /// Downloads the audio for [text] ahead of time (online engine only).
  static void prefetch(String text, String lang) {
    if (AppState.I.ttsEngine != 'online') return;
    final txt = text.replaceAll(RegExp(r'[*_#`$]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (txt.isEmpty) return;
    final code = lang.split('-').first;
    final c = _chunks(txt);
    if (c.isNotEmpty) unawaited(_fetch(code, c.first));
  }

  static List<String> _chunks(String text) {
    const max = 180;
    final out = <String>[];
    var cur = '';
    for (final part in text.split(RegExp(r'(?<=[.!?؟,،;:])\s+'))) {
      if (part.length > max) {
        if (cur.isNotEmpty) {
          out.add(cur);
          cur = '';
        }
        var buf = '';
        for (final w in part.split(' ')) {
          if (buf.isNotEmpty && buf.length + w.length + 1 > max) {
            out.add(buf);
            buf = w;
          } else {
            buf = buf.isEmpty ? w : '$buf $w';
          }
        }
        if (buf.isNotEmpty) out.add(buf);
        continue;
      }
      if (cur.isNotEmpty && cur.length + part.length + 1 > max) {
        out.add(cur);
        cur = part;
      } else {
        cur = cur.isEmpty ? part : '$cur $part';
      }
    }
    if (cur.isNotEmpty) out.add(cur);
    return out;
  }

  static Future<Uint8List?> _fetch(String code, String chunk) async {
    final k = '$code|$chunk';
    final hit = _cache[k];
    if (hit != null) return hit;
    try {
      final uri = Uri.parse(
          'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$code&q=${Uri.encodeComponent(chunk)}');
      final r = await _hc
          .get(uri, headers: {'User-Agent': 'Mozilla/5.0'})
          .timeout(const Duration(seconds: 8));
      if (r.statusCode != 200 || r.bodyBytes.length < 200) return null;
      _cache[k] = r.bodyBytes;
      _order.add(k);
      if (_order.length > 80) _cache.remove(_order.removeAt(0));
      return r.bodyBytes;
    } catch (_) {
      return null;
    }
  }

  /// Plays long text chunk by chunk, downloading the next chunk while the
  /// current one plays. Returns false when nothing could be played.
  static Future<bool> _speakOnline(String text, String lang, int gen) async {
    try {
      final code = lang.split('-').first;
      final chunks = _chunks(text);
      if (chunks.isEmpty) return false;
      var next = _fetch(code, chunks.first);
      for (int i = 0; i < chunks.length; i++) {
        final bytes = await next;
        if (gen != _gen) return true;
        if (bytes == null) return i > 0;
        if (i + 1 < chunks.length) next = _fetch(code, chunks[i + 1]);
        _online ??= AudioPlayer();
        final player = _online!;
        final done = player.onPlayerComplete.first
            .timeout(const Duration(seconds: 60), onTimeout: () {});
        await player.play(BytesSource(bytes, mimeType: 'audio/mpeg'));
        if (i + 1 < chunks.length) await done;
        if (gen != _gen) return true;
      }
      return true;
    } catch (_) {
      return false;
    }
  }
}

// ───────────────────────── AI (any provider) ─────────────────────────

class AiError implements Exception {
  final String msg;
  AiError(this.msg);
  @override
  String toString() => msg;
}

String errText(Object e) {
  if (e is AiError) return e.msg;
  if (e is TimeoutException) return t('timeout');
  final s = e.toString();
  return '${t('net_error')}: ${s.length > 120 ? s.substring(0, 120) : s}';
}

String clip(String s, int n) => s.length > n ? s.substring(0, n) : s;

class Ai {
  static String _short(String b) => b.length > 220 ? b.substring(0, 220) : b;

  /// One shared client keeps connections alive, which makes repeat calls faster.
  static final http.Client _hc = http.Client();

  static void _needToken() {
    if (!AppState.I.aiReady) throw AiError(t('need_token'));
  }

  static Future<String> chat(
    String user, {
    String system = '',
    int maxTokens = 1800,
    double temp = 0.7,
  }) {
    return chatMessages(
      [
        if (system.isNotEmpty) {'role': 'system', 'content': system},
        {'role': 'user', 'content': user},
      ],
      maxTokens: maxTokens,
      temp: temp,
    );
  }

  /// Multi-turn chat. [messages] use roles system / user / assistant.
  static Future<String> chatMessages(
    List<Map<String, String>> messages, {
    int maxTokens = 1800,
    double temp = 0.7,
  }) async {
    return _complete(AppState.I.textModel.trim(), messages, maxTokens, temp);
  }

  /// Asks a vision model about a JPEG/PNG image.
  static Future<String> vision(
    Uint8List bytes,
    String prompt, {
    int maxTokens = 1200,
    double temp = 0.2,
  }) async {
    final b64 = base64Encode(bytes);
    final s = AppState.I;
    final model = s.visionModel.trim().isEmpty ? s.textModel.trim() : s.visionModel.trim();
    if (presetById(s.aiProvider).style == 'anthropic') {
      return _complete(
        model,
        [
          {
            'role': 'user',
            'content': [
              {
                'type': 'image',
                'source': {'type': 'base64', 'media_type': 'image/jpeg', 'data': b64},
              },
              {'type': 'text', 'text': prompt},
            ],
          }
        ],
        maxTokens,
        temp,
      );
    }
    return _complete(
      model,
      [
        {
          'role': 'user',
          'content': [
            {'type': 'text', 'text': prompt},
            {
              'type': 'image_url',
              'image_url': {'url': 'data:image/jpeg;base64,$b64'},
            },
          ],
        }
      ],
      maxTokens,
      temp,
    );
  }

  static String _chatUrl() {
    var base = AppState.I.aiBaseUrl.trim();
    while (base.endsWith('/')) {
      base = base.substring(0, base.length - 1);
    }
    if (base.isEmpty) throw AiError(t('need_base_url'));
    if (!base.startsWith('http')) base = 'https://$base';
    if (base.endsWith('/chat/completions') || base.endsWith('/messages')) return base;
    return presetById(AppState.I.aiProvider).style == 'anthropic'
        ? '$base/messages'
        : '$base/chat/completions';
  }

  static Future<http.Response> _post(Uri uri, Map<String, String> headers, String body,
      {int seconds = 120}) async {
    http.Response r = await _hc.post(uri, headers: headers, body: body)
        .timeout(Duration(seconds: seconds));
    // One quick retry on rate limit / transient server errors.
    if (r.statusCode == 429 || r.statusCode == 502 || r.statusCode == 503) {
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      r = await _hc.post(uri, headers: headers, body: body).timeout(Duration(seconds: seconds));
    }
    return r;
  }

  static Future<String> _complete(
    String model,
    List<Map<String, dynamic>> messages,
    int maxTokens,
    double temp,
  ) async {
    _needToken();
    final s = AppState.I;
    final key = s.hfToken.trim();
    if (model.isEmpty) throw AiError(t('need_model'));
    final anth = presetById(s.aiProvider).style == 'anthropic';
    final uri = Uri.parse(_chatUrl());
    final headers = <String, String>{'Content-Type': 'application/json'};
    late final String body;
    if (anth) {
      headers['x-api-key'] = key;
      headers['anthropic-version'] = '2023-06-01';
      final sys = messages
          .where((m) => m['role'] == 'system')
          .map((m) => m['content'].toString())
          .join('\n');
      body = jsonEncode({
        'model': model,
        'max_tokens': maxTokens,
        'temperature': temp.clamp(0, 1),
        if (sys.isNotEmpty) 'system': sys,
        'messages': messages.where((m) => m['role'] != 'system').toList(),
      });
    } else {
      if (key.isNotEmpty) headers['Authorization'] = 'Bearer $key';
      body = jsonEncode({
        'model': model,
        'messages': messages,
        'max_tokens': maxTokens,
        'temperature': temp,
      });
    }
    final r = await _post(uri, headers, body);
    final text = utf8.decode(r.bodyBytes, allowMalformed: true);
    if (r.statusCode != 200) {
      throw AiError('HTTP ${r.statusCode}: ${_short(text)}');
    }
    try {
      final j = jsonDecode(text);
      if (anth) {
        final parts = (j['content'] as List)
            .where((e) => e['type'] == 'text')
            .map((e) => e['text'].toString());
        return parts.join().trim();
      }
      final c = j['choices'][0]['message']['content'];
      if (c is List) {
        return c.map((e) => (e is Map ? e['text'] ?? '' : e).toString()).join().trim();
      }
      return (c as String).trim();
    } catch (_) {
      throw AiError(_short(text));
    }
  }

  static String pixelPrompt(String subject) =>
      'pixel art icon of "$subject", 16-bit retro game style, centered, simple, clean plain light background';

  static Future<Uint8List> image(String prompt) async {
    final s = AppState.I;
    switch (s.imageProvider) {
      case 'none':
        throw AiError(t('image_off'));
      case 'pollinations':
        return _imagePollinations(prompt);
      case 'openai':
        return _imageOpenAi(prompt);
      default:
        return _imageHf(prompt);
    }
  }

  static Future<Uint8List> _imagePollinations(String prompt) async {
    final uri = Uri.parse(
        'https://image.pollinations.ai/prompt/${Uri.encodeComponent(prompt)}?width=512&height=512&nologo=true&seed=${DateTime.now().millisecondsSinceEpoch % 100000}');
    final r = await _hc.get(uri).timeout(const Duration(seconds: 90));
    final ct = r.headers['content-type'] ?? '';
    if (r.statusCode == 200 && ct.startsWith('image')) return r.bodyBytes;
    throw AiError('HTTP ${r.statusCode}: ${_short(utf8.decode(r.bodyBytes, allowMalformed: true))}');
  }

  static Future<Uint8List> _imageOpenAi(String prompt) async {
    _needToken();
    final s = AppState.I;
    var base = s.aiBaseUrl.trim();
    while (base.endsWith('/')) {
      base = base.substring(0, base.length - 1);
    }
    if (base.endsWith('/chat/completions')) {
      base = base.substring(0, base.length - '/chat/completions'.length);
    }
    if (base.isEmpty) throw AiError(t('need_base_url'));
    final key = s.imageKey.trim().isNotEmpty ? s.imageKey.trim() : s.hfToken.trim();
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (key.isNotEmpty) headers['Authorization'] = 'Bearer $key';
    final r = await _post(
      Uri.parse('$base/images/generations'),
      headers,
      jsonEncode({'model': s.imageModel.trim(), 'prompt': prompt, 'n': 1}),
      seconds: 150,
    );
    final text = utf8.decode(r.bodyBytes, allowMalformed: true);
    if (r.statusCode != 200) throw AiError('HTTP ${r.statusCode}: ${_short(text)}');
    try {
      final d = (jsonDecode(text)['data'] as List).first as Map;
      if (d['b64_json'] != null) return base64Decode(d['b64_json'].toString());
      final img = await _hc.get(Uri.parse(d['url'].toString())).timeout(const Duration(seconds: 60));
      if (img.statusCode == 200) return img.bodyBytes;
    } catch (_) {}
    throw AiError(_short(text));
  }

  static Future<Uint8List> _imageHf(String prompt) async {
    final s = AppState.I;
    final key = s.imageKey.trim().isNotEmpty ? s.imageKey.trim() : s.hfToken.trim();
    if (key.isEmpty) throw AiError(t('need_token'));
    final uri = Uri.parse(
        'https://router.huggingface.co/hf-inference/models/${s.imageModel.trim()}');
    final r = await _post(
      uri,
      {'Authorization': 'Bearer $key', 'Content-Type': 'application/json'},
      jsonEncode({'inputs': prompt}),
      seconds: 150,
    );
    final ct = r.headers['content-type'] ?? '';
    if (r.statusCode == 200 && ct.startsWith('image')) return r.bodyBytes;
    throw AiError(
        'HTTP ${r.statusCode}: ${_short(utf8.decode(r.bodyBytes, allowMalformed: true))}');
  }

  /// Extracts the first JSON array found in [s].
  static List<dynamic> jsonList(String s) {
    final a = s.indexOf('[');
    final b = s.lastIndexOf(']');
    if (a < 0 || b <= a) throw AiError(t('bad_ai_format'));
    try {
      return jsonDecode(s.substring(a, b + 1)) as List<dynamic>;
    } catch (_) {
      throw AiError(t('bad_ai_format'));
    }
  }

  /// Extracts the first JSON object found in [s].
  static Map<String, dynamic> jsonObject(String s) {
    final a = s.indexOf('{');
    final b = s.lastIndexOf('}');
    if (a < 0 || b <= a) throw AiError(t('bad_ai_format'));
    try {
      return Map<String, dynamic>.from(jsonDecode(s.substring(a, b + 1)) as Map);
    } catch (_) {
      throw AiError(t('bad_ai_format'));
    }
  }

  /// Translates each entry of [lines]; result has the same length.
  static Future<List<String>> translateLines(
    List<String> lines, {
    required String from,
    required String to,
  }) async {
    final out = <String>[];
    for (int i = 0; i < lines.length; i += 25) {
      final chunk = lines.sublist(i, i + 25 > lines.length ? lines.length : i + 25);
      final reply = await chat(
        'Translate each of the following lines from $from to $to. '
        'Output exactly one translation per line, in the same order, '
        'with no numbering, no quotes and no extra text.\n\n${chunk.join('\n')}',
        system: 'You are a precise bilingual dictionary.',
        maxTokens: 800,
        temp: 0.2,
      );
      final got = reply
          .split('\n')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
      for (int k = 0; k < chunk.length; k++) {
        out.add(k < got.length ? got[k] : '');
      }
    }
    return out;
  }
}

/// Parses "word, translation" lines. Missing translations are returned as ''.
List<List<String>> parseCardLines(String text) {
  final out = <List<String>>[];
  final sep = RegExp(r'\s*(?:,|،|;|؛|\t|=|:|\s[-–—]\s|\|)\s*');
  for (final raw in text.split('\n')) {
    final line = raw.trim();
    if (line.isEmpty) continue;
    final m = sep.firstMatch(line);
    if (m == null) {
      out.add([line, '']);
    } else {
      out.add([line.substring(0, m.start).trim(), line.substring(m.end).trim()]);
    }
  }
  return out.where((e) => e[0].isNotEmpty).toList();
}

/// Splits "# Title\nbody" into (title, body). Title is '' when absent.
(String, String) splitTitle(String s) {
  final lines = s.trim().split('\n');
  if (lines.isNotEmpty && lines.first.trim().startsWith('#')) {
    final title = lines.first.replaceFirst(RegExp(r'^\s*#+\s*'), '').replaceAll('*', '').trim();
    return (title, lines.skip(1).join('\n').trim());
  }
  return ('', s.trim());
}
