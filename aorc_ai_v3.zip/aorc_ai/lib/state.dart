import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'providers.dart';
import 'theme.dart';

class Lang {
  final String code, ar, en;
  const Lang(this.code, this.ar, this.en);
}

const List<Lang> kLangs = [
  Lang('en-US', 'الإنجليزية', 'English'),
  Lang('ar-SA', 'العربية', 'Arabic'),
  Lang('fr-FR', 'الفرنسية', 'French'),
  Lang('de-DE', 'الألمانية', 'German'),
  Lang('es-ES', 'الإسبانية', 'Spanish'),
  Lang('tr-TR', 'التركية', 'Turkish'),
  Lang('it-IT', 'الإيطالية', 'Italian'),
  Lang('ru-RU', 'الروسية', 'Russian'),
  Lang('pt-BR', 'البرتغالية', 'Portuguese'),
  Lang('ja-JP', 'اليابانية', 'Japanese'),
  Lang('ko-KR', 'الكورية', 'Korean'),
  Lang('zh-CN', 'الصينية', 'Chinese'),
];

Lang langOf(String code) =>
    kLangs.firstWhere((l) => l.code == code, orElse: () => kLangs.first);

/// Language name in the current UI language.
String langName(String code) =>
    AppState.I.uiLang == 'ar' ? langOf(code).ar : langOf(code).en;

class Deck {
  String id, name;
  Deck(this.id, this.name);
  Map<String, dynamic> toJson() => {'id': id, 'name': name};
  factory Deck.fromJson(Map<String, dynamic> j) =>
      Deck((j['id'] ?? '').toString(), (j['name'] ?? '').toString());
}

class CardItem {
  String id, front, back;
  String? image, example, mnemonic;
  String deckId;
  int box, right, wrong, created;
  // spaced repetition (SM-2 style)
  double ease;
  int interval, reps, due; // interval in days, due = epoch ms (0 = new card)

  CardItem({
    required this.id,
    required this.front,
    required this.back,
    this.image,
    this.example,
    this.mnemonic,
    this.deckId = 'default',
    this.box = 0,
    this.right = 0,
    this.wrong = 0,
    this.ease = 2.5,
    this.interval = 0,
    this.reps = 0,
    this.due = 0,
    int? created,
  }) : created = created ?? DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {
        'id': id,
        'front': front,
        'back': back,
        'image': image,
        'example': example,
        'mnemonic': mnemonic,
        'deckId': deckId,
        'box': box,
        'right': right,
        'wrong': wrong,
        'ease': ease,
        'interval': interval,
        'reps': reps,
        'due': due,
        'created': created,
      };

  bool get isNew => due == 0;

  /// A card the user keeps getting wrong.
  bool get isLeech => wrong >= 5 && wrong > right;
  bool get isDue => due <= DateTime.now().millisecondsSinceEpoch;

  /// Days until the next review if answered with grade [q]
  /// (0 again, 3 hard, 4 good, 5 easy). 0 means "again" (about 10 minutes).
  int intervalFor(int q) {
    if (q < 3) return 0;
    if (reps == 0) return q == 5 ? 4 : 1;
    if (reps == 1) return q == 3 ? 3 : (q == 5 ? 8 : 6);
    final f = q == 3 ? 1.2 : (q == 5 ? ease * 1.3 : ease);
    return max(interval + 1, (interval * f).round());
  }

  void applyReview(int q) {
    final days = intervalFor(q);
    final now = DateTime.now();
    if (q < 3) {
      reps = 0;
      interval = 0;
      due = now.millisecondsSinceEpoch + 10 * 60 * 1000;
      wrong++;
    } else {
      reps++;
      interval = days;
      due = DateTime(now.year, now.month, now.day + days).millisecondsSinceEpoch;
      right++;
    }
    final d = q == 0 ? -0.2 : (q == 3 ? -0.15 : (q == 5 ? 0.15 : 0.0));
    ease = max(1.3, ease + d);
    box = min(5, reps);
  }

  factory CardItem.fromJson(Map<String, dynamic> j) => CardItem(
        id: (j['id'] ?? '').toString(),
        front: (j['front'] ?? '').toString(),
        back: (j['back'] ?? '').toString(),
        image: j['image'] as String?,
        example: j['example'] as String?,
        mnemonic: j['mnemonic'] as String?,
        deckId: (j['deckId'] ?? 'default').toString(),
        box: (j['box'] ?? 0) as int,
        right: (j['right'] ?? 0) as int,
        wrong: (j['wrong'] ?? 0) as int,
        ease: ((j['ease'] ?? 2.5) as num).toDouble(),
        interval: (j['interval'] ?? 0) as int,
        reps: (j['reps'] ?? 0) as int,
        due: (j['due'] ?? 0) as int,
        created: j['created'] as int?,
      );
}

class StoryItem {
  String id, title, body, lang;
  String? image;
  int updated;

  StoryItem({
    required this.id,
    this.title = '',
    this.body = '',
    this.lang = 'en-US',
    this.image,
    int? updated,
  }) : updated = updated ?? DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'lang': lang,
        'image': image,
        'updated': updated,
      };

  factory StoryItem.fromJson(Map<String, dynamic> j) => StoryItem(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? '').toString(),
        body: (j['body'] ?? '').toString(),
        lang: (j['lang'] ?? 'en-US').toString(),
        image: j['image'] as String?,
        updated: j['updated'] as int?,
      );
}

class AppState extends ChangeNotifier {
  AppState._();
  static final AppState I = AppState._();

  late SharedPreferences _p;
  late Directory imgDir;
  final Random _rnd = Random();

  // settings
  String uiLang = 'ar';
  String hfToken = ''; // API key of the selected AI provider (name kept for backward compat)
  String aiProvider = 'huggingface';
  String aiBaseUrl = 'https://router.huggingface.co/v1';
  String imageProvider = 'hf'; // hf | openai | pollinations | none
  String imageKey = ''; // optional separate key for the image service (blank = reuse hfToken)
  String themeId = 'classic';
  double btnScale = 1.25; // 1.0 normal, 1.25 large, 1.5 extra large
  String textModel = 'Qwen/Qwen2.5-72B-Instruct';
  String imageModel = 'black-forest-labs/FLUX.1-schnell';
  String frontLang = 'en-US';
  String backLang = 'ar-SA';
  String ttsEngine = 'system'; // system | online
  double speechRate = 0.45;
  bool sfx = true;
  String visionModel = 'Qwen/Qwen2.5-VL-72B-Instruct';
  bool reminderOn = false;
  int reminderHour = 20;
  int reminderMin = 0;

  // progress
  int dailyGoal = 10;
  int totalReviews = 0;
  int bestStreak = 0;
  Map<String, int> daily = {}; // 'yyyy-MM-dd' -> reviews that day

  // data
  List<CardItem> cards = [];
  List<StoryItem> stories = [];
  List<Map<String, dynamic>> quizHistory = [];

  // decks
  List<Deck> decks = [];
  String activeDeck = 'all'; // 'all' or a deck id

  // gamification
  int coins = 0;
  List<String> owned = ['robot'];
  String mascot = 'robot';
  String placement = '';
  String questDate = '';
  Map<String, int> questProg = {};
  List<String> questClaimed = [];
  List<String> achClaimed = [];
  // virtual pet
  String petKind = ''; // '' = not adopted yet
  String petName = '';
  int petFed = 0; // epoch ms of last meal
  int petPlayed = 0; // epoch ms of last play
  Map<String, int> stat = {}; // lifetime counters (games, chat, focus, ...)

  // cross-tab helpers
  final ValueNotifier<int> tab = ValueNotifier<int>(1);
  String? pendingQuizText;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final dir = await getApplicationDocumentsDirectory();
    imgDir = Directory('${dir.path}/imgs');
    if (!imgDir.existsSync()) imgDir.createSync(recursive: true);

    uiLang = _p.getString('uiLang') ?? 'ar';
    hfToken = _p.getString('hfToken') ?? '';
    aiProvider = _p.getString('aiProvider') ?? 'huggingface';
    aiBaseUrl = _p.getString('aiBaseUrl') ?? aiBaseUrl;
    imageProvider = _p.getString('imageProvider') ?? 'hf';
    imageKey = _p.getString('imageKey') ?? '';
    themeId = _p.getString('themeId') ?? 'classic';
    btnScale = _p.getDouble('btnScale') ?? 1.25;
    C.p = palById(themeId);
    textModel = _p.getString('textModel') ?? textModel;
    imageModel = _p.getString('imageModel') ?? imageModel;
    frontLang = _p.getString('frontLang') ?? 'en-US';
    backLang = _p.getString('backLang') ?? 'ar-SA';
    ttsEngine = _p.getString('ttsEngine') ?? 'system';
    speechRate = _p.getDouble('speechRate') ?? 0.45;
    sfx = _p.getBool('sfx') ?? true;
    visionModel = _p.getString('visionModel') ?? visionModel;
    reminderOn = _p.getBool('reminderOn') ?? false;
    reminderHour = _p.getInt('reminderHour') ?? 20;
    reminderMin = _p.getInt('reminderMin') ?? 0;

    dailyGoal = _p.getInt('dailyGoal') ?? 10;
    totalReviews = _p.getInt('totalReviews') ?? 0;
    bestStreak = _p.getInt('bestStreak') ?? 0;
    try {
      final raw = _p.getString('daily');
      if (raw != null && raw.isNotEmpty) {
        daily = (jsonDecode(raw) as Map)
            .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
      }
    } catch (_) {
      daily = {};
    }

    cards = _list(_p.getString('cards')).map(CardItem.fromJson).toList();
    stories = _list(_p.getString('stories')).map(StoryItem.fromJson).toList();
    quizHistory = _list(_p.getString('quizHistory'));
    decks = _list(_p.getString('decks')).map(Deck.fromJson).toList();
    if (!decks.any((d) => d.id == 'default')) decks.insert(0, Deck('default', ''));
    activeDeck = _p.getString('activeDeck') ?? 'all';
    if (activeDeck != 'all' && !decks.any((d) => d.id == activeDeck)) activeDeck = 'all';
    try {
      final raw = _p.getString('extra');
      if (raw != null && raw.isNotEmpty) _loadExtra(Map<String, dynamic>.from(jsonDecode(raw) as Map));
    } catch (_) {}
    _rollQuests();
  }

  // ── extra (gamification) persistence ──

  Map<String, dynamic> extraJson() => {
        'coins': coins,
        'owned': owned,
        'mascot': mascot,
        'placement': placement,
        'questDate': questDate,
        'questProg': questProg,
        'questClaimed': questClaimed,
        'achClaimed': achClaimed,
        'stat': stat,
        'petKind': petKind,
        'petName': petName,
        'petFed': petFed,
        'petPlayed': petPlayed,
      };

  Map<String, int> _intMap(dynamic v) {
    if (v is! Map) return {};
    return v.map((k, x) => MapEntry(k.toString(), (x as num).toInt()));
  }

  List<String> _strList(dynamic v) =>
      v is List ? v.map((e) => e.toString()).toList() : <String>[];

  void _loadExtra(Map<String, dynamic> j) {
    coins = ((j['coins'] ?? 0) as num).toInt();
    final o = _strList(j['owned']);
    owned = o.isEmpty ? ['robot'] : o;
    mascot = (j['mascot'] ?? 'robot').toString();
    if (!owned.contains(mascot)) mascot = 'robot';
    placement = (j['placement'] ?? '').toString();
    questDate = (j['questDate'] ?? '').toString();
    questProg = _intMap(j['questProg']);
    questClaimed = _strList(j['questClaimed']);
    achClaimed = _strList(j['achClaimed']);
    stat = _intMap(j['stat']);
    petKind = (j['petKind'] ?? '').toString();
    petName = (j['petName'] ?? '').toString();
    petFed = ((j['petFed'] ?? 0) as num).toInt();
    petPlayed = ((j['petPlayed'] ?? 0) as num).toInt();
  }

  Future<void> saveExtra() async {
    await _p.setString('extra', jsonEncode(extraJson()));
    notifyListeners();
  }

  void _rollQuests() {
    final k = dayKey(DateTime.now());
    if (questDate != k) {
      questDate = k;
      questProg = {};
      questClaimed = [];
    }
  }

  /// Adds [n] to a lifetime counter and to today's quest progress.
  void bump(String k, [int n = 1]) {
    _rollQuests();
    stat[k] = (stat[k] ?? 0) + n;
    questProg[k] = (questProg[k] ?? 0) + n;
    saveExtra();
  }

  /// Keeps the maximum value seen for [k] (lifetime and today).
  void bumpMax(String k, int v) {
    _rollQuests();
    if (v > (stat[k] ?? 0)) stat[k] = v;
    if (v > (questProg[k] ?? 0)) questProg[k] = v;
    saveExtra();
  }

  void addCoins(int n) {
    coins += n;
    saveExtra();
  }

  int quest(String k) {
    _rollQuests();
    return questProg[k] ?? 0;
  }

  // ── decks ──

  List<CardItem> get scope =>
      activeDeck == 'all' ? cards : cards.where((c) => c.deckId == activeDeck).toList();

  Deck? deckById(String id) {
    for (final d in decks) {
      if (d.id == id) return d;
    }
    return null;
  }

  Future<void> saveDecks() async {
    await _p.setString('decks', jsonEncode(decks.map((d) => d.toJson()).toList()));
    await _p.setString('activeDeck', activeDeck);
    notifyListeners();
  }

  Future<void> setActiveDeck(String id) async {
    activeDeck = id;
    await saveDecks();
  }

  Future<Deck> addDeck(String name) async {
    final d = Deck('d${newId()}', name.trim());
    decks.add(d);
    await saveDecks();
    return d;
  }

  Future<void> deleteDeck(Deck d) async {
    if (d.id == 'default') return;
    for (final c in cards) {
      if (c.deckId == d.id) c.deckId = 'default';
    }
    decks.removeWhere((x) => x.id == d.id);
    if (activeDeck == d.id) activeDeck = 'all';
    await saveCards();
    await saveDecks();
  }


  List<Map<String, dynamic>> _list(String? s) {
    if (s == null || s.isEmpty) return [];
    try {
      return (jsonDecode(s) as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    } catch (_) {
      return [];
    }
  }

  /// Sends text to the quiz tab and switches to it.
  void requestQuiz(String text) {
    pendingQuizText = text;
    tab.value = 4;
    notifyListeners();
  }

  String newId() =>
      '${DateTime.now().microsecondsSinceEpoch}${_rnd.nextInt(9999)}';

  /// True when the selected AI provider can be called (key present, or none needed).
  bool get aiReady => hfToken.trim().isNotEmpty || !aiNeedsKey(aiProvider);

  Map<String, dynamic> _profile() => {
        'key': hfToken,
        'base': aiBaseUrl,
        'text': textModel,
        'vision': visionModel,
        'ip': imageProvider,
        'im': imageModel,
        'ik': imageKey,
      };

  /// Switches the AI provider, remembering the settings of the one being left
  /// and restoring (or defaulting) those of the new one.
  Future<void> switchProvider(String id) async {
    if (id == aiProvider) return;
    await _p.setString('prof_$aiProvider', jsonEncode(_profile()));
    aiProvider = id;
    var loaded = false;
    final raw = _p.getString('prof_$id');
    if (raw != null) {
      try {
        final j = Map<String, dynamic>.from(jsonDecode(raw) as Map);
        hfToken = (j['key'] ?? '').toString();
        aiBaseUrl = (j['base'] ?? '').toString();
        textModel = (j['text'] ?? '').toString();
        visionModel = (j['vision'] ?? '').toString();
        imageProvider = (j['ip'] ?? 'pollinations').toString();
        imageModel = (j['im'] ?? '').toString();
        imageKey = (j['ik'] ?? '').toString();
        loaded = true;
      } catch (_) {}
    }
    if (!loaded) {
      final p = presetById(id);
      hfToken = '';
      imageKey = '';
      aiBaseUrl = p.baseUrl;
      textModel = p.textModel;
      visionModel = p.visionModel;
      imageProvider = p.imageProvider;
      imageModel = p.imageModel;
    }
    await saveSettings();
  }

  /// True when pictures can be generated with the current image settings.
  bool get imageReady {
    switch (imageProvider) {
      case 'none':
        return false;
      case 'pollinations':
        return true;
      case 'openai':
        return aiReady && aiBaseUrl.trim().isNotEmpty;
      default:
        return (imageKey.trim().isNotEmpty || hfToken.trim().isNotEmpty);
    }
  }

  /// Switches the color theme and repaints the whole running app.
  Future<void> setTheme(String id) async {
    themeId = id;
    C.p = palById(id);
    await saveSettings();
    repaintAll();
  }

  Future<void> setBtnScale(double v) async {
    btnScale = v;
    await saveSettings();
    repaintAll();
  }

  /// Forces every widget (even const ones) to rebuild, keeping navigation state.
  static void repaintAll() {
    void visit(Element e) {
      e.markNeedsBuild();
      e.visitChildren(visit);
    }

    WidgetsBinding.instance.rootElement?.visitChildren(visit);
  }

  // ── pet ──

  bool get hasPet => petKind.isNotEmpty;

  static double _decay(int since, double perHour) {
    if (since <= 0) return 0;
    final h = (DateTime.now().millisecondsSinceEpoch - since) / 3600000.0;
    return (100 - h * perHour).clamp(0, 100).toDouble();
  }

  /// 0..100. Falls about 4 points per hour after a meal.
  double get petFullness => _decay(petFed, 4);

  /// 0..100. Falls about 5 points per hour after playing; studying today lifts it.
  double get petJoy {
    final base = _decay(petPlayed, 5);
    final study = (todayCount * 4).clamp(0, 40).toDouble();
    return (base + study).clamp(0, 100).toDouble();
  }

  int get petLevel => 1 + totalReviews ~/ 25;

  Future<void> adoptPet(String kind, String name) async {
    petKind = kind;
    petName = name.trim().isEmpty ? kind : name.trim();
    final now = DateTime.now().millisecondsSinceEpoch;
    petFed = now;
    petPlayed = now;
    await saveExtra();
  }

  /// Returns false when there are not enough coins.
  Future<bool> feedPet(int cost) async {
    if (coins < cost) return false;
    coins -= cost;
    petFed = DateTime.now().millisecondsSinceEpoch;
    await saveExtra();
    return true;
  }

  Future<void> playWithPet() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    // Each play restores some joy but not beyond full.
    final j = (petJoy + 15).clamp(0, 100);
    petPlayed = now - ((100 - j) / 5 * 3600000).round();
    await saveExtra();
  }

  Future<void> releasePet() async {
    petKind = '';
    petName = '';
    await saveExtra();
  }

  Future<void> saveSettings() async {
    await _p.setString('uiLang', uiLang);
    await _p.setString('hfToken', hfToken);
    await _p.setString('aiProvider', aiProvider);
    await _p.setString('aiBaseUrl', aiBaseUrl);
    await _p.setString('imageProvider', imageProvider);
    await _p.setString('imageKey', imageKey);
    await _p.setString('themeId', themeId);
    await _p.setDouble('btnScale', btnScale);
    await _p.setString('textModel', textModel);
    await _p.setString('imageModel', imageModel);
    await _p.setString('frontLang', frontLang);
    await _p.setString('backLang', backLang);
    await _p.setString('ttsEngine', ttsEngine);
    await _p.setDouble('speechRate', speechRate);
    await _p.setBool('sfx', sfx);
    await _p.setString('visionModel', visionModel);
    await _p.setBool('reminderOn', reminderOn);
    await _p.setInt('reminderHour', reminderHour);
    await _p.setInt('reminderMin', reminderMin);
    notifyListeners();
  }

  // ── progress / spaced repetition helpers ──

  static String dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  int get todayCount => daily[dayKey(DateTime.now())] ?? 0;

  int get dueCount => scope.where((c) => c.isDue).length;

  int get masteredCount => cards.where((c) => c.interval >= 21).length;

  /// Consecutive days with at least one review. Today may still be empty.
  int get streak {
    final now = DateTime.now();
    int n = 0;
    int i = (daily[dayKey(now)] ?? 0) > 0 ? 0 : 1;
    while (i < 4000) {
      final d = DateTime(now.year, now.month, now.day - i);
      if ((daily[dayKey(d)] ?? 0) > 0) {
        n++;
        i++;
      } else {
        break;
      }
    }
    return n;
  }

  /// Records one review. Returns true when this review reached the daily goal.
  Future<bool> recordReview() async {
    final k = dayKey(DateTime.now());
    daily[k] = (daily[k] ?? 0) + 1;
    totalReviews++;
    coins++;
    bump('review');
    final st = streak;
    if (st > bestStreak) bestStreak = st;
    await saveProgress();
    return daily[k] == dailyGoal;
  }

  Future<void> saveProgress() async {
    await _p.setString('daily', jsonEncode(daily));
    await _p.setInt('totalReviews', totalReviews);
    await _p.setInt('bestStreak', bestStreak);
    await _p.setInt('dailyGoal', dailyGoal);
    notifyListeners();
  }

  Future<void> saveCards() async {
    await _p.setString('cards', jsonEncode(cards.map((c) => c.toJson()).toList()));
    notifyListeners();
  }

  Future<void> saveStories() async {
    await _p.setString(
        'stories', jsonEncode(stories.map((c) => c.toJson()).toList()));
    notifyListeners();
  }

  Future<void> saveQuizHistory() async {
    await _p.setString('quizHistory', jsonEncode(quizHistory));
  }

  // ── backup ──

  Future<String?> _b64(String? path) async {
    if (path == null) return null;
    try {
      final f = File(path);
      if (f.existsSync()) return base64Encode(await f.readAsBytes());
    } catch (_) {}
    return null;
  }

  Future<Map<String, dynamic>> exportData() async {
    final cj = <Map<String, dynamic>>[];
    for (final c in cards) {
      final m = c.toJson();
      m['imgData'] = await _b64(c.image);
      m['image'] = null;
      cj.add(m);
    }
    final sj = <Map<String, dynamic>>[];
    for (final st in stories) {
      final m = st.toJson();
      m['imgData'] = await _b64(st.image);
      m['image'] = null;
      sj.add(m);
    }
    return {
      'app': 'aorc_ai',
      'version': 2,
      'exported': DateTime.now().toIso8601String(),
      'settings': {
        'uiLang': uiLang,
        'textModel': textModel,
        'imageModel': imageModel,
        'visionModel': visionModel,
        'frontLang': frontLang,
        'backLang': backLang,
        'ttsEngine': ttsEngine,
        'speechRate': speechRate,
        'sfx': sfx,
      },
      'decks': decks.map((d) => d.toJson()).toList(),
      'cards': cj,
      'stories': sj,
      'daily': daily,
      'totalReviews': totalReviews,
      'bestStreak': bestStreak,
      'dailyGoal': dailyGoal,
      'quizHistory': quizHistory,
      'extra': extraJson(),
    };
  }

  /// Restores a backup. Returns the number of cards added.
  Future<int> importData(Map<String, dynamic> j, {required bool replace}) async {
    if (j['app'] != 'aorc_ai') throw const FormatException('not an aorc backup');
    if (replace) {
      for (final c in cards) {
        _deleteFile(c.image);
      }
      for (final st in stories) {
        _deleteFile(st.image);
      }
      cards = [];
      stories = [];
    }
    final deckList = (j['decks'] as List? ?? []).map((e) => Deck.fromJson(Map<String, dynamic>.from(e as Map)));
    if (replace) decks = [];
    for (final d in deckList) {
      if (!decks.any((x) => x.id == d.id)) decks.add(d);
    }
    if (!decks.any((d) => d.id == 'default')) decks.insert(0, Deck('default', ''));

    int added = 0;
    final haveCards = cards.map((c) => c.id).toSet();
    for (final e in (j['cards'] as List? ?? [])) {
      final m = Map<String, dynamic>.from(e as Map);
      final c = CardItem.fromJson(m);
      if (c.id.isEmpty || haveCards.contains(c.id)) continue;
      final b = m['imgData'];
      if (b is String && b.isNotEmpty) {
        try {
          c.image = await saveImage(c.id, base64Decode(b));
        } catch (_) {}
      }
      cards.add(c);
      added++;
    }
    final haveStories = stories.map((x) => x.id).toSet();
    for (final e in (j['stories'] as List? ?? [])) {
      final m = Map<String, dynamic>.from(e as Map);
      final st = StoryItem.fromJson(m);
      if (st.id.isEmpty || haveStories.contains(st.id)) continue;
      final b = m['imgData'];
      if (b is String && b.isNotEmpty) {
        try {
          st.image = await saveImage('${st.id}c', base64Decode(b));
        } catch (_) {}
      }
      stories.add(st);
    }
    final dj = j['daily'];
    if (dj is Map) {
      dj.forEach((k, v) {
        final n = (v as num).toInt();
        if (n > (daily[k.toString()] ?? 0)) daily[k.toString()] = n;
      });
    }
    final tr = ((j['totalReviews'] ?? 0) as num).toInt();
    if (replace || tr > totalReviews) totalReviews = tr;
    final bs = ((j['bestStreak'] ?? 0) as num).toInt();
    if (bs > bestStreak) bestStreak = bs;
    final ex = j['extra'];
    if (ex is Map) {
      final keepCoins = coins;
      final keepOwned = List<String>.from(owned);
      _loadExtra(Map<String, dynamic>.from(ex));
      if (!replace) {
        if (keepCoins > coins) coins = keepCoins;
        for (final o in keepOwned) {
          if (!owned.contains(o)) owned.add(o);
        }
      }
    }
    if (replace) {
      final se = j['settings'];
      if (se is Map) {
        uiLang = (se['uiLang'] ?? uiLang).toString();
        textModel = (se['textModel'] ?? textModel).toString();
        imageModel = (se['imageModel'] ?? imageModel).toString();
        visionModel = (se['visionModel'] ?? visionModel).toString();
        frontLang = (se['frontLang'] ?? frontLang).toString();
        backLang = (se['backLang'] ?? backLang).toString();
      }
      quizHistory = (j['quizHistory'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }
    activeDeck = 'all';
    await saveCards();
    await saveStories();
    await saveDecks();
    await saveProgress();
    await saveExtra();
    await saveQuizHistory();
    await saveSettings();
    return added;
  }

  Future<String> saveImage(String id, Uint8List bytes) async {
    final f = File('${imgDir.path}/$id.img');
    await FileImage(f).evict(); // drop the old picture from Flutter's cache
    await f.writeAsBytes(bytes);
    await FileImage(f).evict();
    return f.path;
  }

  /// Removes the picture of [c] (file and reference).
  Future<void> removeCardImage(CardItem c) async {
    final p = c.image;
    if (p != null) await FileImage(File(p)).evict();
    _deleteFile(p);
    c.image = null;
    await saveCards();
  }

  Future<void> addCard(CardItem c) async {
    if (c.deckId == 'default' && activeDeck != 'all') c.deckId = activeDeck;
    cards.insert(0, c);
    bump('add');
    await saveCards();
  }

  /// Adds many cards with a single save.
  Future<void> addCards(List<CardItem> list) async {
    for (final c in list.reversed) {
      if (c.deckId == 'default' && activeDeck != 'all') c.deckId = activeDeck;
      cards.insert(0, c);
    }
    bump('add', list.length);
    await saveCards();
  }

  Future<void> deleteCard(CardItem c) async {
    cards.removeWhere((x) => x.id == c.id);
    _deleteFile(c.image);
    await saveCards();
  }

  Future<void> deleteAllCards() async {
    for (final c in cards) {
      _deleteFile(c.image);
    }
    cards = [];
    await saveCards();
  }

  Future<void> upsertStory(StoryItem s) async {
    final i = stories.indexWhere((x) => x.id == s.id);
    s.updated = DateTime.now().millisecondsSinceEpoch;
    if (i >= 0) {
      stories[i] = s;
    } else {
      stories.insert(0, s);
    }
    await saveStories();
  }

  Future<void> deleteStory(StoryItem s) async {
    stories.removeWhere((x) => x.id == s.id);
    _deleteFile(s.image);
    await saveStories();
  }

  void _deleteFile(String? path) {
    if (path == null) return;
    try {
      final f = File(path);
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }
}
