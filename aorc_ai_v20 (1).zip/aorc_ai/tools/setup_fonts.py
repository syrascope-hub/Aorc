"""Download the Tajawal Arabic font and register it in pubspec.yaml.

Runs in CI before `flutter pub get`. If any download fails the font is simply
skipped (the app then uses the phone's default font), so the build never breaks.
"""
import os
import urllib.request

BASE = "https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal/"
FILES = [
    ("Tajawal-Regular.ttf", 400),
    ("Tajawal-Medium.ttf", 500),
    ("Tajawal-Bold.ttf", 700),
    ("Tajawal-ExtraBold.ttf", 800),
    ("Tajawal-Black.ttf", 900),
]

os.makedirs("assets/fonts", exist_ok=True)
for name, _ in FILES:
    try:
        req = urllib.request.Request(BASE + name, headers={"User-Agent": "Mozilla/5.0"})
        data = urllib.request.urlopen(req, timeout=60).read()
        if len(data) < 20000:
            raise ValueError("file too small")
        with open("assets/fonts/" + name, "wb") as f:
            f.write(data)
    except Exception as e:  # noqa: BLE001
        print("Font download failed, skipping fonts:", name, e)
        raise SystemExit(0)

with open("pubspec.yaml", "r", encoding="utf-8") as f:
    spec = f.read()
if "family: Tajawal" not in spec:
    block = "\n  fonts:\n    - family: Tajawal\n      fonts:\n"
    for name, w in FILES:
        block += "        - asset: assets/fonts/%s\n          weight: %d\n" % (name, w)
    with open("pubspec.yaml", "w", encoding="utf-8") as f:
        f.write(spec.rstrip("\n") + "\n" + block)
print("Tajawal font registered")

# Display font for big headings (best effort: skipped silently if it fails).
try:
    req = urllib.request.Request(
        "https://raw.githubusercontent.com/google/fonts/main/ofl/lalezar/Lalezar-Regular.ttf",
        headers={"User-Agent": "Mozilla/5.0"},
    )
    data = urllib.request.urlopen(req, timeout=60).read()
    if len(data) < 20000:
        raise ValueError("file too small")
    with open("assets/fonts/Lalezar-Regular.ttf", "wb") as f:
        f.write(data)
    with open("pubspec.yaml", "r", encoding="utf-8") as f:
        spec = f.read()
    if "family: Lalezar" not in spec:
        with open("pubspec.yaml", "w", encoding="utf-8") as f:
            f.write(
                spec.rstrip("\n")
                + "\n    - family: Lalezar\n      fonts:\n"
                + "        - asset: assets/fonts/Lalezar-Regular.ttf\n"
            )
    print("Lalezar display font registered")
except Exception as e:  # noqa: BLE001
    print("Display font skipped:", e)
