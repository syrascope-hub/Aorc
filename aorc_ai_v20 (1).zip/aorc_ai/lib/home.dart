import 'package:flutter/material.dart';

import 'ai_tab.dart';
import 'backgrounds.dart';
import 'cards_tab.dart';
import 'common.dart';
import 'home_tab.dart';
import 'learn_tab.dart';
import 'me_tab.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'ui_extras.dart';
import 'pet.dart';
import 'pet_roamer.dart';

class HomeShell extends StatelessWidget {
  final bool reveal;
  const HomeShell({super.key, this.reveal = false});

  static const List<(String, String)> _tabs = [
    ('home', 'tab_home'),
    ('cards', 'tab_cards'),
    ('games', 'tab_learn'),
    ('ai', 'tab_ai'),
    ('me', 'tab_me'),
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          backgroundColor: C.cream,
          body: ListenableBuilder(
            listenable: AppState.I,
            builder: (context, _) => ValueListenableBuilder<int>(
              valueListenable: AppState.I.tab,
              builder: (context, idx, _) {
                return BgBackdrop(
                  id: idx == 2 ? AppState.I.bgGames : AppState.I.bgHome,
                  extra: 0,
                  child: SafeArea(
                    child: Column(
                      children: [
                        _TopBar(title: t(_tabs[idx].$2)),
                        if (idx >= 1 && idx <= 3) const DailyStrip(),
                        Expanded(
                          child: Stack(
                            children: [
                              IndexedStack(
                                index: idx,
                                children: const [
                                  HomeTab(),
                                  CardsTab(),
                                  LearnTab(),
                                  AiTab(),
                                  MeTab(),
                                ],
                              ),
                              PixelRevealOverlay(
                                key: ValueKey('reveal$idx'),
                                color: C.cream,
                                ms: 380,
                                cols: 7,
                              ),
                              if (AppState.I.hasPet)
                                const Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  height: 96,
                                  child: PetRoamer(),
                                ),
                            ],
                          ),
                        ),
                        _NavBar(index: idx, tabs: _tabs),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        if (reveal)
          PixelRevealOverlay(
            key: ValueKey('firstReveal'),
            color: C.ink,
            ms: 800,
            cols: 9,
          ),
      ],
    );
  }
}

class _TopBar extends StatelessWidget {
  final String title;
  const _TopBar({required this.title});

  @override
  Widget build(BuildContext context) {
    // Top bar grows less than the rest so every button still fits on narrow phones.
    final kt = 1 + (AppState.I.btnScale - 1) * 0.6;
    final pet = AppState.I.hasPet;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      child: Row(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PetScreen()),
              );
            },
            child: Transform.rotate(
              angle: -0.06,
              child: PixelBox(
                u: 2,
                color: C.accent2,
                padding: const EdgeInsets.all(3),
                child: pet
                    ? PetSprite(AppState.I.petKind, size: 34)
                    : Sprite(AppState.I.mascot, px: 2.6),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'AORC AI',
                  style: TextStyle(
                      fontSize: 10.5,
                      letterSpacing: 2.2,
                      fontWeight: FontWeight.w900,
                      color: C.gray),
                ),
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: dispStyle(26 * (1 + (kt - 1) * 0.4), height: 1.05),
                ),
              ],
            ),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProgressScreen()),
              );
            },
            child: PixelBox(
              u: 2,
              color: C.white,
              padding: EdgeInsets.symmetric(horizontal: 8 * kt, vertical: 5 * kt),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Sprite('flame', px: 2.5 * kt),
                  const SizedBox(width: 5),
                  tx('${AppState.I.streak}', bold: true, size: 14),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          coinChip(),
        ],
      ),
    );
  }
}

/// Floating pill navigation: the active tab grows into an accent sticker.
class _NavBar extends StatelessWidget {
  final int index;
  final List<(String, String)> tabs;
  const _NavBar({required this.index, required this.tabs});

  @override
  Widget build(BuildContext context) {
    final k = AppState.I.btnScale;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
      child: Container(
        padding: const EdgeInsets.all(5),
        decoration: BoxDecoration(
          color: C.white,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: C.ink, width: 3),
          boxShadow: [BoxShadow(color: C.ink, offset: const Offset(5, 5))],
        ),
        child: Row(
          children: [
            for (int i = 0; i < tabs.length; i++)
              Expanded(
                flex: i == index ? 15 : 10,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    if (i != index) {
                      Sfx.play('flip');
                      AppState.I.tab.value = i;
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    padding: EdgeInsets.symmetric(vertical: 7 * k),
                    decoration: BoxDecoration(
                      color: i == index ? C.accent : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: i == index ? C.ink : Colors.transparent, width: 2.5),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Sprite(tabs[i].$1,
                            px: (i == index ? 2.7 : 2.4) * k,
                            tint: i == index ? onAccent() : C.ink),
                        if (i == index) ...[
                          const SizedBox(height: 2),
                          Text(
                            t(tabs[i].$2),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 10 + 2 * (k - 1),
                              fontWeight: FontWeight.w900,
                              color: onAccent(),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
