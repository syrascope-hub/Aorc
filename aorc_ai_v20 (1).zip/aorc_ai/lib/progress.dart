import 'dart:math';

import 'package:flutter/material.dart';

import 'cards_tab.dart';
import 'flip_card.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'card_detail.dart';

// ───────────────────────── Pet ─────────────────────────

/// Total reviews needed to reach each pet stage.
const List<int> kPetSteps = [0, 15, 80, 250, 600];
const List<String> kPetSprites = ['egg', 'pet1', 'pet2', 'pet3', 'pet4'];

int petStage(int total) {
  int st = 0;
  for (int i = 0; i < kPetSteps.length; i++) {
    if (total >= kPetSteps[i]) st = i;
  }
  return st;
}

/// Segmented pixel progress bar.
class PixelBar extends StatelessWidget {
  final double value; // 0..1
  final int segs;
  final double height;
  const PixelBar({super.key, required this.value, this.segs = 12, this.height = 14});

  @override
  Widget build(BuildContext context) {
    final filled = (value.clamp(0.0, 1.0) * segs).floor();
    return Row(
      children: [
        for (int i = 0; i < segs; i++)
          Expanded(
            child: Container(
              height: height,
              margin: EdgeInsetsDirectional.only(end: i == segs - 1 ? 0 : 2),
              decoration: BoxDecoration(
                color: i < filled ? C.ink : C.white,
                border: Border.all(color: C.ink, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}

String ivLabel(int days) {
  if (days <= 0) return '10 ${t('u_m')}';
  if (days >= 365) return '${(days / 365).round()} ${t('u_y')}';
  if (days >= 30) return '${(days / 30).round()} ${t('u_mo')}';
  return '$days ${t('u_d')}';
}

// ───────────────────────── Progress screen ─────────────────────────

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});
  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _ctl;
  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _ctl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('progress'),
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
          children: [
            _petCard(),
            PixelTitle(t('daily_goal')),
            _goalCard(),
            const SizedBox(height: 10),
            _tiles(),
            PixelTitle(t('last_weeks')),
            _heatmap(),
          ],
        ),
      ),
    );
  }

  Widget _petCard() {
    final total = s.totalReviews;
    final st = petStage(total);
    final maxed = st >= kPetSteps.length - 1;
    final sleepy = s.todayCount == 0;
    double prog = 1;
    String next = t('pet_max');
    if (!maxed) {
      final a = kPetSteps[st];
      final b = kPetSteps[st + 1];
      prog = (total - a) / (b - a);
      next = '${b - total} ${t('to_next')}';
    }
    return PixelBox(
      padding: const EdgeInsets.all(14),
      child: SizedBox(
        width: double.infinity,
        child: Column(
          children: [
            SizedBox(
              height: 22,
              child: sleepy ? tx('z  z  z', bold: true, color: C.gray, size: 16) : null,
            ),
            SizedBox(
              height: 130,
              child: Center(
                child: AnimatedBuilder(
                  animation: _ctl,
                  builder: (context, child) => Transform.translate(
                    offset: Offset(0, sleepy ? 0 : (_ctl.value < 0.5 ? 0 : -6)),
                    child: child,
                  ),
                  child: Opacity(
                    opacity: sleepy ? 0.55 : 1,
                    child: Sprite(kPetSprites[st], px: 9),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            tx(t('pet_stage$st'), size: 20, bold: true),
            const SizedBox(height: 2),
            tx(sleepy ? t('pet_sleepy') : t('pet_happy'),
                color: C.gray, bold: true, size: 13, align: TextAlign.center),
            const SizedBox(height: 12),
            PixelBar(value: prog),
            const SizedBox(height: 6),
            tx(next, size: 12, color: C.dark, bold: true),
          ],
        ),
      ),
    );
  }

  Widget _goalCard() {
    final goal = s.dailyGoal;
    final today = s.todayCount;
    return PixelBox(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            children: [
              tx('$today / $goal', size: 20, bold: true),
              const Spacer(),
              PixelButton(
                label: '−',
                small: true,
                filled: false,
                onTap: goal > 5
                    ? () {
                        s.dailyGoal = goal - 5;
                        s.saveProgress();
                      }
                    : null,
              ),
              const SizedBox(width: 8),
              PixelButton(
                label: '+',
                small: true,
                filled: false,
                onTap: goal < 200
                    ? () {
                        s.dailyGoal = goal + 5;
                        s.saveProgress();
                      }
                    : null,
              ),
            ],
          ),
          const SizedBox(height: 10),
          PixelBar(value: goal == 0 ? 0 : today / goal, segs: 10),
        ],
      ),
    );
  }

  Widget _tile(String label, String value, {String? icon}) {
    return PixelBox(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: SizedBox(
        width: double.infinity,
        child: Row(
          children: [
            if (icon != null) ...[
              Sprite(icon, px: 3),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  tx(value, size: 22, bold: true),
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: C.gray),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tiles() {
    Widget row(Widget a, Widget b) => Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [Expanded(child: a), const SizedBox(width: 6), Expanded(child: b)],
          ),
        );
    return Column(
      children: [
        row(_tile(t('streak'), '${s.streak}', icon: 'flame'),
            _tile(t('best_streak'), '${s.bestStreak}', icon: 'star')),
        row(_tile(t('total_reviews'), '${s.totalReviews}', icon: 'chart'),
            _tile(t('mastered'), '${s.masteredCount}', icon: 'check')),
        row(_tile(t('due_now'), '${s.dueCount}', icon: 'sparkle'),
            _tile(t('cards_total'), '${s.cards.length}', icon: 'cards')),
      ],
    );
  }

  Color _shade(int n) {
    if (n <= 0) return C.white;
    final goal = max(1, s.dailyGoal);
    final r = n / goal;
    if (r < 0.34) return C.light;
    if (r < 0.67) return C.gray;
    if (r < 1) return C.dark;
    return C.ink;
  }

  Widget _heatmap() {
    const weeks = 14;
    const gap = 3.0;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final todayRow = today.weekday % 7; // Sunday = 0
    final start = DateTime(today.year, today.month, today.day - ((weeks - 1) * 7 + todayRow));
    return PixelBox(
      padding: const EdgeInsets.all(10),
      child: LayoutBuilder(
        builder: (context, bc) {
          final cell = ((bc.maxWidth - gap * weeks) / weeks).clamp(8.0, 24.0);
          return Column(
            children: [
              for (int r = 0; r < 7; r++)
                Padding(
                  padding: const EdgeInsets.only(bottom: gap),
                  child: Row(
                    children: [
                      for (int c = 0; c < weeks; c++)
                        Builder(builder: (context) {
                          final d = DateTime(start.year, start.month, start.day + c * 7 + r);
                          final future = d.isAfter(today);
                          final isToday = d == today;
                          return Container(
                            width: cell,
                            height: cell,
                            margin: const EdgeInsetsDirectional.only(end: gap),
                            decoration: future
                                ? null
                                : BoxDecoration(
                                    color: _shade(s.daily[AppState.dayKey(d)] ?? 0),
                                    border: Border.all(color: C.ink, width: isToday ? 2.5 : 1),
                                  ),
                          );
                        }),
                    ],
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

// ───────────────────────── Review session ─────────────────────────

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});
  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  static const int _maxSession = 40;
  static const int _maxNew = 15;

  AppState get s => AppState.I;
  late List<CardItem> queue;
  int total = 0;
  int answered = 0;
  bool shown = false;
  bool busy = false;
  bool goalHit = false;

  @override
  void initState() {
    super.initState();
    final due = s.scope.where((c) => c.isDue).toList();
    final old = due.where((c) => !c.isNew).toList()..sort((a, b) => a.due.compareTo(b.due));
    final fresh = due.where((c) => c.isNew).toList().reversed.take(_maxNew).toList();
    queue = [...old, ...fresh].take(_maxSession).toList();
    total = queue.length;
  }

  Future<void> _grade(int q) async {
    if (busy || queue.isEmpty) return;
    busy = true;
    final c = queue.first;
    c.applyReview(q);
    Sfx.play(q == 0 ? 'bad' : 'ok');
    await s.saveCards();
    final reached = await s.recordReview();
    if (!mounted) return;
    setState(() {
      queue.removeAt(0);
      if (q == 0) {
        queue.add(c); // see it again before the session ends
      } else {
        answered++;
      }
      shown = false;
      busy = false;
      if (reached) goalHit = true;
    });
    if (reached) {
      Sfx.play('win');
      toast(context, t('goal_reached'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final finished = queue.isEmpty;
    return PixelPage(
      title: t('srs_review'),
      child: finished ? _summary() : _session(),
    );
  }

  Widget _session() {
    final c = queue.first;
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
      children: [
        Row(
          children: [
            Expanded(child: PixelBar(value: total == 0 ? 0 : answered / total, segs: 14, height: 12)),
            const SizedBox(width: 10),
            tx('${min(answered + 1, total)} / $total', bold: true, color: C.gray),
          ],
        ),
        const SizedBox(height: 14),
        SwipeFlipCard(
          key: ValueKey('${c.id}_${answered}_${queue.length}'),
          flipped: shown,
          onFlip: () => setState(() => shown = !shown),
          onSwipe: shown ? (know) => _grade(know ? 4 : 0) : null,
          face: (back) => CardFace(c, back: back, showLevel: false, height: 380),
        ),
        const SizedBox(height: 12),
        if (!shown)
          PixelButton(
            label: t('show_answer'),
            expand: true,
            onTap: () {
              Sfx.play('flip');
              setState(() => shown = true);
            },
          )
        else ...[
          const SizedBox(height: 10),
          Center(
            child: PixelButton(
              label: t('ai_help'),
              icon: 'sparkle',
              small: true,
              filled: false,
              onTap: () => showCardAi(context, c),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _gradeBtn(c, 0, 'g_again', false)),
              const SizedBox(width: 10),
              Expanded(child: _gradeBtn(c, 3, 'g_hard', false)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _gradeBtn(c, 4, 'g_good', true)),
              const SizedBox(width: 10),
              Expanded(child: _gradeBtn(c, 5, 'g_easy', true)),
            ],
          ),
        ],
      ],
    );
  }

  Widget _gradeBtn(CardItem c, int q, String key, bool filled) {
    return PixelButton(
      label: '${t(key)}\n${ivLabel(c.intervalFor(q))}',
      filled: filled,
      expand: true,
      onTap: () => _grade(q),
    );
  }

  Widget _summary() {
    final st = petStage(s.totalReviews);
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Sprite(kPetSprites[st], px: 8),
            const SizedBox(height: 16),
            tx(total == 0 ? t('nothing_due') : t('session_done'),
                size: 18, bold: true, align: TextAlign.center, height: 1.4),
            if (total > 0) ...[
              const SizedBox(height: 6),
              tx('${t('reviewed_n')}: $answered', color: C.gray, bold: true),
              const SizedBox(height: 4),
              tx('${s.todayCount} / ${s.dailyGoal}', size: 16, bold: true),
              if (goalHit) ...[
                const SizedBox(height: 4),
                tx(t('goal_reached'), bold: true),
              ],
            ],
            const SizedBox(height: 18),
            PixelButton(
              label: t('open_progress'),
              icon: 'chart',
              onTap: () {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const ProgressScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
