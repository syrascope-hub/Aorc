import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// One search hit from the web (Wikimedia Commons or Openverse).
class WebImage {
  final String thumb;
  final String full;
  final String title;
  final String credit; // short attribution line
  const WebImage(this.thumb, this.full, this.title, this.credit);
}

/// Downloaded picture plus its attribution, ready to be saved on a card.
class WebPick {
  final Uint8List bytes;
  final String credit;
  const WebPick(this.bytes, this.credit);
}

/// Free picture search. Both sources need no account and no key.
class WebImages {
  static const String ua = 'AorcAI/2.14 (flashcards app)';
  static const Map<String, String> headers = {'User-Agent': ua, 'Accept': '*/*'};
  static final http.Client _hc = http.Client();

  static String _stripTags(String s) => s
      .replaceAll(RegExp(r'<[^>]*>'), '')
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#039;', "'")
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  static Future<List<WebImage>> _openverse(String q) async {
    final uri = Uri.https('api.openverse.org', '/v1/images/', {
      'q': q,
      'page_size': '18',
      'mature': 'false',
    });
    final r = await _hc.get(uri, headers: headers).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) return [];
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    final list = (j is Map ? j['results'] : null);
    if (list is! List) return [];
    final out = <WebImage>[];
    for (final e in list) {
      if (e is! Map) continue;
      final url = (e['url'] ?? '').toString();
      final th = (e['thumbnail'] ?? '').toString();
      if (url.isEmpty && th.isEmpty) continue;
      final title = (e['title'] ?? '').toString();
      final by = (e['creator'] ?? '').toString();
      final lic = ('${e['license'] ?? ''} ${e['license_version'] ?? ''}').trim().toUpperCase();
      final parts = <String>[
        if (by.isNotEmpty) by,
        if (lic.isNotEmpty) 'CC $lic',
        'Openverse',
      ];
      out.add(WebImage(th.isNotEmpty ? th : url, url.isNotEmpty ? url : th, title, parts.join(' · ')));
    }
    return out;
  }

  static Future<List<WebImage>> _wikimedia(String q) async {
    final uri = Uri.https('commons.wikimedia.org', '/w/api.php', {
      'action': 'query',
      'format': 'json',
      'generator': 'search',
      'gsrnamespace': '6',
      'gsrlimit': '18',
      'gsrsearch': '$q filetype:bitmap',
      'prop': 'imageinfo',
      'iiprop': 'url|mime|extmetadata',
      'iiurlwidth': '640',
      'iiextmetadatafilter': 'Artist|LicenseShortName',
    });
    final r = await _hc.get(uri, headers: headers).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) return [];
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    final pages = (j is Map && j['query'] is Map) ? (j['query'] as Map)['pages'] : null;
    if (pages is! Map) return [];
    final items = pages.values.whereType<Map>().toList()
      ..sort((a, b) => ((a['index'] ?? 0) as num).compareTo((b['index'] ?? 0) as num));
    final out = <WebImage>[];
    for (final p in items) {
      final infos = p['imageinfo'];
      if (infos is! List || infos.isEmpty || infos.first is! Map) continue;
      final ii = infos.first as Map;
      final mime = (ii['mime'] ?? '').toString();
      if (mime != 'image/jpeg' && mime != 'image/png' && mime != 'image/webp') continue;
      final th = (ii['thumburl'] ?? ii['url'] ?? '').toString();
      final full = (ii['url'] ?? '').toString();
      if (th.isEmpty) continue;
      final meta = ii['extmetadata'];
      String artist = '';
      String lic = '';
      if (meta is Map) {
        artist = _stripTags(((meta['Artist'] as Map?)?['value'] ?? '').toString());
        lic = _stripTags(((meta['LicenseShortName'] as Map?)?['value'] ?? '').toString());
      }
      var title = (p['title'] ?? '').toString().replaceFirst('File:', '');
      title = title.replaceFirst(RegExp(r'\.[A-Za-z]{3,4}$'), '');
      if (artist.length > 40) artist = artist.substring(0, 40);
      final parts = <String>[
        if (artist.isNotEmpty) artist,
        if (lic.isNotEmpty) lic,
        'Wikimedia Commons',
      ];
      out.add(WebImage(th, full.isEmpty ? th : full, title, parts.join(' · ')));
    }
    return out;
  }

  /// Searches both sources and interleaves the results.
  static Future<List<WebImage>> search(String query) async {
    final q = query.trim();
    if (q.isEmpty) return [];
    Future<List<WebImage>> safe(Future<List<WebImage>> f) =>
        f.timeout(const Duration(seconds: 18)).catchError((_) => <WebImage>[]);
    var res = await Future.wait([safe(_openverse(q)), safe(_wikimedia(q))]);
    var all = _interleave(res[0], res[1]);
    // Foreign-language words often have no hits: retry once in English.
    if (all.isEmpty && AppState.I.aiReady && !AppState.I.frontLang.startsWith('en')) {
      try {
        final tr = await Ai.translateLines([q], from: langOf(AppState.I.frontLang).en, to: 'English');
        final en = tr.isNotEmpty ? tr.first.trim() : '';
        if (en.isNotEmpty && en.toLowerCase() != q.toLowerCase()) {
          res = await Future.wait([safe(_openverse(en)), safe(_wikimedia(en))]);
          all = _interleave(res[0], res[1]);
        }
      } catch (_) {}
    }
    return all;
  }

  static List<WebImage> _interleave(List<WebImage> a, List<WebImage> b) {
    final out = <WebImage>[];
    final seen = <String>{};
    for (int i = 0; i < (a.length > b.length ? a.length : b.length); i++) {
      for (final l in [a, b]) {
        if (i < l.length && seen.add(l[i].full)) out.add(l[i]);
      }
    }
    return out;
  }

  static Future<Uint8List?> _get(String url) async {
    try {
      final r = await _hc.get(Uri.parse(url), headers: headers).timeout(const Duration(seconds: 30));
      final ct = r.headers['content-type'] ?? '';
      if (r.statusCode == 200 && ct.startsWith('image') && r.bodyBytes.length > 500) {
        return r.bodyBytes;
      }
    } catch (_) {}
    return null;
  }

  /// Downloads the picture (preview size first, original as a fallback).
  static Future<WebPick?> download(WebImage w) async {
    final b = await _get(w.thumb) ?? (w.full != w.thumb ? await _get(w.full) : null);
    if (b == null) return null;
    return WebPick(b, w.credit);
  }

  /// Picks the first picture that downloads, without any user interaction.
  static Future<WebPick?> auto(String query) async {
    try {
      final list = await search(query);
      for (final w in list.take(4)) {
        final p = await download(w);
        if (p != null) return p;
      }
    } catch (_) {}
    return null;
  }
}

/// Bottom sheet with a search box and a grid of pictures from the web.
Future<WebPick?> showWebImagePicker(BuildContext context, String initial) {
  return showModalBottomSheet<WebPick>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: C.cream,
    shape: RoundedRectangleBorder(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      side: BorderSide(color: C.ink, width: 3),
    ),
    builder: (_) => _WebPicker(initial),
  );
}

class _WebPicker extends StatefulWidget {
  final String initial;
  const _WebPicker(this.initial);
  @override
  State<_WebPicker> createState() => _WebPickerState();
}

class _WebPickerState extends State<_WebPicker> {
  late final TextEditingController q = TextEditingController(text: widget.initial);
  List<WebImage> items = [];
  bool loading = false;
  bool searched = false;
  bool picking = false;
  String? error;

  @override
  void initState() {
    super.initState();
    if (widget.initial.trim().isNotEmpty) _search();
  }

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final text = q.text.trim();
    if (text.isEmpty || loading) return;
    FocusScope.of(context).unfocus();
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = await WebImages.search(text);
      if (!mounted) return;
      setState(() {
        items = r;
        searched = true;
      });
    } catch (_) {
      if (mounted) setState(() => error = t('web_failed'));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _choose(WebImage w) async {
    if (picking) return;
    Sfx.play('tap');
    setState(() => picking = true);
    final p = await WebImages.download(w);
    if (!mounted) return;
    if (p == null) {
      setState(() => picking = false);
      toast(context, t('web_failed'));
      return;
    }
    Sfx.play('ok');
    Navigator.of(context).pop(p);
  }

  @override
  Widget build(BuildContext context) {
    final inset = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(bottom: inset),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.82,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 48,
                  height: 6,
                  decoration: BoxDecoration(
                    color: C.ink,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              PixelTitle(t('web_image')),
              Row(
                children: [
                  Expanded(
                    child: PixelField(
                      controller: q,
                      hint: t('web_search_hint'),
                      onSubmitted: (_) => _search(),
                    ),
                  ),
                  const SizedBox(width: 10),
                  PixelButton(
                    icon: 'search',
                    small: true,
                    busy: loading,
                    onTap: _search,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(child: _grid()),
              const SizedBox(height: 6),
              Center(child: tx(t('web_credit_note'), size: 11, color: C.gray, align: TextAlign.center)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _grid() {
    if (loading) return const Center(child: PixelLoader());
    if (error != null) return Center(child: tx(error!, bold: true, align: TextAlign.center));
    if (items.isEmpty) {
      return Center(
        child: tx(searched ? t('no_web_results') : t('web_search_hint'),
            bold: true, color: C.gray, align: TextAlign.center),
      );
    }
    return Stack(
      children: [
        GridView.builder(
          padding: const EdgeInsets.only(right: 6, bottom: 6),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: items.length,
          itemBuilder: (_, i) {
            final w = items[i];
            return GestureDetector(
              onTap: () => _choose(w),
              child: PixelBox(
                u: 2,
                padding: const EdgeInsets.all(2),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox.expand(
                    child: Image.network(
                      w.thumb,
                      headers: WebImages.headers,
                      fit: BoxFit.cover,
                      loadingBuilder: (c, child, p) =>
                          p == null ? child : ColoredBox(color: C.creamDeep),
                      errorBuilder: (_, __, ___) => ColoredBox(
                        color: C.creamDeep,
                        child: Center(child: tx('✖', color: C.gray)),
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
        if (picking)
          Positioned.fill(
            child: ColoredBox(
              color: C.cream.withOpacity(0.7),
              child: const Center(child: PixelLoader()),
            ),
          ),
      ],
    );
  }
}
