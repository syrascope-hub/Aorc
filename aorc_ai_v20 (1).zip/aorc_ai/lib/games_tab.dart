import 'dart:math';

import 'package:flutter/material.dart';

import 'cards_tab.dart';
import 'rich.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'games2.dart';
import 'pic_game.dart';
import 'word_rain.dart';
import 'decks.dart';

class GamesTab extends StatelessWidget {
  const GamesTab({super.key});

  void _open(BuildContext context, int need, Widget page) {
    final n = AppState.I.scope.length;
    if (n < need) {
      toast(context, '${t('need_cards_n')} $need (${t('you_have')} $n)');
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    Widget tile(String icon, String title, String desc, VoidCallback onTap) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Sfx.play('tap');
            onTap();
          },
          child: PixelBox(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                PixelBox(
                  color: C.cream,
                  u: 2,
                  shadow: false,
                  padding: const EdgeInsets.all(8),
                  child: Sprite(icon, px: 4),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      tx(title, size: 16, bold: true),
                      const SizedBox(height: 3),
                      tx(desc, size: 12.5, color: C.dark, height: 1.35),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Padding(padding: EdgeInsets.only(bottom: 10), child: DeckBar()),
        tile('image', t('g_pic'), t('g_pic_d'), () {
          if (AppState.I.scope.length < 4) {
            toast(context, '${t('need_cards_n')} 4 (${t('you_have')} ${AppState.I.scope.length})');
            return;
          }
          final n = AppState.I.scope.where((c) => c.image != null).length;
          if (n < 3) {
            toast(context, '${t('need_images_n')} 3 (${t('you_have')} $n)');
            return;
          }
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PicGame()));
        }),
        tile('games', t('g_choice'), t('g_choice_d'), () => _open(context, 4, const McqGame())),
        tile('cards', t('g_match'), t('g_match_d'), () => _open(context, 3, const MatchGame())),
        tile('create', t('g_type'), t('g_type_d'), () => _open(context, 1, const TypeGame())),
        tile('stories', t('g_story'), t('g_story_d'), () => _open(context, 3, const VocabStoryPage())),
        tile('heart', t('g_survival'), t('g_survival_d'), () => _open(context, 4, const SurvivalGame())),
        tile('bolt', t('g_speed'), t('g_speed_d'), () => _open(context, 4, const SpeedGame())),
        tile('skull', t('g_boss'), t('g_boss_d'), () => _open(context, 4, const BossGame())),
        tile('summary', t('g_cloze'), t('g_cloze_d'), () => _open(context, 3, const ClozeGame())),
        tile('dice', t('g_scramble'), t('g_scramble_d'), () => _open(context, 3, const ScrambleGame())),
        tile('games', t('g_rain'), t('g_rain_d'), () => _open(context, 4, const WordRainGame())),
      ],
    );
  }
}

// ───────────────────────── shared result view ─────────────────────────

Widget _gameOver(BuildContext context, String line, VoidCallback again) {
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Sprite('robot', px: 8),
          const SizedBox(height: 18),
          tx(t('game_over'), size: 22, bold: true),
          const SizedBox(height: 8),
          tx(line, size: 18, bold: true, align: TextAlign.center, height: 1.5),
          const SizedBox(height: 20),
          PixelButton(label: t('play_again'), icon: 'games', onTap: again),
          const SizedBox(height: 10),
          PixelButton(
            label: t('back'),
            filled: false,
            onTap: () => Navigator.of(context).maybePop(),
          ),
        ],
      ),
    ),
  );
}

Widget _hearts(int lives, int max) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      for (int i = 0; i < max; i++)
        Padding(
          padding: const EdgeInsets.only(left: 3, right: 3),
          child: Sprite('heart', px: 3, tint: i < lives ? C.ink : C.light),
        ),
    ],
  );
}

// ───────────────────────── multiple choice ─────────────────────────

class McqGame extends StatefulWidget {
  const McqGame({super.key});
  @override
  State<McqGame> createState() => _McqGameState();
}

class _McqGameState extends State<McqGame> {
  final _r = Random();
  late List<CardItem> order;
  int i = 0, score = 0, lives = 3;
  bool fwd = true;
  bool over = false;
  late List<String> options;
  late String correct;
  String? picked;

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    final pool = List<CardItem>.of(s.scope)..shuffle();
    order = pool.take(10).toList();
    i = 0;
    score = 0;
    lives = 3;
    over = false;
    _make();
  }

  void _make() {
    final c = order[i];
    fwd = _r.nextBool();
    correct = fwd ? c.back : c.front;
    final others = s.scope
        .where((x) => x.id != c.id)
        .map((x) => fwd ? x.back : x.front)
        .where((x) => x != correct)
        .toSet()
        .toList()
      ..shuffle();
    options = [correct, ...others.take(3)]..shuffle();
    picked = null;
  }

  void _pick(String o) {
    if (picked != null) return;
    final ok = o == correct;
    setState(() {
      picked = o;
      if (ok) {
        score++;
      } else {
        lives--;
      }
    });
    Sfx.play(ok ? 'ok' : 'bad');
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      setState(() {
        if (lives <= 0 || i + 1 >= order.length) {
          over = true;
          Sfx.play('win');
        } else {
          i++;
          _make();
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      games: true,
      title: t('g_choice'),
      child: over
          ? _gameOver(context, '${t('score')}: $score / ${order.length}', () => setState(_start))
          : _body(),
    );
  }

  Widget _body() {
    final c = order[i];
    final prompt = fwd ? c.front : c.back;
    final lang = fwd ? s.frontLang : s.backLang;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            tx('${i + 1} / ${order.length}', bold: true, color: C.gray),
            const Spacer(),
            const Sprite('star', px: 2.5),
            const SizedBox(width: 4),
            tx('$score', bold: true, size: 16),
            const SizedBox(width: 14),
            _hearts(lives, 3),
          ],
        ),
        const SizedBox(height: 14),
        PixelBox(
          padding: const EdgeInsets.all(18),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                if (fwd && c.image != null) ...[
                  cardImage(c.image, 100),
                  const SizedBox(height: 12),
                ],
                tx(prompt, size: 26, bold: true, align: TextAlign.center, height: 1.3),
                const SizedBox(height: 12),
                SpeakBtn(prompt, lang),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        for (final o in options)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _option(o),
          ),
      ],
    );
  }

  Widget _option(String o) {
    Color bg = C.white;
    Color fg = C.ink;
    String mark = '';
    if (picked != null) {
      if (o == correct) {
        bg = C.ink;
        fg = C.cream;
        mark = '✔ ';
      } else if (o == picked) {
        bg = C.light;
        fg = C.dark;
        mark = '✖ ';
      }
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _pick(o),
      child: SizedBox(
        width: double.infinity,
        child: PixelBox(
          color: bg,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          child: Text(
            '$mark$o',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: fg),
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── matching ─────────────────────────

class MatchGame extends StatefulWidget {
  const MatchGame({super.key});
  @override
  State<MatchGame> createState() => _MatchGameState();
}

class _MatchGameState extends State<MatchGame> {
  late List<CardItem> pairs;
  late List<CardItem> left;
  late List<CardItem> right;
  String? selL, selR;
  final Set<String> matched = {};
  int errors = 0;
  bool done = false;
  Stopwatch sw = Stopwatch();

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    final pool = List<CardItem>.of(s.scope)..shuffle();
    pairs = pool.take(min(6, pool.length)).toList();
    left = List<CardItem>.of(pairs)..shuffle();
    right = List<CardItem>.of(pairs)..shuffle();
    selL = null;
    selR = null;
    matched.clear();
    errors = 0;
    done = false;
    sw = Stopwatch()..start();
  }

  void _tap(bool isLeft, CardItem c) {
    if (matched.contains(c.id) || done) return;
    Sfx.play('tap');
    setState(() {
      if (isLeft) {
        selL = selL == c.id ? null : c.id;
        Speech.speak(c.front, s.frontLang);
      } else {
        selR = selR == c.id ? null : c.id;
      }
    });
    if (selL != null && selR != null) {
      if (selL == selR) {
        Sfx.play('ok');
        setState(() {
          matched.add(selL!);
          selL = null;
          selR = null;
          if (matched.length == pairs.length) {
            done = true;
            sw.stop();
            Sfx.play('win');
          }
        });
      } else {
        Sfx.play('bad');
        errors++;
        Future.delayed(const Duration(milliseconds: 450), () {
          if (mounted) {
            setState(() {
              selL = null;
              selR = null;
            });
          }
        });
      }
    }
  }

  Widget _item(bool isLeft, CardItem c) {
    final isMatched = matched.contains(c.id);
    final sel = (isLeft ? selL : selR) == c.id;
    final bg = isMatched ? C.light : (sel ? C.ink : C.white);
    final fg = isMatched ? C.gray : (sel ? C.cream : C.ink);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _tap(isLeft, c),
        child: SizedBox(
          width: double.infinity,
          child: PixelBox(
            color: bg,
            flat: isMatched,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
            child: Text(
              isLeft ? c.front : c.back,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: fg),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      games: true,
      title: t('g_match'),
      child: done
          ? _gameOver(
              context,
              '${t('time')}: ${sw.elapsed.inSeconds}s\n${t('mistakes')}: $errors',
              () => setState(_start),
            )
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                tx(t('match_help'), size: 13, color: C.dark, align: TextAlign.center),
                const SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: Column(children: [for (final c in left) _item(true, c)])),
                    const SizedBox(width: 12),
                    Expanded(child: Column(children: [for (final c in right) _item(false, c)])),
                  ],
                ),
              ],
            ),
    );
  }
}

// ───────────────────────── typing ─────────────────────────

class TypeGame extends StatefulWidget {
  const TypeGame({super.key});
  @override
  State<TypeGame> createState() => _TypeGameState();
}

class _TypeGameState extends State<TypeGame> {
  late List<CardItem> order;
  final ctl = TextEditingController();
  int i = 0, score = 0;
  bool checked = false;
  bool ok = false;
  bool over = false;

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  void _start() {
    final pool = List<CardItem>.of(s.scope)..shuffle();
    order = pool.take(10).toList();
    i = 0;
    score = 0;
    checked = false;
    over = false;
    ctl.clear();
  }

  String _norm(String x) => x
      .toLowerCase()
      .replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  void _check() {
    if (checked) return;
    final c = order[i];
    final good = _norm(ctl.text) == _norm(c.front);
    setState(() {
      checked = true;
      ok = good;
      if (good) score++;
    });
    Sfx.play(good ? 'ok' : 'bad');
    Speech.speak(c.front, s.frontLang);
  }

  void _next() {
    setState(() {
      if (i + 1 >= order.length) {
        over = true;
        Sfx.play('win');
      } else {
        i++;
        checked = false;
        ctl.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      games: true,
      title: t('g_type'),
      child: over
          ? _gameOver(context, '${t('score')}: $score / ${order.length}', () => setState(_start))
          : _body(),
    );
  }

  Widget _body() {
    final c = order[i];
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            tx('${i + 1} / ${order.length}', bold: true, color: C.gray),
            const Spacer(),
            const Sprite('star', px: 2.5),
            const SizedBox(width: 4),
            tx('$score', bold: true, size: 16),
          ],
        ),
        const SizedBox(height: 14),
        PixelBox(
          padding: const EdgeInsets.all(18),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                if (c.image != null) ...[
                  cardImage(c.image, 100),
                  const SizedBox(height: 12),
                ],
                tx(c.back, size: 26, bold: true, align: TextAlign.center, height: 1.3),
                const SizedBox(height: 12),
                SpeakBtn(c.front, s.frontLang),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        tx('${t('type_it')} (${langName(s.frontLang)})', size: 13, color: C.dark),
        const SizedBox(height: 6),
        PixelField(
          controller: ctl,
          hint: t('your_answer'),
          onSubmitted: (_) => _check(),
        ),
        const SizedBox(height: 14),
        if (checked) ...[
          PixelBox(
            color: ok ? C.ink : C.light,
            child: SizedBox(
              width: double.infinity,
              child: Text(
                ok ? '✔ ${c.front}' : '✖ ${c.front}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: ok ? C.cream : C.ink,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          PixelButton(label: t('next'), expand: true, onTap: _next),
        ] else
          PixelButton(label: t('check'), icon: 'check', expand: true, onTap: _check),
      ],
    );
  }
}

// ───────────────────────── story from vocabulary ─────────────────────────

class VocabStoryPage extends StatefulWidget {
  const VocabStoryPage({super.key});
  @override
  State<VocabStoryPage> createState() => _VocabStoryPageState();
}

class _VocabStoryPageState extends State<VocabStoryPage> {
  int count = 6;
  String level = 'A2';
  String? story;
  String title = '';
  List<CardItem> used = [];
  bool busy = false;

  AppState get s => AppState.I;

  Future<void> _gen() async {
    final pool = List<CardItem>.of(s.scope)..shuffle();
    used = pool.take(min(count, pool.length)).toList();
    final lang = langOf(s.frontLang).en;
    final words = used.map((c) => c.front).join(', ');
    setState(() => busy = true);
    try {
      final reply = await Ai.chat(
        'Write a short, fun and coherent story (about 150 words) in $lang at CEFR level $level. '
        'Use ALL of these words naturally: $words. '
        'Wrap each of those words, as used in the text, in double asterisks like **word**. '
        'Output only the story, with a short title on the first line that starts with "# ".',
        system: 'You are a creative storyteller for language learners.',
        maxTokens: 900,
      );
      final parts = splitTitle(reply);
      if (mounted) {
        setState(() {
          title = parts.$1;
          story = parts.$2;
        });
        Sfx.play('ok');
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    if (story == null) return;
    await s.upsertStory(StoryItem(
      id: s.newId(),
      title: title.isEmpty ? t('untitled') : title,
      body: story!.replaceAll('**', ''),
      lang: s.frontLang,
    ));
    if (mounted) toast(context, t('saved_to_stories'));
  }

  void _showWord(CardItem c) {
    Speech.speak(c.front, s.frontLang);
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: C.cream,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: C.ink, width: 3)),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              tx(c.front, size: 24, bold: true),
              const SizedBox(height: 8),
              tx(c.back, size: 20, color: C.dark),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SpeakBtn(c.front, s.frontLang),
                  const SizedBox(width: 8),
                  SpeakBtn(c.back, s.backLang),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      games: true,
      title: t('g_story'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          PixelTitle(t('words_count')),
          PixelChips<int>(
            options: const [(4, '4'), (6, '6'), (8, '8'), (10, '10')],
            value: count,
            onChanged: (v) => setState(() => count = v),
          ),
          PixelTitle(t('level')),
          PixelChips<String>(
            options: const [('A1', 'A1'), ('A2', 'A2'), ('B1', 'B1'), ('B2', 'B2'), ('C1', 'C1')],
            value: level,
            onChanged: (v) => setState(() => level = v),
          ),
          const SizedBox(height: 16),
          PixelButton(
            label: story == null ? t('make_story') : t('regenerate'),
            icon: 'sparkle',
            expand: true,
            busy: busy,
            onTap: _gen,
          ),
          if (story != null) ...[
            const SizedBox(height: 16),
            PixelBox(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (title.isNotEmpty) ...[
                      tx(title, size: 20, bold: true),
                      const SizedBox(height: 10),
                    ],
                    Directionality(
                      textDirection: langOf(s.frontLang).code.startsWith('ar')
                          ? TextDirection.rtl
                          : TextDirection.ltr,
                      child: RichMath(story!, size: 16),
                    ),
                  ],
                ),
              ),
            ),
            PixelTitle(t('story_words')),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in used)
                  GestureDetector(
                    onTap: () => _showWord(c),
                    child: PixelBox(
                      u: 2,
                      shadow: false,
                      color: C.creamDeep,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      child: tx(c.front, size: 13, bold: true),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: t('listen'),
                    icon: 'speaker',
                    filled: false,
                    onTap: () => Speech.speak(story!, s.frontLang),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PixelButton(label: t('save_story'), icon: 'check', onTap: _save),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
