import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';

import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

const Color _kKnow = Color(0xFF22B573);
const Color _kMiss = Color(0xFFFF4D6D);

/// A flash card that flips in 3D when tapped and flies away when swiped:
/// right = "knew it", left = "missed it". The parent owns the flipped state.
class SwipeFlipCard extends StatefulWidget {
  final Widget Function(bool back) face;
  final bool flipped;
  final VoidCallback onFlip;
  final Future<void> Function(bool know)? onSwipe; // null disables swiping
  const SwipeFlipCard({
    super.key,
    required this.face,
    required this.flipped,
    required this.onFlip,
    this.onSwipe,
  });

  @override
  State<SwipeFlipCard> createState() => _SwipeFlipCardState();
}

class _SwipeFlipCardState extends State<SwipeFlipCard> {
  static const double _threshold = 110;
  double _dx = 0;
  bool _dragging = false;
  bool _armed = false;
  bool _leaving = false;

  void _update(DragUpdateDetails d) {
    if (widget.onSwipe == null || _leaving) return;
    setState(() {
      _dragging = true;
      _dx += d.delta.dx;
    });
    final armed = _dx.abs() > _threshold;
    if (armed != _armed) {
      _armed = armed;
      if (armed) Sfx.play('tick');
    }
  }

  Future<void> _end(DragEndDetails d) async {
    if (widget.onSwipe == null || _leaving) return;
    final v = d.primaryVelocity ?? 0;
    final go = _dx.abs() > _threshold || (v.abs() > 900 && _dx.abs() > 30);
    if (!go) {
      setState(() {
        _dragging = false;
        _dx = 0;
        _armed = false;
      });
      return;
    }
    final know = (_dx != 0 ? _dx : v) > 0;
    final w = MediaQuery.of(context).size.width;
    Sfx.play('swipe');
    setState(() {
      _leaving = true;
      _dragging = false;
      _dx = know ? w * 1.3 : -w * 1.3;
    });
    await Future<void>.delayed(const Duration(milliseconds: 220));
    if (!mounted) return;
    await widget.onSwipe!(know);
    if (!mounted) return;
    setState(() {
      _leaving = false;
      _dragging = true;
      _dx = 0;
      _armed = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = (_dx.abs() / _threshold).clamp(0.0, 1.0);
    final know = _dx > 0;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (_leaving) return;
        Sfx.play('flip');
        widget.onFlip();
      },
      onHorizontalDragUpdate: widget.onSwipe == null ? null : _update,
      onHorizontalDragEnd: widget.onSwipe == null ? null : _end,
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(end: _dx),
        duration: _dragging ? Duration.zero : const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
        builder: (context, dx, child) => Transform.translate(
          offset: Offset(dx, 0),
          child: Transform.rotate(angle: dx / 1400, child: child),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: widget.flipped ? pi : 0),
              duration: const Duration(milliseconds: 520),
              curve: Curves.easeOutBack,
              builder: (context, a, _) {
                final showBack = a > pi / 2;
                // The card rises and tilts a little while it turns.
                final lift = sin(a.clamp(0.0, pi));
                return Transform.scale(
                  scale: 1 + 0.07 * lift,
                  child: Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.0013)
                      ..rotateX(-0.1 * lift)
                      ..rotateY(a),
                    child: showBack
                        ? Transform(
                            alignment: Alignment.center,
                            transform: Matrix4.identity()..rotateY(pi),
                            child: widget.face(true),
                          )
                        : widget.face(false),
                  ),
                );
              },
            ),
            if (p > 0.05)
              Positioned(
                top: 18,
                left: know ? 18 : null,
                right: know ? null : 18,
                child: Opacity(
                  opacity: p,
                  child: Transform.rotate(
                    angle: know ? -0.18 : 0.18,
                    child: PixelBox(
                      u: 2,
                      color: know ? _kKnow : _kMiss,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      child: Text(
                        know ? t('swipe_know') : t('swipe_dont'),
                        style: dispStyle(22, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

const List<Color> _levelColors = [
  Color(0xFF9A9A9A),
  Color(0xFFE63946),
  Color(0xFFF4A261),
  Color(0xFFE9C46A),
  Color(0xFF7BC96F),
  Color(0xFF2EC4B6),
];

/// Six blocks that fill with a level color as the card is mastered.
Widget levelBar(CardItem c) {
  final lv = c.box.clamp(0, 5);
  final col = _levelColors[lv];
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      for (int i = 0; i < 6; i++)
        Container(
          width: 18,
          height: 9,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: i <= lv && !(lv == 0 && i > 0) ? col : C.light,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(color: C.ink, width: 2),
          ),
        ),
    ],
  );
}

/// Front or back of a flash card (shared by the study view and the review).
class CardFace extends StatelessWidget {
  final CardItem card;
  final bool back;
  final bool showLevel;
  final double height;
  const CardFace(this.card, {super.key, required this.back, this.showLevel = true, this.height = 400});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final c = card;
    final hasImg = c.image != null;
    final imgFirst = s.imageFirst && hasImg;
    final fg = back ? onAccent() : C.ink;
    final sub = back ? onAccent().withOpacity(0.75) : C.gray;
    final mainText = back ? c.back : (imgFirst ? t('guess_word') : c.front);
    final lang = back ? s.backLang : s.frontLang;
    return SizedBox(
      height: height,
      child: PixelBox(
        color: back ? C.accent : C.white,
        padding: const EdgeInsets.all(14),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (showLevel) levelBar(c),
              if (showLevel) const SizedBox(height: 10),
              if (!back && hasImg)
                PixelBox(
                  u: 2,
                  padding: const EdgeInsets.all(3),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: Image.file(
                      File(c.image!),
                      width: double.infinity,
                      height: imgFirst ? 210 : 150,
                      fit: BoxFit.cover,
                      filterQuality: FilterQuality.medium,
                      errorBuilder: (_, __, ___) =>
                          SizedBox(height: imgFirst ? 210 : 150, width: double.infinity),
                    ),
                  ),
                ),
              if (!back && hasImg) const SizedBox(height: 12),
              if (back && imgFirst) ...[
                Text(
                  c.front,
                  textAlign: TextAlign.center,
                  style: dispStyle(26, color: sub, height: 1.2),
                ),
                const SizedBox(height: 6),
              ],
              Flexible(
                child: SingleChildScrollView(
                  child: Text(
                    mainText,
                    textAlign: TextAlign.center,
                    style: (!back && imgFirst)
                        ? dispStyle(26, color: sub, height: 1.2)
                        : dispStyle(back && imgFirst ? 34 : 38, color: fg, height: 1.15),
                  ),
                ),
              ),
              if (back && (c.example ?? '').isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  c.example!,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: sub, fontWeight: FontWeight.w700),
                ),
              ],
              if (back && hasImg && (c.credit ?? '').isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  '${t('img_credit')}: ${c.credit}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.ltr,
                  style: TextStyle(fontSize: 10, color: sub, fontWeight: FontWeight.w600),
                ),
              ],
              const SizedBox(height: 12),
              if (!(imgFirst && !back)) SpeakBtn(back ? c.back : c.front, lang, big: true),
              const SizedBox(height: 8),
              Text(
                t('swipe_hint'),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 10.5, color: sub, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
