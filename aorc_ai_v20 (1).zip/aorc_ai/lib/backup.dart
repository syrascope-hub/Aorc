import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Minimal CSV/TSV parser (quotes supported).
List<List<String>> parseDelimited(String text, String delim) {
  final rows = <List<String>>[];
  var row = <String>[];
  final sb = StringBuffer();
  bool q = false;
  for (int i = 0; i < text.length; i++) {
    final ch = text[i];
    if (q) {
      if (ch == '"') {
        if (i + 1 < text.length && text[i + 1] == '"') {
          sb.write('"');
          i++;
        } else {
          q = false;
        }
      } else {
        sb.write(ch);
      }
    } else if (ch == '"' && sb.isEmpty) {
      q = true;
    } else if (ch == delim) {
      row.add(sb.toString());
      sb.clear();
    } else if (ch == '\n' || ch == '\r') {
      if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++;
      row.add(sb.toString());
      sb.clear();
      if (row.any((e) => e.trim().isNotEmpty)) rows.add(row);
      row = <String>[];
    } else {
      sb.write(ch);
    }
  }
  row.add(sb.toString());
  if (row.any((e) => e.trim().isNotEmpty)) rows.add(row);
  return rows;
}

String _stripHtml(String s) => s
    .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), ' ')
    .replaceAll(RegExp(r'<[^>]*>'), '')
    .replaceAll('&nbsp;', ' ')
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();

/// Parses CSV / TSV / Anki text export into [front, back, example] rows.
List<List<String>> parseCardsFile(String raw) {
  var text = raw;
  if (text.startsWith('﻿')) text = text.substring(1);
  final lines = text.split('\n').where((l) => !l.startsWith('#')).toList();
  final body = lines.join('\n');
  final first = lines.firstWhere((l) => l.trim().isNotEmpty, orElse: () => '');
  String delim = '\t';
  if (!first.contains('\t')) {
    final commas = ','.allMatches(first).length;
    final semis = ';'.allMatches(first).length;
    delim = semis > commas ? ';' : ',';
  }
  final out = <List<String>>[];
  for (final r in parseDelimited(body, delim)) {
    if (r.length < 2) continue;
    final f = _stripHtml(r[0]);
    final b = _stripHtml(r[1]);
    if (f.isEmpty || b.isEmpty) continue;
    out.add([f, b, r.length > 2 ? _stripHtml(r[2]) : '']);
  }
  return out;
}

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});
  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  AppState get s => AppState.I;
  bool busy = false;
  List<List<String>> csvRows = [];
  String csvName = '';

  String _stamp() {
    final n = DateTime.now();
    return '${n.year}${n.month.toString().padLeft(2, '0')}${n.day.toString().padLeft(2, '0')}';
  }

  Future<void> _export() async {
    setState(() => busy = true);
    try {
      final data = await s.exportData();
      final bytes = Uint8List.fromList(utf8.encode(jsonEncode(data)));
      final path = await FilePicker.platform.saveFile(
        dialogTitle: t('backup_export'),
        fileName: 'aorc_backup_${_stamp()}.json',
        bytes: bytes,
      );
      if (mounted) toast(context, path == null ? t('cancelled') : t('saved'));
    } catch (e) {
      if (mounted) toast(context, '${t('net_error')}: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _import() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
      final f = r?.files.single;
      if (f == null || f.bytes == null) return;
      final j = jsonDecode(utf8.decode(f.bytes!, allowMalformed: true));
      if (j is! Map) throw const FormatException('bad');
      if (!mounted) return;
      final replace = await showDialog<bool>(
        context: context,
        builder: (ctx) => Dialog(
          backgroundColor: C.cream,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: C.ink, width: 3)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                tx(t('backup_mode'), size: 16, bold: true, align: TextAlign.center, height: 1.4),
                const SizedBox(height: 14),
                PixelButton(
                    label: t('backup_merge'),
                    expand: true,
                    onTap: () => Navigator.pop(ctx, false)),
                const SizedBox(height: 8),
                PixelButton(
                    label: t('backup_replace'),
                    expand: true,
                    filled: false,
                    onTap: () => Navigator.pop(ctx, true)),
              ],
            ),
          ),
        ),
      );
      if (replace == null) return;
      setState(() => busy = true);
      final n = await s.importData(Map<String, dynamic>.from(j), replace: replace);
      if (mounted) toast(context, '${t('cards_added')}: $n');
    } catch (_) {
      if (mounted) toast(context, t('backup_bad'));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _pickCsv() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
      final f = r?.files.single;
      if (f == null || f.bytes == null) return;
      final rows = parseCardsFile(utf8.decode(f.bytes!, allowMalformed: true));
      setState(() {
        csvRows = rows;
        csvName = f.name;
      });
      if (rows.isEmpty && mounted) toast(context, t('csv_empty'));
    } catch (_) {
      if (mounted) toast(context, t('csv_empty'));
    }
  }

  Future<void> _addCsv() async {
    final list = [
      for (final r in csvRows)
        CardItem(
          id: s.newId(),
          front: r[0],
          back: r[1],
          example: r[2].isEmpty ? null : r[2],
        ),
    ];
    await s.addCards(list);
    Sfx.play('ok');
    if (mounted) {
      toast(context, '${t('cards_added')}: ${list.length}');
      setState(() => csvRows = []);
    }
  }

  Future<void> _exportCsv() async {
    final sb = StringBuffer();
    String q(String x) => '"${x.replaceAll('"', '""')}"';
    for (final c in s.scope) {
      sb.writeln('${q(c.front)},${q(c.back)},${q(c.example ?? '')}');
    }
    final bytes = Uint8List.fromList(utf8.encode(sb.toString()));
    try {
      final path = await FilePicker.platform.saveFile(
        dialogTitle: t('csv_export'),
        fileName: 'aorc_cards_${_stamp()}.csv',
        bytes: bytes,
      );
      if (mounted) toast(context, path == null ? t('cancelled') : t('saved'));
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: sb.toString()));
      if (mounted) toast(context, t('copied'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('backup'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('backup_help')),
          PixelTitle(t('backup_full')),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: t('backup_export'),
                  icon: 'save',
                  busy: busy,
                  expand: true,
                  onTap: _export,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: PixelButton(
                  label: t('backup_import'),
                  icon: 'folder',
                  filled: false,
                  expand: true,
                  onTap: busy ? null : _import,
                ),
              ),
            ],
          ),
          PixelTitle(t('csv_title')),
          tx(t('csv_help'), size: 13, color: C.dark, height: 1.45),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: t('csv_pick'),
                  icon: 'cards',
                  filled: false,
                  expand: true,
                  onTap: _pickCsv,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: PixelButton(
                  label: t('csv_export'),
                  icon: 'save',
                  filled: false,
                  expand: true,
                  onTap: _exportCsv,
                ),
              ),
            ],
          ),
          if (csvRows.isNotEmpty) ...[
            const SizedBox(height: 10),
            tx('$csvName · ${t('detected')}: ${csvRows.length}', bold: true, size: 13, color: C.gray),
            const SizedBox(height: 6),
            for (final r in csvRows.take(5))
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: tx('${r[0]}  →  ${r[1]}', size: 13),
              ),
            const SizedBox(height: 10),
            PixelButton(
              label: '${t('create_cards')} (${csvRows.length})',
              icon: 'create',
              expand: true,
              onTap: _addCsv,
            ),
          ],
        ],
      ),
    );
  }
}
