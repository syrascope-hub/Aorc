import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';

import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Picture quiz: a picture appears and the player picks the matching word.
class PicGame extends StatefulWidget {
  const PicGame({super.key});
  @override
  State<PicGame> createState() => _PicGameState();
}

class _PicGameState extends State<PicGame> {
  final _r = Random();
  late List<CardItem> order;
  int i = 0, score = 0, lives = 3;
  bool over = false;
  late List<String> options;
  late String correct;
  String? picked;

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    final pool = s.scope.where((c) => c.image != null && File(c.image!).existsSync()).toList()
      ..shuffle();
    order = pool.take(10).toList();
    i = 0;
    score = 0;
    lives = 3;
    over = false;
    if (order.isEmpty) {
      over = true;
    } else {
      _make();
    }
  }

  void _make() {
    final c = order[i];
    correct = c.front;
    final others = s.scope
        .where((x) => x.id != c.id && x.front != correct)
        .map((x) => x.front)
        .toSet()
        .toList()
      ..shuffle(_r);
    options = [correct, ...others.take(3)]..shuffle(_r);
    picked = null;
  }

  void _pick(String o) {
    if (picked != null) return;
    final ok = o == correct;
    setState(() {
      picked = o;
      if (ok) {
        score++;
      } else {
        lives--;
      }
    });
    Sfx.play(ok ? 'ok' : 'bad');
    if (ok) Speech.speak(order[i].front, s.frontLang);
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      setState(() {
        if (lives <= 0 || i + 1 >= order.length) {
          over = true;
          Sfx.play('win');
        } else {
          i++;
          _make();
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      games: true,
      title: t('g_pic'),
      child: over ? _gameOver() : _body(),
    );
  }

  Widget _gameOver() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('trophy', px: 8),
            const SizedBox(height: 18),
            Text(t('game_over'), style: dispStyle(32)),
            const SizedBox(height: 8),
            tx('${t('score')}: $score / ${order.length}',
                size: 18, bold: true, align: TextAlign.center, height: 1.5),
            const SizedBox(height: 20),
            PixelButton(
              label: t('play_again'),
              icon: 'games',
              onTap: () => setState(_start),
            ),
            const SizedBox(height: 10),
            PixelButton(
              label: t('back'),
              filled: false,
              onTap: () => Navigator.of(context).maybePop(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    final c = order[i];
    final done = picked != null;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            tx('${i + 1} / ${order.length}', bold: true, color: C.gray),
            const Spacer(),
            const Sprite('star', px: 2.5),
            const SizedBox(width: 4),
            tx('$score', bold: true, size: 16),
            const SizedBox(width: 14),
            for (int h = 0; h < 3; h++)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Sprite('heart', px: 3, tint: h < lives ? C.ink : C.light),
              ),
          ],
        ),
        const SizedBox(height: 14),
        PixelBox(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(c.image!),
                  width: double.infinity,
                  height: 230,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      const SizedBox(height: 230, width: double.infinity),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                done ? c.back : t('guess_word'),
                textAlign: TextAlign.center,
                style: dispStyle(24, color: done ? C.ink : C.gray),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        for (final o in options)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _option(o),
          ),
      ],
    );
  }

  Widget _option(String o) {
    Color bg = C.white;
    Color fg = C.ink;
    String mark = '';
    if (picked != null) {
      if (o == correct) {
        bg = const Color(0xFF22B573);
        fg = Colors.white;
        mark = '✔ ';
      } else if (o == picked) {
        bg = const Color(0xFFFF4D6D);
        fg = Colors.white;
        mark = '✖ ';
      }
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _pick(o),
      child: SizedBox(
        width: double.infinity,
        child: PixelBox(
          color: bg,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          child: Text(
            '$mark$o',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: fg),
          ),
        ),
      ),
    );
  }
}
