import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'fx.dart';
import 'providers.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'tts_engines.dart';
import 'backup.dart';
import 'common.dart';
import 'voice_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  AppState get s => AppState.I;
  late final TextEditingController token = TextEditingController(text: s.hfToken);
  late final TextEditingController baseUrl = TextEditingController(text: s.aiBaseUrl);
  late final TextEditingController imageKey = TextEditingController(text: s.imageKey);
  late final TextEditingController textModel = TextEditingController(text: s.textModel);
  late final TextEditingController imageModel = TextEditingController(text: s.imageModel);
  late final TextEditingController visionModel = TextEditingController(text: s.visionModel);
  bool showToken = false;
  bool testing = false;

  @override
  void dispose() {
    _apply();
    token.dispose();
    baseUrl.dispose();
    imageKey.dispose();
    textModel.dispose();
    imageModel.dispose();
    visionModel.dispose();
    super.dispose();
  }

  void _apply() {
    s.hfToken = token.text.trim();
    s.aiBaseUrl = baseUrl.text.trim();
    s.imageKey = imageKey.text.trim();
    final tm = textModel.text.trim();
    final im = imageModel.text.trim();
    if (tm.isNotEmpty) s.textModel = tm;
    if (im.isNotEmpty) s.imageModel = im;
    final vm = visionModel.text.trim();
    if (vm.isNotEmpty) s.visionModel = vm;
    s.saveSettings();
  }

  Future<void> _pickProvider(String id) async {
    _apply();
    await s.switchProvider(id);
    if (!mounted) return;
    setState(() {
      token.text = s.hfToken;
      baseUrl.text = s.aiBaseUrl;
      textModel.text = s.textModel;
      visionModel.text = s.visionModel;
      imageModel.text = s.imageModel;
      imageKey.text = s.imageKey;
    });
  }

  Widget _themeTile(Pal p) {
    final sel = s.themeId == p.id;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Sfx.play('flip');
        s.setTheme(p.id);
      },
      child: SizedBox(
        width: 96,
        child: PixelBox(
          color: p.cream,
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (final c in [p.ink, p.creamDeep, p.accent, p.white])
                    Container(
                      width: 14,
                      height: 22,
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      decoration: BoxDecoration(
                        color: c,
                        border: Border.all(color: p.ink, width: 1.5),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                (sel ? '✔ ' : '') + (s.uiLang == 'ar' ? p.ar : p.en),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: p.ink),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _testText() async {
    _apply();
    setState(() => testing = true);
    try {
      final r = await Ai.chat('Reply with the single word: OK', maxTokens: 10, temp: 0);
      if (mounted) toast(context, '✔ ${clip(r, 40)}');
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => testing = false);
    }
  }

  String _phrase(String code) =>
      code.startsWith('ar') ? 'مرحباً، هذا اختبار للصوت.' : 'Hello, this is a voice test.';

  Future<void> _copyAll() async {
    final lines = s.cards.map((c) => '${c.front}, ${c.back}').join('\n');
    await Clipboard.setData(ClipboardData(text: lines));
    if (mounted) toast(context, t('copied'));
  }

  Future<void> _importClipboard() async {
    final d = await Clipboard.getData('text/plain');
    final rows = parseCardLines(d?.text ?? '').where((r) => r[1].isNotEmpty).toList();
    if (rows.isEmpty) {
      if (mounted) toast(context, t('need_text'));
      return;
    }
    for (final r in rows) {
      await s.addCard(CardItem(id: s.newId(), front: r[0], back: r[1]));
    }
    if (mounted) toast(context, '${t('cards_added')}: ${rows.length}');
  }

  Future<void> _deleteAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: C.cream,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: C.ink, width: 3)),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              tx(t('confirm_delete_all'), size: 16, bold: true, align: TextAlign.center, height: 1.4),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: PixelButton(
                      label: t('cancel'),
                      filled: false,
                      onTap: () => Navigator.pop(ctx, false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: PixelButton(label: t('delete'), onTap: () => Navigator.pop(ctx, true)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (ok == true) {
      await s.deleteAllCards();
      if (mounted) toast(context, t('deleted'));
    }
  }

  List<(String, String)> get _langOptions =>
      [for (final l in kLangs) (l.code, s.uiLang == 'ar' ? l.ar : l.en)];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => PixelPage(
        title: t('settings'),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 30),
          children: [
            PixelTitle(t('app_language')),
            PixelChips<String>(
              options: const [('ar', 'العربية'), ('en', 'English')],
              value: s.uiLang,
              onChanged: (v) {
                s.uiLang = v;
                s.saveSettings();
              },
            ),
            PixelTitle(t('theme_colors')),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [for (final p in kPalettes) _themeTile(p)],
            ),
            PixelTitle(t('button_size')),
            PixelChips<double>(
              options: [(1.0, t('size_normal')), (1.25, t('size_large')), (1.5, t('size_xlarge'))],
              value: s.btnScale,
              onChanged: (v) => s.setBtnScale(v),
            ),
            const SizedBox(height: 10),
            PixelButton(
              label: t('preview_button'),
              icon: 'star',
              expand: true,
              onTap: () => toast(context, '👍'),
            ),
            PixelTitle(t('ai_section')),
            tx(t('provider'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<String>(
              options: [for (final p in kAiPresets) (p.id, p.label)],
              value: s.aiProvider,
              onChanged: _pickProvider,
            ),
            const SizedBox(height: 8),
            tx(t('provider_help'), size: 12, color: C.dark, height: 1.45),
            const SizedBox(height: 8),
            tx(t('base_url'), size: 12.5, color: C.dark),
            const SizedBox(height: 4),
            PixelField(controller: baseUrl, hint: 'https://.../v1', dir: TextDirection.ltr),
            const SizedBox(height: 8),
            tx(aiNeedsKey(s.aiProvider) ? t('api_key') : t('api_key_opt'),
                size: 12.5, color: C.dark),
            const SizedBox(height: 4),
            PixelField(
              controller: token,
              hint: presetById(s.aiProvider).keyHint,
              obscure: !showToken,
              dir: TextDirection.ltr,
              suffix: GestureDetector(
                onTap: () => setState(() => showToken = !showToken),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(showToken ? '◉' : '○', style: const TextStyle(fontSize: 18)),
                ),
              ),
            ),
            const SizedBox(height: 8),
            tx(t('text_model'), size: 12.5, color: C.dark),
            const SizedBox(height: 4),
            PixelField(controller: textModel, dir: TextDirection.ltr),
            const SizedBox(height: 8),
            tx(t('vision_model'), size: 12.5, color: C.dark),
            const SizedBox(height: 4),
            PixelField(controller: visionModel, dir: TextDirection.ltr),
            const SizedBox(height: 12),
            tx(t('image_service'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<String>(
              options: [
                ('hf', 'Hugging Face'),
                ('openai', t('img_same')),
                ('pollinations', t('img_free')),
                ('none', t('off')),
              ],
              value: s.imageProvider,
              onChanged: (v) => setState(() {
                s.imageProvider = v;
                s.saveSettings();
              }),
            ),
            if (s.imageProvider == 'hf' || s.imageProvider == 'openai') ...[
              const SizedBox(height: 8),
              tx(t('image_model'), size: 12.5, color: C.dark),
              const SizedBox(height: 4),
              PixelField(controller: imageModel, dir: TextDirection.ltr),
            ],
            if (s.imageProvider == 'hf' && s.aiProvider != 'huggingface') ...[
              const SizedBox(height: 8),
              tx(t('image_key'), size: 12.5, color: C.dark),
              const SizedBox(height: 4),
              PixelField(
                controller: imageKey,
                hint: 'hf_...',
                obscure: true,
                dir: TextDirection.ltr,
              ),
            ],
            const SizedBox(height: 12),
            PixelButton(
              label: t('test_ai'),
              icon: 'sparkle',
              expand: true,
              filled: false,
              busy: testing,
              onTap: _testText,
            ),
            PixelTitle(t('card_langs')),
            tx(t('front_lang'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<String>(
              options: _langOptions,
              value: s.frontLang,
              onChanged: (v) {
                s.frontLang = v;
                s.saveSettings();
              },
            ),
            const SizedBox(height: 10),
            tx(t('back_lang'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<String>(
              options: _langOptions,
              value: s.backLang,
              onChanged: (v) {
                s.backLang = v;
                s.saveSettings();
              },
            ),
            PixelTitle(t('voice')),
            PixelChips<String>(
              options: [for (final e in kTtsEngines) (e.id, t('engine_${e.id}'))],
              value: s.ttsEngine,
              onChanged: (v) {
                s.ttsEngine = v;
                s.saveSettings();
                Speech.invalidate();
              },
            ),
            const SizedBox(height: 6),
            tx(t('engine_${s.ttsEngine}_note'),
                size: 12, color: C.dark, height: 1.4),
            const SizedBox(height: 10),
            tx(t('speech_rate'), size: 12.5, color: C.dark),
            SliderTheme(
              data: SliderThemeData(
                trackHeight: 8,
                activeTrackColor: C.ink,
                inactiveTrackColor: C.light,
                thumbColor: C.ink,
                trackShape: const RectangularSliderTrackShape(),
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9),
                overlayShape: SliderComponentShape.noOverlay,
              ),
              child: Slider(
                value: s.speechRate,
                min: 0.2,
                max: 0.9,
                onChanged: (v) => setState(() => s.speechRate = v),
                onChangeEnd: (_) => s.saveSettings(),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: t('test_front'),
                    icon: 'speaker',
                    small: true,
                    filled: false,
                    onTap: () => Speech.speak(_phrase(s.frontLang), s.frontLang),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PixelButton(
                    label: t('test_back'),
                    icon: 'speaker',
                    small: true,
                    filled: false,
                    onTap: () => Speech.speak(_phrase(s.backLang), s.backLang),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            PixelButton(
              label: t('voice_open'),
              icon: 'speaker',
              expand: true,
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => const VoiceScreen())),
            ),
            PixelTitle(t('sound_fx')),
            PixelChips<bool>(
              options: [(true, t('on')), (false, t('off'))],
              value: s.sfx,
              onChanged: (v) {
                s.sfx = v;
                s.saveSettings();
                if (v) Sfx.play('ok');
              },
            ),
            PixelTitle(t('haptics')),
            tx(t('haptics_d'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<bool>(
              options: [(true, t('on')), (false, t('off'))],
              value: s.haptics,
              onChanged: (v) {
                s.haptics = v;
                s.saveSettings();
                if (v) Sfx.play('ok');
              },
            ),
            PixelTitle(t('image_first')),
            tx(t('image_first_d'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<bool>(
              options: [(true, t('on')), (false, t('off'))],
              value: s.imageFirst,
              onChanged: (v) {
                s.imageFirst = v;
                s.saveSettings();
              },
            ),
            PixelTitle(t('bg_settings')),
            tx(t('bg_motion'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<bool>(
              options: [(true, t('on')), (false, t('off'))],
              value: s.bgMotion,
              onChanged: (v) {
                s.bgMotion = v;
                s.saveSettings();
              },
            ),
            const SizedBox(height: 10),
            tx(t('bg_veil'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<double>(
              options: [(0.2, t('veil_l')), (0.4, t('veil_m')), (0.65, t('veil_h'))],
              value: s.bgVeil,
              onChanged: (v) {
                s.bgVeil = v;
                s.saveSettings();
              },
            ),
            const SizedBox(height: 10),
            tx(t('bg_weather'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<String>(
              options: [
                ('none', t('w_none')),
                ('rain', t('w_rain')),
                ('snow', t('w_snow')),
                ('fog', t('w_fog')),
              ],
              value: s.bgWeather,
              onChanged: (v) {
                s.bgWeather = v;
                s.saveSettings();
              },
            ),
            const SizedBox(height: 10),
            tx(t('fx_particles'), size: 12.5, color: C.dark),
            const SizedBox(height: 6),
            PixelChips<bool>(
              options: [(true, t('on')), (false, t('off'))],
              value: s.fx,
              onChanged: (v) {
                s.fx = v;
                s.saveSettings();
                if (v) Fx.fire('ok');
              },
            ),
            PixelTitle(t('data')),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: t('copy_cards'),
                    small: true,
                    filled: false,
                    onTap: _copyAll,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PixelButton(
                    label: t('paste_cards'),
                    small: true,
                    filled: false,
                    onTap: _importClipboard,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            PixelButton(
              label: t('backup'),
              icon: 'save',
              small: true,
              expand: true,
              onTap: () => pushPage(context, const BackupScreen()),
            ),
            const SizedBox(height: 10),
            PixelButton(
              label: t('delete_all'),
              icon: 'trash',
              small: true,
              filled: false,
              expand: true,
              onTap: _deleteAll,
            ),
            const SizedBox(height: 24),
            Center(child: tx('aorc ai · v1.0', size: 12, color: C.gray)),
          ],
        ),
      ),
    );
  }
}
