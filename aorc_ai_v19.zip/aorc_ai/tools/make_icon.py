"""Generate assets/icon.png (bold neo-brutalist robot) with pure Python."""
import math
import struct
import zlib

SIZE = 512
BG = (255, 243, 207)
INK = (17, 17, 17)
PINK = (255, 107, 157)
YELLOW = (255, 216, 77)
WHITE = (255, 255, 255)


def rrect(px, py, x0, y0, x1, y1, r):
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    hx, hy = (x1 - x0) / 2 - r, (y1 - y0) / 2 - r
    dx, dy = abs(px - cx) - hx, abs(py - cy) - hy
    return math.hypot(max(dx, 0), max(dy, 0)) + min(max(dx, dy), 0) - r


def circle(px, py, cx, cy, r):
    return math.hypot(px - cx, py - cy) - r


# (distance function, color) layers, painted in order with anti-aliased edges
layers = [
    (lambda x, y: rrect(x, y, 84, 84, 444, 444, 64), INK),               # hard shadow
    (lambda x, y: rrect(x, y, 60, 60, 420, 420, 64), INK),               # border
    (lambda x, y: rrect(x, y, 76, 76, 404, 404, 50), PINK),              # card
    (lambda x, y: rrect(x, y, 236, 96, 244, 150, 4), INK),               # antenna stem
    (lambda x, y: circle(x, y, 240, 96, 30), INK),                       # antenna ball border
    (lambda x, y: circle(x, y, 240, 96, 20), YELLOW),                    # antenna ball
    (lambda x, y: rrect(x, y, 130, 150, 350, 330, 34), INK),             # face border
    (lambda x, y: rrect(x, y, 142, 162, 338, 318, 24), WHITE),           # face
    (lambda x, y: circle(x, y, 202, 224, 30), INK),                      # left eye
    (lambda x, y: circle(x, y, 278, 224, 30), INK),                      # right eye
    (lambda x, y: circle(x, y, 212, 214, 9), WHITE),                     # left glint
    (lambda x, y: circle(x, y, 288, 214, 9), WHITE),                     # right glint
    (lambda x, y: rrect(x, y, 190, 274, 290, 296, 11), INK),             # mouth
]

rows = []
for y in range(SIZE):
    row = bytearray([0])
    for x in range(SIZE):
        c = BG
        for fn, col in layers:
            d = fn(x + 0.5, y + 0.5)
            cov = min(1.0, max(0.0, 0.5 - d))
            if cov > 0:
                c = tuple(int(round(c[i] * (1 - cov) + col[i] * cov)) for i in range(3))
        row += bytes(c)
    rows.append(bytes(row))

raw = b"".join(rows)


def chunk(tag, data):
    body = tag + data
    return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)


png = b"\x89PNG\r\n\x1a\n"
png += chunk(b"IHDR", struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0))
png += chunk(b"IDAT", zlib.compress(raw, 9))
png += chunk(b"IEND", b"")

with open("assets/icon.png", "wb") as f:
    f.write(png)
print("icon written")
