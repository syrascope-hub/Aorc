#!/usr/bin/env python3
"""Procedural premium pixel-art pets.

Draws every pet on a 24x24 grid with a top-left light source, 4-tone shading
with ordered dithering on tone borders, a selective dark outline, glossy eyes,
blush, scarf and several animation frames, then writes lib/sprites_pets.dart
(sprite rows + per-pet palettes) and optional PNG previews.

Usage: python3 tools/make_pets.py [--preview DIR]
"""
import math
import sys
from pathlib import Path

W = H = 24

# ───────────────────────── canvas ─────────────────────────


class Cv:
    def __init__(self):
        self.g = [["."] * W for _ in range(H)]

    def put(self, x, y, c):
        if 0 <= x < W and 0 <= y < H:
            self.g[y][x] = c

    def get(self, x, y):
        if 0 <= x < W and 0 <= y < H:
            return self.g[y][x]
        return "."


def tone(s, x, y, ramp):
    """ramp = 'HLMD' style 4 letters, brightest first."""
    th = (0.84, 0.66, 0.40)
    t = 3
    for i, v in enumerate(th):
        if s > v:
            t = i
            break
    # ordered dithering when close to the next brighter tone
    if t > 0 and (x + y) % 2 == 0 and abs(s - th[t - 1]) < 0.035:
        t -= 1
    return ramp[t]


LIGHT = (-0.55, -0.65)


def shade_val(dx, dy, nz=0.5):
    return max(0.0, min(1.0, 0.55 + 0.45 * (dx * LIGHT[0] + dy * LIGHT[1]) + 0.10 * nz))


def ell(cv, cx, cy, rx, ry, ramp, over=None):
    for y in range(H):
        for x in range(W):
            dx = (x + 0.5 - cx) / rx
            dy = (y + 0.5 - cy) / ry
            r2 = dx * dx + dy * dy
            if r2 <= 1.0:
                if over is not None and cv.get(x, y) not in over:
                    continue
                cv.put(x, y, tone(shade_val(dx, dy, math.sqrt(1 - r2)), x, y, ramp))


def poly(cv, pts, ramp):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
    rx, ry = max(1, (max(xs) - min(xs)) / 2), max(1, (max(ys) - min(ys)) / 2)

    def inside(px, py):
        n = len(pts)
        ins = False
        j = n - 1
        for i in range(n):
            xi, yi = pts[i]
            xj, yj = pts[j]
            if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi + 1e-9) + xi:
                ins = not ins
            j = i
        return ins

    for y in range(H):
        for x in range(W):
            if inside(x + 0.5, y + 0.5):
                dx = (x + 0.5 - cx) / rx
                dy = (y + 0.5 - cy) / ry
                cv.put(x, y, tone(shade_val(dx * 0.8, dy * 0.8), x, y, ramp))


def mirror_poly(pts):
    return [(W - x, y) for x, y in pts]


def rect(cv, x0, y0, x1, y1, c):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            cv.put(x, y, c)


def outline(cv):
    src = [row[:] for row in cv.g]
    for y in range(H):
        for x in range(W):
            if src[y][x] == ".":
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < W and 0 <= ny < H and src[ny][nx] not in (".",):
                        cv.g[y][x] = "O"
                        break


# ───────────────────────── shared face / body parts ─────────────────────────

EYE_L, EYE_R = 7, 15  # left x of each 2px wide eye


def eyes(cv, mode, y=11, white_pupil=False, lx=EYE_L, rx=EYE_R):
    for x0 in (lx, rx):
        if mode == "open":
            rect(cv, x0, y, x0 + 1, y + 2, "E")
            cv.put(x0, y, "W")
            if white_pupil:
                cv.put(x0 + 1, y + 2, "W")
        elif mode == "closed":
            rect(cv, x0 - 1, y + 1, x0 + 2, y + 1, "E")
        elif mode == "happy":
            cv.put(x0 - 1, y + 2, "E")
            cv.put(x0, y + 1, "E")
            cv.put(x0 + 1, y + 1, "E")
            cv.put(x0 + 2, y + 2, "E")


def blush(cv, y=14):
    for x in (5, 6, 17, 18):
        cv.put(x, y, "P")


def mouth(cv, mode, y=15, nose=True, dark="E"):
    if nose:
        cv.put(11, y - 1, "N")
        cv.put(12, y - 1, "N")
    if mode == "happy":
        rect(cv, 10, y, 13, y, dark)
        cv.put(11, y + 1, "T")
        cv.put(12, y + 1, "T")
    else:
        cv.put(10, y, dark)
        cv.put(13, y, dark)
        cv.put(11, y + 1, dark)
        cv.put(12, y + 1, dark)


def scarf(cv, y=18):
    for x in range(7, 17):
        d = abs(x - 11.5)
        yy = y + (1 if d < 3 else 0)
        cv.put(x, yy, "A")
        cv.put(x, yy + 1, "a")
    # knot hanging on the left
    cv.put(8, y + 2, "A")
    cv.put(8, y + 3, "a")


def feet(cv, ramp, step, y=22, x1=8, x2=15):
    a, b = (0, 0) if step == 0 else (-1, 0)
    if step == 2:
        a, b = (0, -1)
    ell(cv, x1 + 0.5, y + 0.5 + a, 2.4, 1.6, ramp)
    ell(cv, x2 + 0.5, y + 0.5 + b, 2.4, 1.6, ramp)


# ───────────────────────── species ─────────────────────────


def cat(eye, step):
    c = Cv()
    # tail
    for i, (x, y) in enumerate([(19, 21), (21, 19), (22, 16), (21, 13), (20, 11)]):
        ell(c, x + 0.5, y + 0.5, 1.9, 1.9, "HLMD")
    ell(c, 20.5, 11.5, 1.6, 1.6, "wbvv")
    # body + belly
    ell(c, 12, 18.6, 6.6, 4.6, "HLMD")
    ell(c, 12, 19.6, 3.8, 3.0, "wbvv")
    feet(c, "HLMD", step)
    # ears
    poly(c, [(2.2, 6.8), (3.4, 0.8), (9.0, 4.6)], "HLMD")
    poly(c, mirror_poly([(2.2, 6.8), (3.4, 0.8), (9.0, 4.6)]), "HLMD")
    poly(c, [(3.6, 5.6), (4.2, 2.6), (6.8, 4.6)], "IIII")
    poly(c, mirror_poly([(3.6, 5.6), (4.2, 2.6), (6.8, 4.6)]), "IIII")
    # head
    ell(c, 12, 11, 9.6, 8.0, "HLMD")
    # forehead stripes
    for x, y0, y1 in ((11, 3, 5), (12, 3, 5), (8, 4, 5), (15, 4, 5)):
        for y in range(y0, y1 + 1):
            c.put(x, y, "D")
    # muzzle
    ell(c, 12, 15.2, 3.9, 2.7, "wbvv", over="HLMD")
    scarf(c)
    eyes(c, eye)
    blush(c)
    mouth(c, eye)
    outline(c)
    return c


def dog(eye, step):
    c = Cv()
    ell(c, 21, 19, 1.7, 2.4, "HLMD")  # tail
    ell(c, 12, 18.6, 6.6, 4.6, "HLMD")
    ell(c, 12, 19.6, 3.8, 3.0, "wbvv")
    feet(c, "wbvv", step)
    # head
    ell(c, 12, 11, 9.4, 7.8, "HLMD")
    # white blaze + muzzle
    ell(c, 12, 14.8, 4.4, 3.4, "wbvv", over="HLMD")
    for y in range(4, 12):
        w = 1 if y < 8 else 2
        for x in range(12 - w, 12 + w):
            c.put(x, y, "b" if (x + y) % 5 else "w")
    # floppy ears
    ell(c, 3.6, 11.0, 2.9, 6.0, "JKQQ")
    ell(c, 20.4, 11.0, 2.9, 6.0, "JKQQ")
    scarf(c)
    eyes(c, eye, y=10)
    blush(c, 14)
    # big dark nose
    rect(c, 10, 13, 13, 13, "E")
    rect(c, 11, 14, 12, 14, "E")
    c.put(11, 13, "W")
    if eye == "happy":
        rect(c, 10, 15, 13, 15, "E")
        rect(c, 11, 16, 12, 16, "T")
    else:
        c.put(10, 15, "E")
        c.put(13, 15, "E")
        c.put(11, 16, "E")
        c.put(12, 16, "E")
    outline(c)
    return c


def rabbit(eye, step):
    c = Cv()
    ell(c, 19.8, 21, 2.0, 2.0, "wbvv")  # cotton tail
    ell(c, 12, 18.8, 6.4, 4.4, "HLMD")
    ell(c, 12, 19.8, 3.6, 2.8, "wbvv")
    feet(c, "HLMD", step)
    # long ears
    ell(c, 7.6, 5.4, 2.4, 4.9, "HLMD")
    ell(c, 16.4, 5.4, 2.4, 4.9, "HLMD")
    ell(c, 7.8, 5.6, 1.2, 3.6, "IIII")
    ell(c, 16.2, 5.6, 1.2, 3.6, "IIII")
    ell(c, 12, 12, 9.2, 7.2, "HLMD")
    ell(c, 12, 15.6, 3.6, 2.3, "wbvv", over="HLMD")
    scarf(c)
    eyes(c, eye, y=11, lx=7, rx=15)
    blush(c, 14)
    c.put(11, 14, "N")
    c.put(12, 14, "N")
    c.put(11, 15, "E")
    c.put(12, 15, "E")
    if eye != "happy":
        c.put(10, 16, "E")
        c.put(13, 16, "E")
        rect(c, 11, 16, 12, 17, "W")  # buck teeth
        c.put(11, 17, "b")
        c.put(12, 17, "b")
    else:
        rect(c, 10, 16, 13, 16, "E")
        rect(c, 11, 17, 12, 17, "T")
    outline(c)
    return c


def panda(eye, step):
    c = Cv()
    ell(c, 12, 18.6, 6.8, 4.7, "wbvv")
    # arms patch
    ell(c, 6.2, 19.4, 2.4, 3.0, "JKQQ")
    ell(c, 17.8, 19.4, 2.4, 3.0, "JKQQ")
    ell(c, 12, 19.6, 3.8, 2.8, "wbvv")
    feet(c, "JKQQ", step)
    # ears
    ell(c, 4.6, 4.8, 2.8, 2.8, "JKQQ")
    ell(c, 19.4, 4.8, 2.8, 2.8, "JKQQ")
    ell(c, 12, 11, 9.6, 8.0, "wbvv")
    # eye patches
    ell(c, 7.8, 11.6, 2.7, 3.2, "JKQQ")
    ell(c, 16.2, 11.6, 2.7, 3.2, "JKQQ")
    scarf(c)
    if eye == "open":
        for x0 in (7, 15):
            rect(c, x0, 11, x0 + 1, 13, "E")
            c.put(x0, 11, "W")
            c.put(x0 + 1, 13, "W")
    else:
        for x0 in (7, 15):
            if eye == "closed":
                rect(c, x0 - 1, 12, x0 + 2, 12, "W")
            else:
                c.put(x0 - 1, 13, "W")
                c.put(x0, 12, "W")
                c.put(x0 + 1, 12, "W")
                c.put(x0 + 2, 13, "W")
    blush(c, 15)
    rect(c, 11, 14, 12, 14, "E")
    if eye == "happy":
        rect(c, 10, 15, 13, 15, "E")
        rect(c, 11, 16, 12, 16, "T")
    else:
        c.put(10, 15, "E")
        c.put(13, 15, "E")
        c.put(11, 16, "E")
        c.put(12, 16, "E")
    outline(c)
    return c


def penguin(eye, step):
    c = Cv()
    ell(c, 12, 15.6, 8.2, 8.0, "HLMD")  # whole plump body
    ell(c, 12, 17.2, 5.6, 5.8, "wbvv")  # belly
    # flippers
    ell(c, 3.8, 16.5, 1.9, 4.2, "JKQQ")
    ell(c, 20.2, 16.5, 1.9, 4.2, "JKQQ")
    # feet
    a, b = (0, 0) if step == 0 else ((-1, 0) if step == 1 else (0, -1))
    ell(c, 8.5, 22.7 + a, 2.6, 1.2, "NNNN")
    ell(c, 15.5, 22.7 + b, 2.6, 1.2, "NNNN")
    # head
    ell(c, 12, 9.4, 7.6, 6.4, "HLMD")
    # white face mask (heart shaped)
    ell(c, 8.8, 11.2, 3.6, 3.6, "wbvv", over="HLMD")
    ell(c, 15.2, 11.2, 3.6, 3.6, "wbvv", over="HLMD")
    ell(c, 12, 13.2, 4.2, 2.6, "wbvv", over="HLMD")
    scarf(c, y=15)
    eyes(c, eye, y=9, lx=8, rx=14, white_pupil=True)
    blush(c, 12)
    # beak
    rect(c, 10, 12, 13, 12, "N")
    rect(c, 11, 13, 12, 13, "N")
    if eye == "happy":
        rect(c, 11, 14, 12, 14, "T")
    outline(c)
    return c


def fox(eye, step):
    c = Cv()
    # big tail with white tip
    for (x, y, r) in [(19, 21, 2.2), (21, 18.5, 2.5), (21.5, 15.5, 2.5), (20.5, 12.5, 2.2)]:
        ell(c, x + 0.5, y + 0.5, r, r, "HLMD")
    ell(c, 20.6, 11.8, 1.9, 1.9, "wbvv")
    ell(c, 12, 18.6, 6.6, 4.6, "HLMD")
    ell(c, 12, 19.6, 3.8, 3.0, "wbvv")
    feet(c, "JKQQ", step)
    # ears (dark tips)
    for pts in ([(2.0, 7.0), (3.6, 0.4), (9.4, 4.6)],):
        poly(c, pts, "HLMD")
        poly(c, mirror_poly(pts), "HLMD")
    for pts in ([(3.0, 3.6), (3.6, 0.4), (5.8, 2.4)],):
        poly(c, pts, "JKQQ")
        poly(c, mirror_poly(pts), "JKQQ")
    poly(c, [(3.9, 5.8), (4.4, 3.4), (6.8, 4.8)], "IIII")
    poly(c, mirror_poly([(3.9, 5.8), (4.4, 3.4), (6.8, 4.8)]), "IIII")
    ell(c, 12, 11, 9.8, 7.8, "HLMD")
    # white cheeks forming a mask
    ell(c, 6.6, 15.0, 4.8, 3.4, "wbvv", over="HLMD")
    ell(c, 17.4, 15.0, 4.8, 3.4, "wbvv", over="HLMD")
    ell(c, 12, 16.0, 4.0, 2.4, "wbvv", over="HLMD")
    scarf(c)
    eyes(c, eye, y=10)
    blush(c, 14)
    rect(c, 11, 14, 12, 14, "E")
    if eye == "happy":
        rect(c, 10, 15, 13, 15, "E")
        rect(c, 11, 16, 12, 16, "T")
    else:
        c.put(10, 15, "E")
        c.put(13, 15, "E")
        c.put(11, 16, "E")
        c.put(12, 16, "E")
    outline(c)
    return c


def owl(eye, step):
    c = Cv()
    ell(c, 12, 14.4, 9.2, 9.0, "HLMD")  # round body
    ell(c, 12, 18.2, 5.4, 4.6, "wbvv")  # belly
    # feather ticks on belly
    for x, y in ((10, 17), (13, 17), (11, 19), (14, 19), (9, 20)):
        c.put(x, y, "v")
    ell(c, 3.4, 15.6, 2.0, 4.6, "JKQQ")  # wings
    ell(c, 20.6, 15.6, 2.0, 4.6, "JKQQ")
    # ear tufts
    poly(c, [(3.0, 6.2), (3.8, 0.8), (8.6, 4.2)], "HLMD")
    poly(c, mirror_poly([(3.0, 6.2), (3.8, 0.8), (8.6, 4.2)]), "HLMD")
    # face discs
    ell(c, 7.8, 10.2, 4.3, 4.3, "wbvv")
    ell(c, 16.2, 10.2, 4.3, 4.3, "wbvv")
    a, b = (0, 0) if step == 0 else ((-1, 0) if step == 1 else (0, -1))
    ell(c, 9, 23 + a, 2.3, 1.0, "NNNN")
    ell(c, 15, 23 + b, 2.3, 1.0, "NNNN")
    # big eyes
    for x0 in (6, 15):
        if eye == "open":
            rect(c, x0, 9, x0 + 2, 11, "E")
            c.put(x0, 9, "W")
            c.put(x0 + 2, 11, "W")
        elif eye == "closed":
            rect(c, x0, 10, x0 + 2, 10, "E")
        else:
            c.put(x0, 11, "E")
            c.put(x0 + 1, 10, "E")
            c.put(x0 + 2, 11, "E")
    blush(c, 13)
    rect(c, 11, 11, 12, 11, "N")
    rect(c, 11, 12, 12, 12, "N")
    scarf(c, y=15)
    outline(c)
    return c


def hamster(eye, step):
    c = Cv()
    ell(c, 12, 15.6, 10.0, 8.0, "HLMD")  # very round
    ell(c, 12, 19.0, 6.2, 4.2, "wbvv")
    ell(c, 4.2, 5.4, 2.4, 2.4, "HLMD")
    ell(c, 19.8, 5.4, 2.4, 2.4, "HLMD")
    ell(c, 4.2, 5.6, 1.2, 1.2, "IIII")
    ell(c, 19.8, 5.6, 1.2, 1.2, "IIII")
    ell(c, 12, 11.4, 9.8, 7.4, "HLMD")
    # cream cap + cheeks
    ell(c, 12, 7.2, 5.0, 3.0, "wbvv", over="HLMD")
    ell(c, 6.2, 15.2, 4.2, 3.4, "wbvv", over="HLMD")
    ell(c, 17.8, 15.2, 4.2, 3.4, "wbvv", over="HLMD")
    feet(c, "wbvv", step, y=22.3 if False else 22)
    eyes(c, eye, y=10, lx=7, rx=15)
    blush(c, 14)
    c.put(11, 13, "N")
    c.put(12, 13, "N")
    if eye == "happy":
        rect(c, 10, 14, 13, 14, "E")
        rect(c, 11, 15, 12, 15, "T")
    else:
        c.put(10, 14, "E")
        c.put(13, 14, "E")
        c.put(11, 15, "E")
        c.put(12, 15, "E")
        rect(c, 11, 16, 12, 16, "W")
    scarf(c, y=18)
    outline(c)
    return c


# ───────────────────────── palettes ─────────────────────────
# letter -> hex. Shared letters keep the same meaning in every pet.

BASE = {
    "O": "#1a1226",  # outline
    "E": "#1b1424",  # eye / mouth
    "W": "#ffffff",  # shine / white
    "T": "#ff6f8d",  # tongue
    "P": "#ff8fa8",  # blush
}

PETS = {
    "cat": dict(
        fn=cat,
        pal=dict(H="#ffc78a", L="#f2a14e", M="#dd7f2e", D="#b45a22",
                 w="#fff6e6", b="#ffe3c2", v="#f2c39a",
                 I="#ff9bb0", N="#e0607a", A="#4fb8ff", a="#2a7fd4",
                 J="#fff6e6", K="#ffe3c2", Q="#f2c39a"),
    ),
    "dog": dict(
        fn=dog,
        pal=dict(H="#e8b985", L="#cd9a62", M="#aa7745", D="#80532e",
                 w="#fffaf0", b="#f4e3c8", v="#d9bf9a",
                 J="#a56a3c", K="#7d4a29", Q="#5a331c",
                 I="#ff9bb0", N="#1b1424", A="#ff5d73", a="#c93a52"),
    ),
    "rabbit": dict(
        fn=rabbit,
        pal=dict(H="#ffffff", L="#f1eefa", M="#d7d0ec", D="#aea4cf",
                 w="#ffffff", b="#f6f2ff", v="#ddd5f1",
                 I="#ffb3c6", N="#ff7b9c", A="#7ad67a", a="#3f9f4a",
                 J="#ffffff", K="#f1eefa", Q="#d7d0ec"),
    ),
    "panda": dict(
        fn=panda,
        pal=dict(H="#ffffff", L="#f4f4f4", M="#d9d9e0", D="#b0b0bd",
                 w="#ffffff", b="#f4f4f4", v="#d3d3dc",
                 J="#5a5a6e", K="#363648", Q="#232233",
                 I="#ffb3c6", N="#232233", A="#ff6f91", a="#c8436a"),
    ),
    "penguin": dict(
        fn=penguin,
        pal=dict(H="#6f8fd8", L="#4a67b8", M="#34498f", D="#243566",
                 w="#ffffff", b="#f4f6ff", v="#d3d9f0",
                 J="#4a67b8", K="#34498f", Q="#243566",
                 I="#ffb3c6", N="#ffa826", A="#ff5d73", a="#c93a52"),
    ),
    "fox": dict(
        fn=fox,
        pal=dict(H="#ffa266", L="#ff8238", M="#e2601c", D="#a8430f",
                 w="#fffaf0", b="#ffe9d2", v="#f1c9a5",
                 J="#6b4a52", K="#4a3038", Q="#2e1d24",
                 I="#ffb3c6", N="#2e1d24", A="#46c28e", a="#23895f"),
    ),
    "owl": dict(
        fn=owl,
        pal=dict(H="#c9a07a", L="#a67c58", M="#85603f", D="#5f432a",
                 w="#fff3dc", b="#f1dcb8", v="#d4b98f",
                 J="#8b6444", K="#6b4a30", Q="#4a3220",
                 I="#ffb3c6", N="#ffa826", A="#c06bff", a="#8a3fc9"),
    ),
    "hamster": dict(
        fn=hamster,
        pal=dict(H="#ffd9a0", L="#f4b868", M="#dd9648", D="#b27030",
                 w="#fffaf0", b="#fff0d9", v="#f2d4a8",
                 I="#ffa6b8", N="#e0607a", A="#5fd0c0", a="#2d9c8f",
                 J="#fffaf0", K="#fff0d9", Q="#f2d4a8"),
    ),
}

FRAMES = {"": ("open", 0), "_b": ("closed", 0), "_h": ("happy", 0), "_w": ("open", 1), "_v": ("open", 2)}


def rows(cv):
    return ["".join(r) for r in cv.g]


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def dart_color(h):
    return "Color(0xFF%s)" % h.lstrip("#").upper()


def main():
    preview = None
    if "--preview" in sys.argv:
        preview = Path(sys.argv[sys.argv.index("--preview") + 1])
        preview.mkdir(parents=True, exist_ok=True)

    out = []
    out.append("// GENERATED by tools/make_pets.py - do not edit by hand.")
    out.append("// Premium shaded pixel pets: 24x24, 4-tone shading, outline, animation frames.")
    out.append("// Frames: '' stand, _b blink, _h happy, _w/_v walk (alternate feet).")
    out.append("import 'dart:ui' show Color;")
    out.append("")
    out.append("const List<String> kPetKinds2 = [%s];" % ", ".join("'%s'" % k for k in PETS))
    out.append("")
    out.append("const Map<String, Map<String, Color>> kPetPalettes = {")
    for k, d in PETS.items():
        pal = dict(BASE)
        pal.update(d["pal"])
        out.append("  '%s': {" % k)
        items = list(pal.items())
        for i in range(0, len(items), 3):
            out.append("    " + " ".join("'%s': %s," % (a, dart_color(b)) for a, b in items[i:i + 3]))
        out.append("  },")
    out.append("};")
    out.append("")
    out.append("const Map<String, List<String>> kSpritesPets = {")

    sheet = []
    for k, d in PETS.items():
        row_imgs = []
        for suffix, (eye, step) in FRAMES.items():
            cv = d["fn"](eye, step)
            r = rows(cv)
            out.append("  'pet_%s%s': [" % (k, suffix))
            for line in r:
                out.append("    '%s'," % line)
            out.append("  ],")
            row_imgs.append((r, k))
        sheet.append(row_imgs)
    out.append("};")
    Path("lib/sprites_pets.dart").write_text("\n".join(out) + "\n", encoding="utf-8")
    print("wrote lib/sprites_pets.dart")

    if preview:
        from PIL import Image

        sc = 8
        pad = 4
        cols = len(FRAMES)
        img = Image.new("RGB", (cols * (W * sc + pad) + pad, len(PETS) * (H * sc + pad) + pad), (246, 237, 214))
        for ri, (k, d) in enumerate(PETS.items()):
            pal = dict(BASE)
            pal.update(d["pal"])
            for ci, (r, _) in enumerate(sheet[ri]):
                ox = pad + ci * (W * sc + pad)
                oy = pad + ri * (H * sc + pad)
                for y, line in enumerate(r):
                    for x, ch in enumerate(line):
                        if ch == ".":
                            continue
                        col = hex_to_rgb(pal.get(ch, "#ff00ff"))
                        for yy in range(sc):
                            for xx in range(sc):
                                img.putpixel((ox + x * sc + xx, oy + y * sc + yy), col)
        img.save(preview / "pets.png")
        print("preview", preview / "pets.png")


if __name__ == "__main__":
    main()
