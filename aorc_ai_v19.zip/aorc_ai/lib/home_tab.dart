import 'package:flutter/material.dart';

import 'challenge.dart';
import 'chat_screen.dart';
import 'common.dart';
import 'daily_pack.dart';
import 'focus.dart';
import 'listen_mode.dart';
import 'progress.dart';
import 'pronounce.dart';
import 'quests.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// The new landing tab: one big action, today's goal, stats and shortcuts.
class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final due = s.dueCount;
        final hasCards = s.cards.isNotEmpty;
        final goal = s.dailyGoal <= 0 ? 1 : s.dailyGoal;
        final n = s.todayCount;
        final v = (n / goal).clamp(0.0, 1.0).toDouble();
        final done = n >= goal;
        final qDone = kQuests.where((q) => s.quest(q.key) >= q.target).length;
        final fg = onAccent();
        final w = (MediaQuery.of(context).size.width - 28 - 12) / 2;

        final String headline = !hasCards
            ? t('home_no_cards')
            : due > 0
                ? t('home_due_n').replaceAll('{n}', '$due')
                : t('home_none');
        final String btnLabel = !hasCards ? t('home_add') : (due > 0 ? t('home_start') : t('home_play'));
        final String btnIcon = !hasCards ? 'create' : (due > 0 ? 'sparkle' : 'games');
        void onHero() {
          if (!hasCards) {
            s.goOldTab(0);
          } else if (due > 0) {
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ReviewScreen()));
          } else {
            s.goOldTab(2);
          }
        }

        void shortcut(Widget page, {int need = 0}) {
          if (need > 0 && !needCards(context, need)) return;
          pushPage(context, page);
        }

        final items = <(String, String, VoidCallback)>[
          ('headphones', t('listen_mode'), () => shortcut(const ListenModeScreen(), need: 1)),
          ('sparkle', t('daily_pack'), () => shortcut(const DailyPackScreen(), need: 3)),
          ('games', t('challenge'), () => shortcut(const ChallengeScreen())),
          ('timer', t('focus'), () => shortcut(const FocusScreen())),
          ('chat', t('chat'), () => shortcut(const ChatScreen(), need: 3)),
          ('mic', t('pronounce'), () => shortcut(const PronounceScreen(), need: 1)),
        ];

        return ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 110),
          children: [
            PixelBox(
              color: C.accent,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Sprite(hasCards ? 'sparkle' : 'create', px: 3.6, tint: fg),
                      const SizedBox(width: 10),
                      Expanded(child: tx(t('home_hi'), size: 15, bold: true, color: fg)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    headline,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: fg, height: 1.3),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: PixelButton(
                      label: btnLabel,
                      icon: btnIcon,
                      filled: false,
                      expand: true,
                      onTap: onHero,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            PixelBox(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: tx(
                          done ? t('daily_goal_done') : '${t('daily_today')}: $n / $goal',
                          bold: true,
                          size: 14.5,
                        ),
                      ),
                      const Sprite('flame', px: 2.4),
                      const SizedBox(width: 4),
                      tx('${s.streak} ${t('streak_days')}', bold: true, size: 13, color: C.dark),
                    ],
                  ),
                  const SizedBox(height: 10),
                  PixelBox(
                    u: 2,
                    shadow: false,
                    padding: const EdgeInsets.all(3),
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: FractionallySizedBox(
                        widthFactor: v < 0.03 ? 0.03 : v,
                        child: Container(
                          height: 12,
                          decoration: BoxDecoration(
                            color: done ? const Color(0xFF22B573) : C.accent2,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _stat('${s.masteredCount}', t('home_mastered'))),
                const SizedBox(width: 6),
                Expanded(child: _stat('${s.cards.length}', t('home_cards'))),
                const SizedBox(width: 6),
                Expanded(child: _stat('${s.totalReviews}', t('home_reviews'))),
              ],
            ),
            PixelTitle(t('home_quick')),
            Wrap(
              spacing: 12,
              runSpacing: 6,
              children: [
                for (final it in items)
                  SizedBox(
                    width: w,
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        Sfx.play('tap');
                        it.$3();
                      },
                      child: PixelBox(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                        child: Row(
                          children: [
                            Sprite(it.$1, px: 3),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                it.$2,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: C.ink),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            menuTile('tasks', t('quests'), '$qDone / ${kQuests.length}',
                () => pushPage(context, const QuestsScreen())),
          ],
        );
      },
    );
  }

  Widget _stat(String value, String label) {
    return PixelBox(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            tx(value, size: 21, bold: true),
            const SizedBox(height: 2),
            tx(label, size: 11.5, color: C.dark, bold: true, align: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
