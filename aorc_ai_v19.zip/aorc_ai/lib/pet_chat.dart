import 'dart:async';

import 'package:flutter/material.dart';

import 'backup.dart';
import 'common.dart';
import 'focus.dart';
import 'pet.dart';
import 'pet_brain.dart';
import 'progress.dart';
import 'quests.dart';
import 'services.dart';
import 'settings_screen.dart';
import 'state.dart';
import 'strings.dart';
import 'stt.dart';
import 'theme.dart';
import 'voice_screen.dart';

class _M {
  final bool user;
  final String text;
  final List<PetAction> actions;
  final String? speak; // '<lang>|<text>'
  _M(this.user, this.text, {this.actions = const [], this.speak});
}

/// Chat with your pet. Everything runs on the phone: no API, no key, no cost.
class PetChatScreen extends StatefulWidget {
  const PetChatScreen({super.key});
  @override
  State<PetChatScreen> createState() => _PetChatScreenState();
}

class _PetChatScreenState extends State<PetChatScreen> {
  AppState get s => AppState.I;

  final List<_M> msgs = [];
  final TextEditingController input = TextEditingController();
  final ScrollController scroll = ScrollController();
  PetQuiz? _quiz;
  String _face = '_h';
  Timer? _faceT;
  Timer? _blinkT;
  bool _listening = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _blinkT = Timer.periodic(const Duration(milliseconds: 3200), (_) async {
      if (!mounted || _face != '') return;
      setState(() => _face = '_b');
      await Future<void>.delayed(const Duration(milliseconds: 160));
      if (mounted && _face == '_b') setState(() => _face = '');
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _deliver(PetBrain.welcome(), delay: 200));
  }

  @override
  void dispose() {
    _faceT?.cancel();
    _blinkT?.cancel();
    Stt.stop();
    Speech.stop();
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void _setFace(String f) {
    _faceT?.cancel();
    setState(() => _face = f);
    if (f != '') {
      _faceT = Timer(const Duration(milliseconds: 2200), () {
        if (mounted) setState(() => _face = '');
      });
    }
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent + 200,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _deliver(PetReply r, {int delay = 380}) async {
    if (r.autoAction != null) {
      await _action(PetAction(r.autoAction!, ''), echo: false);
      return;
    }
    setState(() => _busy = true);
    await Future<void>.delayed(Duration(milliseconds: delay));
    if (!mounted) return;
    setState(() {
      _busy = false;
      msgs.add(_M(false, r.text, actions: r.actions, speak: r.speak));
    });
    _setFace(r.face);
    _toEnd();
    if (r.speak != null) _speakRaw(r.speak!);
  }

  void _speakRaw(String raw) {
    final i = raw.indexOf('|');
    if (i < 0) return;
    Speech.speak(raw.substring(i + 1), raw.substring(0, i));
  }

  Future<void> _send(String text) async {
    final txt = text.trim();
    if (txt.isEmpty || _busy) return;
    input.clear();
    setState(() => msgs.add(_M(true, txt)));
    _toEnd();
    final q = _quiz;
    if (q != null) {
      final n = PetBrain.norm(txt);
      final idx = q.options.indexWhere((o) => PetBrain.norm(o) == n);
      if (idx >= 0) {
        await _answer(idx);
        return;
      }
    }
    await _deliver(PetBrain.reply(txt));
  }

  Future<void> _answer(int i) async {
    final q = _quiz;
    if (q == null) return;
    _quiz = null;
    final ok = i == q.correct;
    q.card.applyReview(ok ? 4 : 0);
    Sfx.play(ok ? 'ok' : 'bad');
    await s.saveCards();
    await s.recordReview();
    await _deliver(PetBrain.feedback(q, ok), delay: 250);
  }

  void _goTab(int n) {
    s.tab.value = n;
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  Future<void> _action(PetAction a, {bool echo = true}) async {
    if (_busy) return;
    final id = a.id;
    if (echo && a.label.isNotEmpty) {
      setState(() => msgs.add(_M(true, a.label)));
      _toEnd();
    }
    if (id.startsWith('ans:')) {
      await _answer(int.tryParse(id.substring(4)) ?? -1);
      return;
    }
    if (id.startsWith('tab:')) {
      _goTab(int.tryParse(id.substring(4)) ?? 1);
      return;
    }
    if (id.startsWith('screen:')) {
      _openScreen(id.substring(7));
      return;
    }
    if (id.startsWith('speak:')) {
      _speakRaw(id.substring(6));
      return;
    }
    switch (id) {
      case 'quiz':
        final q = PetBrain.makeQuiz();
        if (q == null) {
          await _deliver(PetBrain.quizUnavailable());
        } else {
          _quiz = q;
          await _deliver(PetBrain.quizQuestion(q));
        }
        break;
      case 'word':
        await _deliver(PetBrain.wordOfDay());
        break;
      case 'hard':
        await _deliver(PetBrain.hardWords());
        break;
      case 'stats':
        await _deliver(PetBrain.statsInfo());
        break;
      case 'due':
        await _deliver(PetBrain.dueInfo());
        break;
      case 'joke':
        await _deliver(PetBrain.joke());
        break;
      case 'help':
        await _deliver(PetBrain.helpMenu());
        break;
      case 'feed':
        if (await s.feedPet(kFeedCost)) {
          Sfx.play('win');
          await _deliver(PetReply(_l('ياي! شكراً على الطعام 🍖', 'Yay! Thanks for the food 🍖'), face: '_h'));
        } else {
          await _deliver(PetReply(t('pet_no_coins'), face: '_b'));
        }
        break;
      case 'play':
        await s.playWithPet();
        Sfx.play('ok');
        await _deliver(PetReply(_l('كان ممتعاً! 🎾', 'That was fun! 🎾'), face: '_h'));
        break;
    }
  }

  String _l(String ar, String en) => s.uiLang == 'ar' ? ar : en;

  void _openScreen(String name) {
    Widget? page;
    switch (name) {
      case 'voice':
        page = const VoiceScreen();
        break;
      case 'settings':
        page = const SettingsScreen();
        break;
      case 'focus':
        page = const FocusScreen();
        break;
      case 'progress':
        page = const ProgressScreen();
        break;
      case 'shop':
        page = const ShopScreen();
        break;
      case 'backup':
        page = const BackupScreen();
        break;
    }
    if (page != null) pushPage(context, page);
  }

  Future<void> _mic() async {
    if (_listening) {
      await Stt.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    final ok = await Stt.start(s.uiLang == 'ar' ? 'ar-SA' : 'en-US', (text, done) {
      if (!mounted) return;
      input.text = text;
      if (done) {
        setState(() => _listening = false);
        _send(text);
      }
    });
    if (!mounted) return;
    if (ok) {
      setState(() => _listening = true);
    } else {
      toast(context, t('pc_mic_fail'));
    }
  }

  Widget _chip(PetAction a, {bool main = false}) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Sfx.play('tap');
        _action(a);
      },
      child: PixelBox(
        u: 2,
        shadow: false,
        color: main ? C.accent : C.cream,
        edge: main ? C.ink : null,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Text(a.label,
            style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: C.ink)),
      ),
    );
  }

  Widget _bubble(_M m, bool last) {
    final lang = s.uiLang == 'ar' ? 'ar-SA' : 'en-US';
    final bubble = PixelBox(
      u: 2,
      color: m.user ? C.ink : C.white,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            m.text,
            style: TextStyle(
              fontSize: 15,
              height: 1.35,
              fontWeight: FontWeight.w700,
              color: m.user ? C.cream : C.ink,
            ),
          ),
          if (!m.user && m.text.length > 3) ...[
            const SizedBox(height: 6),
            SpeakBtn(m.text, lang),
          ],
        ],
      ),
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        crossAxisAlignment: m.user ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
            child: bubble,
          ),
          if (!m.user && last && m.actions.isNotEmpty && !_busy)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final a in m.actions)
                    _chip(a, main: a.id.startsWith('tab:') || a.id == 'quiz'),
                ],
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = s.petName.isEmpty ? t('pet') : s.petName;
    return PixelPage(
      title: name,
      actions: [coinChip()],
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
            child: Row(
              children: [
                PixelBox(
                  color: C.creamDeep,
                  padding: const EdgeInsets.all(4),
                  child: PetSprite(s.hasPet ? s.petKind : 'cat', size: 72, frame: _face),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      tx(name, size: 18, bold: true),
                      tx(_busy ? t('pc_typing') : t('pc_offline'), size: 12.5, color: C.dark),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
              itemCount: msgs.length,
              itemBuilder: (_, i) => _bubble(msgs[i], i == msgs.length - 1),
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              children: [
                for (final a in [
                  PetAction('due', _l('ماذا أراجع؟', 'What to review?')),
                  PetAction('quiz', _l('اختبرني', 'Quiz me')),
                  PetAction('stats', _l('تقدّمي', 'My progress')),
                  PetAction('word', _l('كلمة اليوم', 'Word of the day')),
                  PetAction('hard', _l('كلماتي الصعبة', 'My hard words')),
                  PetAction('joke', _l('نكتة', 'Joke')),
                  PetAction('help', _l('مساعدة', 'Help')),
                ])
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8, bottom: 4),
                    child: _chip(a),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
            child: Row(
              children: [
                Expanded(
                  child: PixelField(
                    controller: input,
                    hint: t('pc_hint'),
                    onSubmitted: _send,
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _mic,
                  child: PixelBox(
                    color: _listening ? C.accent : C.white,
                    padding: const EdgeInsets.all(9),
                    child: Sprite('mic', px: 2.6),
                  ),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _send(input.text),
                  child: PixelBox(
                    color: C.ink,
                    edge: C.accent,
                    padding: const EdgeInsets.all(9),
                    child: Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.diagonal3Values(
                          Directionality.of(context) == TextDirection.rtl ? 1 : -1, 1, 1),
                      child: Sprite('back', px: 2.6, tint: C.cream),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
