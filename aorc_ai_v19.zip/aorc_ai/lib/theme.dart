import 'dart:math';

import 'package:flutter/material.dart';

import 'backgrounds.dart';
import 'services.dart';
import 'sprites_extra.dart';
import 'sprites_pets.dart';
import 'state.dart';
import 'ui_extras.dart';

// ───────────────────────── Palettes (color themes) ─────────────────────────
// Roles: ink = text/borders, cream = page background, creamDeep = highlighted
// background, white = card surface, gray = muted text, light = soft fill,
// dark = secondary text.

class Pal {
  final String id;
  final String ar;
  final String en;
  final Color ink, cream, creamDeep, white, gray, light, dark;
  final Color accent, accent2; // gold trim + secondary highlight (premium look)
  const Pal(this.id, this.ar, this.en, this.ink, this.cream, this.creamDeep, this.white,
      this.gray, this.light, this.dark,
      {this.accent = const Color(0xFFE8B63A), this.accent2 = const Color(0xFF7B4DD6)});
}

const List<Pal> kPalettes = [
  // Neo-Brutalism: thick black borders, hard shadows, loud flat colors.
  Pal('brutal', 'بروتال', 'Brutal', Color(0xFF111111), Color(0xFFFFF3CF), Color(0xFFFFD84D),
      Color(0xFFFFFFFF), Color(0xFF6B6B6B), Color(0xFFEADFBE), Color(0xFF333333),
      accent: Color(0xFFFF6B9D), accent2: Color(0xFF4D8DFF)),
  Pal('brutal_night', 'بروتال ليلي', 'Brutal night', Color(0xFFF5F5F5), Color(0xFF16161D),
      Color(0xFF23232E), Color(0xFF1F1F29), Color(0xFF9C9CAA), Color(0xFF34343F),
      Color(0xFFD6D6E0),
      accent: Color(0xFFC6FF4D), accent2: Color(0xFFFF6B9D)),
  Pal('royal', 'ملكي', 'Royal', Color(0xFF1B1230), Color(0xFFF3EAD3), Color(0xFFE6D6B0),
      Color(0xFFFFFBF0), Color(0xFF8A7F99), Color(0xFFD9CDB4), Color(0xFF4A3F66)),
  Pal('royal_night', 'ملكي ليلي', 'Royal night', Color(0xFFF3EAD3), Color(0xFF171226),
      Color(0xFF241B3A), Color(0xFF2A2145), Color(0xFF9A8FB5), Color(0xFF3A2E5C),
      Color(0xFFD8CDF0),
      accent2: Color(0xFFA77BFF)),
  Pal('classic', 'كلاسيكي', 'Classic', Color(0xFF1B1B1B), Color(0xFFF6EDD6), Color(0xFFEADFBF),
      Color(0xFFFFFFFF), Color(0xFF8C8C8C), Color(0xFFDAD5C8), Color(0xFF4B4B4B)),
  Pal('ocean', 'محيط', 'Ocean', Color(0xFF10263D), Color(0xFFDDEBF8), Color(0xFFC3DBF0),
      Color(0xFFFFFFFF), Color(0xFF7C8FA3), Color(0xFFB7CCE0), Color(0xFF3B556F)),
  Pal('mint', 'نعناع', 'Mint', Color(0xFF123227), Color(0xFFDDF3E4), Color(0xFFC4E8D0),
      Color(0xFFFFFFFF), Color(0xFF7A9A88), Color(0xFFB5D6C2), Color(0xFF365C4A)),
  Pal('sakura', 'ساكورا', 'Sakura', Color(0xFF3B1526), Color(0xFFFCE4EC), Color(0xFFF7CCDA),
      Color(0xFFFFFFFF), Color(0xFFA0808C), Color(0xFFEBC2D0), Color(0xFF6B3A50)),
  Pal('lavender', 'لافندر', 'Lavender', Color(0xFF241A40), Color(0xFFE9E2F8), Color(0xFFD5C9F0),
      Color(0xFFFFFFFF), Color(0xFF8A82A3), Color(0xFFC6BBE3), Color(0xFF54487A)),
  Pal('sunset', 'غروب', 'Sunset', Color(0xFF3D1C0C), Color(0xFFFFE8D2), Color(0xFFFAD3AE),
      Color(0xFFFFFFFF), Color(0xFFA38670), Color(0xFFEBC9A8), Color(0xFF6E3F22)),
  Pal('lemon', 'ليمون', 'Lemon', Color(0xFF2E2A06), Color(0xFFFBF5BD), Color(0xFFF1E88E),
      Color(0xFFFFFFFF), Color(0xFF948E55), Color(0xFFE0D880), Color(0xFF5E5714)),
  Pal('night', 'ليلي', 'Night', Color(0xFFF2EAD3), Color(0xFF1C1D26), Color(0xFF2D2F3D),
      Color(0xFF282A36), Color(0xFF8A8B99), Color(0xFF3A3D4D), Color(0xFFCFC8B2)),
  Pal('contrast', 'تباين عالٍ', 'High contrast', Color(0xFF000000), Color(0xFFFFFFFF),
      Color(0xFFFFF176), Color(0xFFFFFFFF), Color(0xFF555555), Color(0xFFD0D0D0), Color(0xFF222222)),
];

Pal palById(String id) =>
    kPalettes.firstWhere((p) => p.id == id, orElse: () => kPalettes.first);

class C {
  static Pal p = kPalettes.first;
  static Color get ink => p.ink;
  static Color get cream => p.cream;
  static Color get creamDeep => p.creamDeep;
  static Color get white => p.white;
  static Color get gray => p.gray;
  static Color get light => p.light;
  static Color get dark => p.dark;
  static Color get accent => p.accent;
  static Color get accent2 => p.accent2;
}

/// Readable text color on top of the accent color.
Color onAccent() =>
    C.accent.computeLuminance() > 0.35 ? const Color(0xFF111111) : Colors.white;

/// Mixes [a] toward [b] by [t] (0..1).
Color mix(Color a, Color b, double t) => Color.lerp(a, b, t) ?? a;

bool _isDark(Color c) => c.computeLuminance() < 0.32;

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'Tajawal', // registered by tools/setup_fonts.py; default font if missing
    scaffoldBackgroundColor: C.cream,
    textTheme: Typography.material2021()
        .black
        .apply(fontFamily: 'Tajawal', bodyColor: C.ink, displayColor: C.ink),
    colorScheme: ColorScheme.fromSeed(
      seedColor: C.ink,
      brightness: Brightness.light,
      surface: C.cream,
    ),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: C.ink,
      selectionColor: C.light,
      selectionHandleColor: C.ink,
    ),
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
  );
}

// ───────────────────────── Pixel sprites ─────────────────────────
// 1 = ink, 2 = gray, 3 = white, 4 = cream, 5 = dark gray, 6 = light gray

const Map<String, List<String>> kSprites = {
  'robot': [
    '.....11.....',
    '.....11.....',
    '.1111111111.',
    '.1444444441.',
    '.1414444141.',
    '.1414444141.',
    '.1444444441.',
    '.1441111441.',
    '.1444444441.',
    '.1111111111.',
    '..1......1..',
    '.111....111.',
  ],
  'star': [
    '...1...',
    '...1...',
    '.11111.',
    '1111111',
    '.11111.',
    '..1.1..',
    '.1...1.',
  ],
  'create': [
    '1111111111',
    '1........1',
    '1...11...1',
    '1...11...1',
    '1.111111.1',
    '1.111111.1',
    '1...11...1',
    '1...11...1',
    '1........1',
    '1111111111',
  ],
  'cards': [
    '...1111111',
    '...1.....1',
    '...1.....1',
    '1111111..1',
    '1.....1..1',
    '1.....1..1',
    '1.....1111',
    '1.....1...',
    '1.....1...',
    '1111111...',
  ],
  'games': [
    '..........',
    '.11111111.',
    '1........1',
    '1..1...1.1',
    '1.111.1..1',
    '1..1...1.1',
    '1........1',
    '.11....11.',
    '..1....1..',
    '..........',
  ],
  'summary': [
    '.11111111.',
    '.1......1.',
    '.1.1111.1.',
    '.1......1.',
    '.1.1111.1.',
    '.1......1.',
    '.1.11...1.',
    '.1......1.',
    '.11111111.',
    '..........',
  ],
  'quiz': [
    '1111111111',
    '1........1',
    '1......1.1',
    '1.1...11.1',
    '1.11.11..1',
    '1..111...1',
    '1...1....1',
    '1........1',
    '1111111111',
    '..........',
  ],
  'stories': [
    '..........',
    '1111111111',
    '1...11...1',
    '1.1.11.1.1',
    '1...11...1',
    '1.1.11.1.1',
    '1...11...1',
    '1111111111',
    '..........',
    '..........',
  ],
  'gear': [
    '....11....',
    '.1.1111.1.',
    '..111111..',
    '.11....11.',
    '111....111',
    '111....111',
    '.11....11.',
    '..111111..',
    '.1.1111.1.',
    '....11....',
  ],
  'speaker': [
    '....1.....',
    '...11..1..',
    '11111...1.',
    '11111.1.1.',
    '11111.1.1.',
    '11111...1.',
    '...11..1..',
    '....1.....',
  ],
  'back': [
    '...1....',
    '..11....',
    '.111....',
    '11111111',
    '.111....',
    '..11....',
    '...1....',
  ],
  'heart': [
    '.11.11.',
    '1111111',
    '1111111',
    '.11111.',
    '..111..',
    '...1...',
  ],
  'check': [
    '......1',
    '.....11',
    '1...11.',
    '11.11..',
    '.111...',
    '..1....',
  ],
  'trash': [
    '..1111..',
    '11111111',
    '........',
    '.1.1.1..',
    '.1.1.1..',
    '.1.1.1..',
    '.1.1.1..',
    '..1111..',
  ],
  'sparkle': [
    '...1...',
    '..111..',
    '.11111.',
    '1111111',
    '.11111.',
    '..111..',
    '...1...',
  ],
  'flame': [
    '...1...',
    '..11...',
    '.1211..',
    '.12211.',
    '1223221',
    '1233321',
    '.12221.',
    '..111..',
  ],
  'chart': [
    '......11',
    '......11',
    '...11.11',
    '...11.11',
    '.1.11.11',
    '.1.11.11',
    '11111111',
  ],
  'egg': [
    '....1111....',
    '...133331...',
    '..13333331..',
    '..13363331..',
    '.1333333331.',
    '.1333333631.',
    '.1366333331.',
    '.1333333331.',
    '.1333336331.',
    '..13333331..',
    '...133331...',
    '....1111....',
  ],
  'pet1': [
    '............',
    '....1111....',
    '...144441...',
    '..14444441..',
    '.1414444141.',
    '.1414444141.',
    '.1464444641.',
    '.1444114441.',
    '..14444441..',
    '...111111...',
  ],
  'pet2': [
    '.11......11.',
    '.1411111141.',
    '.1444444441.',
    '.1414444141.',
    '.1414444141.',
    '.1464444641.',
    '.1444114441.',
    '.1444444441.',
    '..14444441..',
    '..11111111..',
    '..11....11..',
  ],
  'pet3': [
    '.11......11.',
    '.1411111141.',
    '.1444444441.',
    '.1414444141.',
    '.1414444141.',
    '.1464444641.',
    '.1444114441.',
    '114444444411',
    '1.14333341.1',
    '..14333341..',
    '..11111111..',
    '..11....11..',
  ],
  'pet4': [
    '...1.11.1...',
    '...111111...',
    '.11......11.',
    '.1411111141.',
    '.1444444441.',
    '.1414444141.',
    '.1414444141.',
    '.1464444641.',
    '.1444114441.',
    '114444444411',
    '1.14333341.1',
    '..14333341..',
    '..11111111..',
    '..11....11..',
  ],
};

Color? spriteColor(String ch, Color? tint) {
  switch (ch) {
    case '1':
      return tint ?? C.ink;
    case '2':
      return C.gray;
    case '3':
      return C.white;
    case '4':
      return C.cream;
    case '5':
      return C.dark;
    case '6':
      return C.light;
    // fixed colors (not theme dependent), used by the pets
    case '7':
      return const Color(0xFFE8964A); // orange
    case '8':
      return const Color(0xFF9C6B43); // brown
    case '9':
      return const Color(0xFFF29BB0); // pink
    case 'a':
      return const Color(0xFFF7F2E8); // off-white
    case 'c':
      return const Color(0xFF34476B); // navy
  }
  return null;
}

class SpritePainter extends CustomPainter {
  final List<String> rows;
  final double px;
  final Color? tint;
  final int? limit; // draw only the first [limit] cells of [order]
  final List<Point<int>>? order;
  final Map<String, Color>? pal; // per-sprite colors (pets); checked before the theme legend

  SpritePainter(this.rows, this.px, {this.tint, this.limit, this.order, this.pal});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..isAntiAlias = true;
    void cell(int x, int y) {
      if (y >= rows.length || x >= rows[y].length) return;
      final ch = rows[y][x];
      final c = pal != null ? (pal![ch] ?? spriteColor(ch, tint)) : spriteColor(ch, tint);
      if (c == null) return;
      paint.color = c;
      canvas.drawRect(Rect.fromLTWH(x * px, y * px, px + 0.4, px + 0.4), paint);
    }

    if (order != null && limit != null) {
      final n = limit!.clamp(0, order!.length);
      for (int i = 0; i < n; i++) {
        cell(order![i].x, order![i].y);
      }
      return;
    }
    for (int y = 0; y < rows.length; y++) {
      for (int x = 0; x < rows[y].length; x++) {
        cell(x, y);
      }
    }
  }

  @override
  bool shouldRepaint(covariant SpritePainter old) =>
      old.limit != limit || old.px != px || old.tint != tint || old.rows != rows || old.pal != pal;
}

const Map<String, IconData> _kIcons = {
  'robot': Icons.smart_toy_rounded,
  'star': Icons.star_rounded,
  'create': Icons.add_box_rounded,
  'cards': Icons.style_rounded,
  'games': Icons.sports_esports_rounded,
  'summary': Icons.summarize_rounded,
  'quiz': Icons.quiz_rounded,
  'stories': Icons.menu_book_rounded,
  'gear': Icons.settings_rounded,
  'speaker': Icons.volume_up_rounded,
  'back': Icons.arrow_back_rounded,
  'heart': Icons.favorite_rounded,
  'check': Icons.check_circle_rounded,
  'trash': Icons.delete_rounded,
  'sparkle': Icons.auto_awesome_rounded,
  'flame': Icons.local_fire_department_rounded,
  'chart': Icons.bar_chart_rounded,
  'coin': Icons.monetization_on_rounded,
  'mic': Icons.mic_rounded,
  'camera': Icons.photo_camera_rounded,
  'chat': Icons.chat_bubble_rounded,
  'trophy': Icons.emoji_events_rounded,
  'timer': Icons.timer_rounded,
  'folder': Icons.folder_rounded,
  'bell': Icons.notifications_rounded,
  'bulb': Icons.lightbulb_rounded,
  'headphones': Icons.headphones_rounded,
  'lock': Icons.lock_rounded,
  'bolt': Icons.bolt_rounded,
  'more': Icons.more_horiz_rounded,
  'save': Icons.save_rounded,
  'mind': Icons.psychology_rounded,
  'shop': Icons.storefront_rounded,
  'tasks': Icons.task_alt_rounded,
  'dice': Icons.casino_rounded,
  'home': Icons.home_rounded,
  'me': Icons.person_rounded,
  'ai': Icons.auto_awesome_rounded,
};

const Map<String, Color> _kIconColors = {
  'star': Color(0xFFFFB400),
  'heart': Color(0xFFFF4D6D),
  'check': Color(0xFF22B573),
  'flame': Color(0xFFFF7A1A),
  'coin': Color(0xFFFFB400),
  'trophy': Color(0xFFFFB400),
  'bolt': Color(0xFFFFB400),
  'sparkle': Color(0xFFB36BFF),
  'trash': Color(0xFFE5484D),
};

const Map<String, String> _kEmoji = {
  'egg': '🥚',
  'pet1': '🐣',
  'pet2': '🐥',
  'pet3': '🦉',
  'pet4': '🐲',
  'cat': '🐱',
  'ghost': '👻',
  'alien': '👽',
  'skull': '💀',
  'sword': '⚔️',
  'crown': '👑',
};

const Map<String, String> _kPetEmoji = {
  'cat': '🐱',
  'dog': '🐶',
  'rabbit': '🐰',
  'panda': '🐼',
  'penguin': '🐧',
  'fox': '🦊',
};

/// Modern replacement for the old bitmap sprites: renders a rounded icon or an emoji
/// in the same box the sprite used to occupy, so every layout stays the same.
class Sprite extends StatelessWidget {
  final String name;
  final double px;
  final Color? tint;
  const Sprite(this.name, {super.key, this.px = 3, this.tint});

  @override
  Widget build(BuildContext context) {
    final rows = kSpritesPets[name] ?? kSprites[name] ?? kSpritesExtra[name];
    final cells = rows == null ? 10 : max(rows.map((r) => r.length).reduce(max), rows.length);
    final box = cells * px;
    Widget glyph;
    String? emoji = _kEmoji[name];
    if (emoji == null && name.startsWith('pet_')) {
      emoji = _kPetEmoji[name.split('_')[1]] ?? '🐱';
    }
    if (emoji != null) {
      glyph = Text(emoji, style: TextStyle(fontSize: box * 0.8, height: 1.0));
    } else if (RegExp(r'^[0-9]$').hasMatch(name)) {
      glyph = Text(name,
          style: TextStyle(fontSize: box * 0.95, fontWeight: FontWeight.w900, color: tint ?? C.ink, height: 1.0));
    } else {
      glyph = Icon(_kIcons[name] ?? Icons.star_rounded,
          size: box * 0.95, color: tint ?? _kIconColors[name] ?? C.ink);
    }
    return SizedBox(width: box, height: box, child: Center(child: glyph));
  }
}

/// A premium shaded pet. [frame]: '' stand, '_b' blink, '_h' happy, '_w'/'_v' walk.
class PetSprite extends StatelessWidget {
  final String kind;
  final double size; // width/height in logical pixels
  final String frame;
  const PetSprite(this.kind, {super.key, this.size = 72, this.frame = ''});

  @override
  Widget build(BuildContext context) {
    final k = _kPetEmoji.containsKey(kind) ? kind : 'cat';
    Widget w = SizedBox(
      width: size,
      height: size,
      child: Center(child: Text(_kPetEmoji[k]!, style: TextStyle(fontSize: size * 0.8, height: 1.0))),
    );
    if (frame == '_h') {
      w = Transform.scale(scale: 1.12, child: w);
    } else if (frame == '_w') {
      w = Transform.rotate(angle: -0.09, child: w);
    } else if (frame == '_v') {
      w = Transform.rotate(angle: 0.09, child: w);
    } else if (frame == '_b') {
      w = Transform.scale(scaleY: 0.92, child: w);
    }
    return w;
  }
}

// ───────────────────────── 5x7 bitmap font (Latin caps + digits) ─────────────────────────

const Map<String, List<int>> kGlyphs = {
  'A': [0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11],
  'B': [0x1E, 0x11, 0x11, 0x1E, 0x11, 0x11, 0x1E],
  'C': [0x0E, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0E],
  'D': [0x1E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1E],
  'E': [0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F],
  'F': [0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x10],
  'G': [0x0E, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0F],
  'H': [0x11, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11],
  'I': [0x0E, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0E],
  'J': [0x07, 0x02, 0x02, 0x02, 0x02, 0x12, 0x0C],
  'K': [0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11],
  'L': [0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1F],
  'M': [0x11, 0x1B, 0x15, 0x15, 0x11, 0x11, 0x11],
  'N': [0x11, 0x11, 0x19, 0x15, 0x13, 0x11, 0x11],
  'O': [0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E],
  'P': [0x1E, 0x11, 0x11, 0x1E, 0x10, 0x10, 0x10],
  'Q': [0x0E, 0x11, 0x11, 0x11, 0x15, 0x12, 0x0D],
  'R': [0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11],
  'S': [0x0F, 0x10, 0x10, 0x0E, 0x01, 0x01, 0x1E],
  'T': [0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04],
  'U': [0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E],
  'V': [0x11, 0x11, 0x11, 0x11, 0x11, 0x0A, 0x04],
  'W': [0x11, 0x11, 0x11, 0x15, 0x15, 0x15, 0x0A],
  'X': [0x11, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x11],
  'Y': [0x11, 0x11, 0x11, 0x0A, 0x04, 0x04, 0x04],
  'Z': [0x1F, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1F],
  '0': [0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E],
  '1': [0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E],
  '2': [0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F],
  '3': [0x1F, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0E],
  '4': [0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02],
  '5': [0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E],
  '6': [0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E],
  '7': [0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08],
  '8': [0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E],
  '9': [0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C],
  '.': [0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x0C],
  '-': [0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00],
  '!': [0x04, 0x04, 0x04, 0x04, 0x04, 0x00, 0x04],
  ':': [0x00, 0x0C, 0x0C, 0x00, 0x0C, 0x0C, 0x00],
  '?': [0x0E, 0x11, 0x01, 0x02, 0x04, 0x00, 0x04],
  '+': [0x00, 0x04, 0x04, 0x1F, 0x04, 0x04, 0x00],
  '/': [0x01, 0x01, 0x02, 0x04, 0x08, 0x10, 0x10],
  ' ': [0, 0, 0, 0, 0, 0, 0],
};

class _FontPainter extends CustomPainter {
  final String text;
  final double scale;
  final Color color;
  _FontPainter(this.text, this.scale, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..isAntiAlias = true;
    for (int i = 0; i < text.length; i++) {
      final g = kGlyphs[text[i].toUpperCase()] ?? kGlyphs[' ']!;
      for (int y = 0; y < 7; y++) {
        for (int x = 0; x < 5; x++) {
          if ((g[y] >> (4 - x)) & 1 == 1) {
            canvas.drawRect(
              Rect.fromLTWH((i * 6 + x) * scale, y * scale, scale + 0.4, scale + 0.4),
              p,
            );
          }
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _FontPainter old) =>
      old.text != text || old.scale != scale || old.color != color;
}

/// Text drawn with a hand-made 5x7 pixel font (Latin letters and digits only).
class PixelFont extends StatelessWidget {
  final String text;
  final double scale;
  final Color? color;
  final bool reserve; // keep full width even if [text] is a partial reveal
  final int? reserveLen;
  const PixelFont(this.text,
      {super.key, this.scale = 3, this.color, this.reserve = false, this.reserveLen});

  @override
  Widget build(BuildContext context) {
    final n = reserve ? (reserveLen ?? text.length) : text.length;
    return ConstrainedBox(
      constraints: BoxConstraints(minWidth: reserve ? n * scale * 3.7 : 0),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: scale * 4.6,
          fontWeight: FontWeight.w900,
          letterSpacing: scale * 0.4,
          height: 1.1,
          color: color ?? C.ink,
        ),
      ),
    );
  }
}

// ───────────────────────── Pixel box / button / field ─────────────────────────

Path _notched(Rect r, double u) {
  return Path()
    ..moveTo(r.left + u, r.top)
    ..lineTo(r.right - u, r.top)
    ..lineTo(r.right - u, r.top + u)
    ..lineTo(r.right, r.top + u)
    ..lineTo(r.right, r.bottom - u)
    ..lineTo(r.right - u, r.bottom - u)
    ..lineTo(r.right - u, r.bottom)
    ..lineTo(r.left + u, r.bottom)
    ..lineTo(r.left + u, r.bottom - u)
    ..lineTo(r.left, r.bottom - u)
    ..lineTo(r.left, r.top + u)
    ..lineTo(r.left + u, r.top + u)
    ..close();
}

class _BoxPainter extends CustomPainter {
  final Color fill;
  final Color ink;
  final double u;
  final bool drawShadow;
  final double sh;
  final bool inset;
  final Color? edge; // kept for API compatibility (unused in the brutal look)
  _BoxPainter(this.fill, this.ink, this.u, this.drawShadow, this.sh, this.inset, this.edge);

  @override
  void paint(Canvas canvas, Size size) {
    final r = Offset.zero & size;
    final bw = u <= 2 ? 2.0 : 3.0; // border thickness
    final rad = Radius.circular(u <= 2 ? 6 : 10);
    final p = Paint()..style = PaintingStyle.fill;
    if (drawShadow) {
      p.color = ink;
      canvas.drawRRect(RRect.fromRectAndRadius(r.shift(Offset(sh, sh)), rad), p);
    }
    // border (ink) then flat fill
    p.color = ink;
    canvas.drawRRect(RRect.fromRectAndRadius(r, rad), p);
    p.color = inset ? mix(fill, ink, 0.06) : fill;
    canvas.drawRRect(
        RRect.fromRectAndRadius(r.deflate(bw), Radius.circular(max(0, rad.x - bw))), p);
  }

  @override
  bool shouldRepaint(covariant _BoxPainter old) =>
      old.fill != fill ||
      old.ink != ink ||
      old.u != u ||
      old.drawShadow != drawShadow ||
      old.inset != inset;
}

class PixelBox extends StatelessWidget {
  final Widget? child;
  final Color? color;
  final EdgeInsets padding;
  final bool shadow; // reserve room for the hard shadow
  final bool flat; // keep room but do not paint the shadow (pressed look)
  final double u;
  final bool inset; // sunken look (text fields)
  final Color? edge; // optional trim along the bottom
  const PixelBox({
    super.key,
    this.child,
    this.color,
    this.padding = const EdgeInsets.all(12),
    this.shadow = true,
    this.flat = false,
    this.u = 3,
    this.inset = false,
    this.edge,
  });

  @override
  Widget build(BuildContext context) {
    const sh = 5.0;
    return Padding(
      padding: EdgeInsets.only(right: shadow ? sh : 0, bottom: shadow ? sh : 0),
      child: CustomPaint(
        painter: _BoxPainter(color ?? C.white, C.ink, u, shadow && !flat, sh, inset, edge),
        child: Padding(padding: padding + EdgeInsets.all(u), child: child),
      ),
    );
  }
}

class PixelButton extends StatefulWidget {
  final String? label;
  final String? icon;
  final VoidCallback? onTap;
  final bool filled;
  final bool small;
  final bool busy;
  final bool expand;
  const PixelButton({
    super.key,
    this.label,
    this.icon,
    this.onTap,
    this.filled = true,
    this.small = false,
    this.busy = false,
    this.expand = false,
  });

  @override
  State<PixelButton> createState() => _PixelButtonState();
}

class _PixelButtonState extends State<PixelButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null && !widget.busy;
    final k = AppState.I.btnScale;
    final bg = widget.filled ? C.accent : C.white;
    final fgBtn = widget.filled ? onAccent() : C.ink;
    final content = Row(
      mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (widget.icon != null) Sprite(widget.icon!, px: (widget.small ? 2.2 : 3) * k, tint: fgBtn),
        if (widget.icon != null && widget.label != null) SizedBox(width: 8 * k),
        if (widget.label != null)
          Flexible(
            child: Text(
              widget.label!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: fgBtn,
                fontWeight: FontWeight.w900,
                fontSize: (widget.small ? 14 : 16) * k,
              ),
            ),
          ),
      ],
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => setState(() => _down = true) : null,
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: enabled
          ? () {
              Sfx.play('tap');
              widget.onTap!();
            }
          : null,
      child: Opacity(
        opacity: enabled || widget.busy ? 1 : 0.45,
        child: Transform.translate(
          offset: _down ? const Offset(5, 5) : Offset.zero,
          child: PixelBox(
            color: bg,
            flat: _down,
            padding: EdgeInsets.symmetric(
              horizontal: (widget.small ? 12 : 18) * k,
              vertical: (widget.small ? 9 : 13) * k,
            ),
            child: widget.busy ? PixelLoader(color: fgBtn) : content,
          ),
        ),
      ),
    );
  }
}

class PixelLoader extends StatefulWidget {
  final Color? color;
  const PixelLoader({super.key, this.color});
  @override
  State<PixelLoader> createState() => _PixelLoaderState();
}

class _PixelLoaderState extends State<PixelLoader> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final a = (_c.value * 3).floor();
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (int i = 0; i < 3; i++)
              Container(
                width: 9,
                height: 9,
                margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i == a ? (widget.color ?? C.ink) : (widget.color ?? C.ink).withOpacity(0.3),
                ),
              ),
          ],
        );
      },
    );
  }
}

class PixelField extends StatelessWidget {
  final TextEditingController controller;
  final String? hint;
  final int minLines;
  final int maxLines;
  final bool obscure;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final TextInputType? keyboard;
  final Widget? suffix;
  final TextDirection? dir;
  const PixelField({
    super.key,
    required this.controller,
    this.hint,
    this.minLines = 1,
    this.maxLines = 1,
    this.obscure = false,
    this.onChanged,
    this.onSubmitted,
    this.keyboard,
    this.suffix,
    this.dir,
  });

  @override
  Widget build(BuildContext context) {
    return PixelBox(
      u: 2,
      shadow: false,
      inset: true,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
      child: TextField(
        controller: controller,
        minLines: minLines,
        maxLines: obscure ? 1 : maxLines,
        obscureText: obscure,
        onChanged: onChanged,
        onSubmitted: onSubmitted,
        keyboardType: keyboard,
        textDirection: dir,
        cursorColor: C.ink,
        cursorWidth: 3,
        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: C.ink),
        decoration: InputDecoration(
          isDense: true,
          border: InputBorder.none,
          hintText: hint,
          hintStyle: TextStyle(color: C.gray, fontWeight: FontWeight.w500),
          contentPadding: const EdgeInsets.symmetric(vertical: 11),
          suffixIcon: suffix,
        ),
      ),
    );
  }
}

class PixelChips<T> extends StatelessWidget {
  final List<(T, String)> options;
  final T value;
  final ValueChanged<T> onChanged;
  const PixelChips({super.key, required this.options, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final o in options)
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              onChanged(o.$1);
            },
            child: PixelBox(
              u: 2,
              shadow: false,
              color: o.$1 == value ? C.accent : C.white,
              padding: EdgeInsets.symmetric(
                  horizontal: 12 * AppState.I.btnScale, vertical: 8 * AppState.I.btnScale),
              child: Text(
                o.$2,
                style: TextStyle(
                  fontSize: 14 * AppState.I.btnScale,
                  fontWeight: FontWeight.w800,
                  color: o.$1 == value ? onAccent() : C.ink,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class SpeakBtn extends StatelessWidget {
  final String text;
  final String lang;
  final bool big; // large variant with the engine badge (flashcards)
  const SpeakBtn(this.text, this.lang, {super.key, this.big = false});

  @override
  Widget build(BuildContext context) {
    if (big) {
      final k = AppState.I.btnScale;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => Speech.speak(text, lang),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            PixelBox(
              padding: EdgeInsets.symmetric(horizontal: 22 * k, vertical: 12 * k),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Sprite('speaker', px: 4.2 * k),
                  const SizedBox(width: 10),
                  Text(
                    lang.split('-').first.toUpperCase(),
                    style: TextStyle(fontSize: 16 * k, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            const EngineBadge(),
          ],
        ),
      );
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => Speech.speak(text, lang),
      child: PixelBox(
        u: 2,
        padding: EdgeInsets.symmetric(
            horizontal: 9 * AppState.I.btnScale, vertical: 7 * AppState.I.btnScale),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Sprite('speaker', px: 2.4 * AppState.I.btnScale),
            const SizedBox(width: 5),
            Text(
              lang.split('-').first.toUpperCase(),
              style: TextStyle(fontSize: 12 * AppState.I.btnScale, fontWeight: FontWeight.w900),
            ),
          ],
        ),
      ),
    );
  }
}

/// Section title with a pixel marker.
class PixelTitle extends StatelessWidget {
  final String text;
  const PixelTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 14, bottom: 8),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: C.accent, border: Border.all(color: C.ink, width: 2)),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

Widget tx(String s,
    {double size = 14, bool bold = false, Color? color, TextAlign? align, double? height}) {
  return Text(
    s,
    textAlign: align,
    style: TextStyle(
      fontSize: size,
      color: color ?? C.ink,
      height: height,
      fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
    ),
  );
}

void toast(BuildContext context, String msg) {
  final m = ScaffoldMessenger.maybeOf(context);
  if (m == null) return;
  m.hideCurrentSnackBar();
  m.showSnackBar(
    SnackBar(
      backgroundColor: C.ink,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(),
      duration: const Duration(seconds: 4),
      content: Text(msg, style: TextStyle(color: C.cream, fontWeight: FontWeight.w700)),
    ),
  );
}

/// Full-screen page with a pixel back button.
class PixelPage extends StatelessWidget {
  final String title;
  final Widget child;
  final List<Widget> actions;
  final bool games; // use the "games" background instead of the home one
  const PixelPage(
      {super.key,
      required this.title,
      required this.child,
      this.actions = const [],
      this.games = false});

  @override
  Widget build(BuildContext context) {
    final rtl = Directionality.of(context) == TextDirection.rtl;
    return Scaffold(
      backgroundColor: C.cream,
      body: BgBackdrop(
        id: games ? AppState.I.bgGames : AppState.I.bgHome,
        extra: 0.3,
        child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: Row(
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      Sfx.play('tap');
                      Speech.stop();
                      Navigator.of(context).maybePop();
                    },
                    child: PixelBox(
                      padding: const EdgeInsets.all(8),
                      child: Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.diagonal3Values(rtl ? -1 : 1, 1, 1),
                        child: const Sprite('back', px: 3),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  ),
                  ...actions,
                ],
              ),
            ),
            Expanded(child: child),
          ],
        ),
      ),
      ),
    );
  }
}

// ───────────────────────── Pixel block wipe transition ─────────────────────────

class WipePainter extends CustomPainter {
  final double p; // 0 = nothing covered, 1 = fully covered
  final Color color;
  final int cols;
  WipePainter(this.p, this.color, this.cols);

  @override
  void paint(Canvas canvas, Size size) {
    if (p <= 0) return;
    final cell = size.width / cols;
    final rows = (size.height / cell).ceil();
    final rnd = Random(11);
    final paint = Paint()
      ..color = color
      ..isAntiAlias = true;
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        final th = 0.6 * rnd.nextDouble() + 0.4 * ((c + r) / (cols + rows));
        if (p > th) {
          canvas.drawRect(Rect.fromLTWH(c * cell, r * cell, cell + 0.6, cell + 0.6), paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant WipePainter old) => old.p != p || old.color != color;
}

/// Covers its area with blocks that disappear in a pixel pattern, then removes itself.
class PixelRevealOverlay extends StatefulWidget {
  final Color color;
  final int ms;
  final int cols;
  const PixelRevealOverlay({super.key, required this.color, this.ms = 400, this.cols = 8});

  @override
  State<PixelRevealOverlay> createState() => _PixelRevealOverlayState();
}

class _PixelRevealOverlayState extends State<PixelRevealOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: Duration(milliseconds: widget.ms))..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            if (_c.isCompleted) return const SizedBox.shrink();
            return Opacity(
              opacity: (1 - Curves.easeOut.transform(_c.value)).clamp(0.0, 1.0),
              child: ColoredBox(color: widget.color),
            );
          },
        ),
      ),
    );
  }
}

/// Used by tabs that depend on settings.
Listenable get appListenable => AppState.I;
