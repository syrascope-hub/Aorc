/// Single source of truth for every speech engine.
/// Settings, the voice test screen, the fallback chain and the badge all read
/// this list, so adding or removing an engine is a one-line change here
/// (plus its strings and its `_get` case in speech.dart).
class TtsEngine {
  final String id;
  final bool inChain; // part of the automatic fallback chain
  final bool inTestAll; // tested by "run all" in the voice screen
  const TtsEngine(this.id, {this.inChain = false, this.inTestAll = false});
}

/// ResponsiveVoice web key (same key as the script tag
/// https://code.responsivevoice.org/responsivevoice.js?key=...).
const String kResponsiveVoiceKey = 'qlpAd0be';

/// Order = order shown in Settings. In the automatic chain, engines are tried
/// in this order after the user's chosen one.
const List<TtsEngine> kTtsEngines = [
  TtsEngine('auto'),
  TtsEngine('piper', inChain: true, inTestAll: true),
  TtsEngine('system', inChain: true, inTestAll: true),
  TtsEngine('responsive', inChain: true, inTestAll: true),
  TtsEngine('online', inChain: true, inTestAll: true),
  TtsEngine('slow'),
  TtsEngine('gmirror', inChain: true, inTestAll: true),
  TtsEngine('baidu', inChain: true, inTestAll: true),
  TtsEngine('polly', inChain: true, inTestAll: true),
  TtsEngine('youdao', inChain: true, inTestAll: true),
  TtsEngine('dictapi', inChain: true),
  TtsEngine('hf'),
  TtsEngine('openai'),
];

const List<String> kTtsChain = [
  'piper',
  'system',
  'responsive',
  'online',
  'gmirror',
  'baidu',
  'polly',
  'youdao',
  'dictapi',
];
List<String> get kTtsTestAll => [for (final e in kTtsEngines) if (e.inTestAll) e.id];
bool isKnownEngine(String id) => kTtsEngines.any((e) => e.id == id);

/// Maps an engine id to the key used in `Speech.errors`.
String ttsErrorKey(String engine) => (engine == 'online' || engine == 'slow') ? 'google' : engine;
