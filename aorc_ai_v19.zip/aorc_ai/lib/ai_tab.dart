import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'common.dart';
import 'create_tab.dart';
import 'daily_pack.dart';
import 'dictation.dart';
import 'lessons.dart';
import 'mindmap.dart';
import 'pronounce.dart';
import 'state.dart';
import 'strings.dart';
import 'summarize_tab.dart';
import 'theme.dart';
import 'video_learn.dart';
import 'vision_card.dart';
import 'voice_tutor.dart';

/// Create cards and summarize with AI, plus a sheet of every other AI tool.
class AiTab extends StatelessWidget {
  const AiTab({super.key});

  void _tools(BuildContext context) {
    void go(Widget page, {int need = 0}) {
      Navigator.of(context).pop();
      if (need > 0 && !needCards(context, need)) return;
      pushPage(context, page);
    }

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: C.cream,
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
        side: BorderSide(color: C.ink, width: 3),
      ),
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 20),
          children: [
            menuTile('chat', t('chat'), t('chat_d'), () => go(const ChatScreen(), need: 3)),
            menuTile('sparkle', t('daily_pack'), t('daily_pack_d'), () => go(const DailyPackScreen(), need: 3)),
            menuTile('chat', t('voice_tutor'), t('voice_tutor_d'), () => go(const VoiceTutorScreen(), need: 1)),
            menuTile('camera', t('photo_cards'), t('photo_cards_d'), () => go(const VisionCardScreen())),
            menuTile('mic', t('pronounce'), t('pronounce_d'), () => go(const PronounceScreen(), need: 1)),
            menuTile('mind', t('mindmap'), t('mindmap_d'), () => go(const MindMapScreen())),
            menuTile('summary', t('lessons'), t('lessons_d'), () => go(const LessonsScreen())),
            menuTile('create', t('video_learn'), t('video_learn_d'), () => go(const VideoLearnScreen())),
            menuTile('headphones', t('dictation'), t('dictation_d'), () => go(const DictationScreen())),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return ValueListenableBuilder<int>(
      valueListenable: s.aiSub,
      builder: (context, i, _) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: Row(
              children: [
                Expanded(
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: PixelChips<int>(
                      options: [(0, t('tab_create')), (1, t('tab_sum'))],
                      value: i,
                      onChanged: (v) => s.aiSub.value = v,
                    ),
                  ),
                ),
                PixelButton(
                  label: t('ai_tools'),
                  icon: 'sparkle',
                  small: true,
                  onTap: () => _tools(context),
                ),
              ],
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: i,
              children: const [CreateTab(), SummarizeTab()],
            ),
          ),
        ],
      ),
    );
  }
}
