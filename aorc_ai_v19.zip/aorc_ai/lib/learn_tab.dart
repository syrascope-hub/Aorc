import 'package:flutter/material.dart';

import 'games_tab.dart';
import 'quiz_tab.dart';
import 'state.dart';
import 'stories_tab.dart';
import 'strings.dart';
import 'theme.dart';

/// Games, quiz and stories in one tab with a switcher on top.
class LearnTab extends StatelessWidget {
  const LearnTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return ValueListenableBuilder<int>(
      valueListenable: s.learnSub,
      builder: (context, i, _) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: PixelChips<int>(
                options: [(0, t('tab_games')), (1, t('tab_quiz')), (2, t('tab_stories'))],
                value: i,
                onChanged: (v) => s.learnSub.value = v,
              ),
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: i,
              children: const [GamesTab(), QuizTab(), StoriesTab()],
            ),
          ),
        ],
      ),
    );
  }
}
