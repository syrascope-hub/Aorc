import 'package:flutter/material.dart';

import 'backgrounds.dart';
import 'backup.dart';
import 'common.dart';
import 'decks.dart';
import 'insights.dart';
import 'more_screen.dart';
import 'notifications.dart';
import 'pet.dart';
import 'progress.dart';
import 'quests.dart';
import 'settings_screen.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Profile, rewards, data and settings in one place.
class MeTab extends StatelessWidget {
  const MeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final fg = onAccent();
    void go(Widget page) => pushPage(context, page);
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 110),
        children: [
          PixelBox(
            color: C.accent,
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => go(const PetScreen()),
                  child: s.hasPet
                      ? PetSprite(s.petKind, size: 58)
                      : Sprite(s.mascot, px: 5, tint: fg),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        s.hasPet && s.petName.isNotEmpty ? s.petName : 'AORC AI',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: fg),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Sprite('flame', px: 2.4),
                          const SizedBox(width: 4),
                          tx('${s.streak} ${t('streak_days')}', bold: true, size: 13, color: fg),
                        ],
                      ),
                    ],
                  ),
                ),
                coinChip(),
              ],
            ),
          ),
          const SizedBox(height: 16),
          menuTile('chart', t('progress'), '${s.totalReviews} · ${s.masteredCount}', () => go(const ProgressScreen())),
          menuTile('tasks', t('quests'), t('quests_d'), () => go(const QuestsScreen())),
          menuTile('trophy', t('achievements'), t('achievements_d'), () => go(const AchievementsScreen())),
          menuTile('shop', t('shop'), t('shop_d'), () => go(const ShopScreen())),
          menuTile('sparkle', t('bgs'), t('bgs_d'), () => go(const BgShopScreen())),
          menuTile('chart', t('insights'), t('insights_d'), () => go(const InsightsScreen())),
          menuTile('folder', t('decks'), t('decks_d'), () => go(const DecksScreen())),
          menuTile('save', t('backup'), t('backup_d'), () => go(const BackupScreen())),
          menuTile('bell', t('reminder'), t('reminder_d'), () => go(const ReminderScreen()),
              badge: s.reminderOn ? t('on') : null),
          menuTile('gear', t('settings'), '', () => go(const SettingsScreen())),
          menuTile('more', t('me_all'), t('me_all_d'), () => go(const MoreScreen())),
        ],
      ),
    );
  }
}
