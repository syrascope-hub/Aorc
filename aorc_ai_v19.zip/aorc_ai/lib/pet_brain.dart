import 'dart:math';

import 'common.dart';
import 'state.dart';

/// The pet's offline "brain": a rule/intent engine that works on the phone
/// only. No API, no network, no cost. It understands Arabic and English
/// keywords, reads the learner's own cards and progress, and answers with
/// short replies plus tappable actions.

class PetAction {
  /// tab:N | screen:name | quiz | word | hard | stats | due | joke | feed | play |
  /// speak:<lang>|<text> | ans:N | help
  final String id;
  final String label;
  const PetAction(this.id, this.label);
}

class PetReply {
  final String text;
  final List<PetAction> actions;
  final String face; // '' neutral, '_h' happy, '_b' sleepy/sad
  final String? speak; // '<lang>|<text>' the pet should pronounce
  final String? autoAction; // an action the screen runs instead of showing text
  const PetReply(this.text,
      {this.actions = const [], this.face = '', this.speak, this.autoAction});
}

class PetQuiz {
  final CardItem card;
  final List<String> options;
  final int correct;
  const PetQuiz(this.card, this.options, this.correct);
}

String _l(String ar, String en) => AppState.I.uiLang == 'ar' ? ar : en;

const Map<String, List<String>> _sounds = {
  'cat': ['مياو~', 'Meow~'],
  'dog': ['هاو هاو!', 'Woof woof!'],
  'rabbit': ['*يحرّك أذنيه*', '*wiggles ears*'],
  'panda': ['مممم~', 'Mmm~'],
  'penguin': ['نوت نوت!', 'Noot noot!'],
  'fox': ['يِب!', 'Yip!'],
  'owl': ['هووو~', 'Hoo hoo~'],
  'hamster': ['*يحشو خدّيه*', '*stuffs cheeks*'],
};

class PetBrain {
  static final Random _r = Random();
  static AppState get s => AppState.I;

  static String _sound() {
    final v = _sounds[s.petKind] ?? _sounds['cat']!;
    return s.uiLang == 'ar' ? v[0] : v[1];
  }

  static T _pick<T>(List<T> l) => l[_r.nextInt(l.length)];

  // ───────────── text helpers ─────────────

  static String norm(String x) {
    var n = x.toLowerCase();
    n = n.replaceAll(RegExp('[ً-ْـ]'), '');
    n = n.replaceAll(RegExp('[أإآ]'), 'ا').replaceAll('ى', 'ي').replaceAll('ة', 'ه');
    n = n.replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), ' ');
    return n.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static bool _has(String n, List<String> keys) {
    final padded = ' $n ';
    for (final raw in keys) {
      final k = norm(raw);
      if (k.isEmpty) continue;
      final latinShort = RegExp(r'^[a-z ]+$').hasMatch(k) && k.length < 6;
      if (latinShort) {
        if (padded.contains(' $k ')) return true;
      } else if (n.contains(k)) {
        return true;
      }
    }
    return false;
  }

  // ───────────── cards ─────────────

  static CardItem? _find(String term) {
    final t = norm(term);
    if (t.isEmpty) return null;
    final all = s.cards;
    for (final c in all) {
      if (norm(c.front) == t || norm(c.back) == t) return c;
    }
    for (final c in all) {
      final f = norm(c.front), b = norm(c.back);
      if (t.length >= 3 && (f.contains(t) || b.contains(t))) return c;
    }
    if (t.length >= 4) {
      for (final c in all) {
        if (levenshtein(norm(c.front), t) <= 1) return c;
      }
    }
    return null;
  }

  static String _cardLine(CardItem c) {
    final b = StringBuffer('${c.front}  =  ${c.back}');
    if ((c.example ?? '').trim().isNotEmpty) b.write('\n${c.example!.trim()}');
    return b.toString();
  }

  /// A new multiple choice question from the learner's own cards.
  static PetQuiz? makeQuiz() {
    final pool = s.scope.where((c) => c.front.trim().isNotEmpty && c.back.trim().isNotEmpty).toList();
    if (pool.length < 2) return null;
    final due = pool.where((c) => c.isDue).toList();
    final base = due.isNotEmpty && _r.nextBool() ? due : pool;
    final card = _pick(base);
    final others = pool.where((c) => c.id != card.id && norm(c.back) != norm(card.back)).toList()..shuffle();
    final opts = <String>[card.back, ...others.take(3).map((c) => c.back)]..shuffle();
    return PetQuiz(card, opts, opts.indexOf(card.back));
  }

  // ───────────── proactive tips (home bubble) ─────────────

  static String? tip() {
    if (!s.hasPet) return null;
    final name = s.petName;
    final due = s.dueCount;
    final hour = DateTime.now().hour;
    final tips = <String>[];
    if (s.petFullness < 30) {
      tips.add(_l('$name جوعان! أطعمه من شاشة الحيوان', '$name is hungry! Feed me from the pet screen'));
    }
    if (due > 0) {
      tips.add(_l('عندك $due بطاقة جاهزة للمراجعة', 'You have $due cards ready to review'));
    }
    final left = s.dailyGoal - s.todayCount;
    if (left > 0 && s.cards.isNotEmpty) {
      tips.add(_l('باقي $left بطاقة لتحقق هدفك اليوم', '$left more cards to reach today\'s goal'));
    }
    if (s.todayCount == 0 && s.streak > 0 && hour >= 17) {
      tips.add(_l('لا تضيّع سلسلة ${s.streak} يوم! راجع بطاقة واحدة', 'Don\'t lose your ${s.streak}-day streak! Review one card'));
    }
    if (s.cards.isEmpty) {
      tips.add(_l('أضف أول بطاقاتك وأنا أساعدك!', 'Add your first cards and I\'ll help!'));
    } else {
      final c = _pick(s.cards);
      tips.add(_l('كلمة للمراجعة: ${c.front} = ${c.back}', 'Quick recall: ${c.front} = ${c.back}'));
    }
    tips.add(_l('اضغط عليّ لنتحدث!', 'Tap me to chat!'));
    return _pick(tips);
  }

  // ───────────── greetings ─────────────

  static PetReply welcome() {
    final h = DateTime.now().hour;
    final part = h < 5
        ? _l('سهران؟', 'Up late?')
        : h < 12
            ? _l('صباح الخير!', 'Good morning!')
            : h < 18
                ? _l('أهلاً!', 'Hello!')
                : _l('مساء الخير!', 'Good evening!');
    final due = s.dueCount;
    final line = due > 0
        ? _l('عندك $due بطاقة للمراجعة.', 'You have $due cards to review.')
        : _l('كل شيء مراجَع، أحسنت!', 'Everything is reviewed, nice!');
    return PetReply('${_sound()} $part ${_l('أنا', 'I\'m')} ${s.petName}. $line\n${_l('اسألني أي شيء أو اختر من الأزرار.', 'Ask me anything or pick a button.')}',
        face: '_h', actions: _quick());
  }

  static List<PetAction> _quick() => [
        PetAction('due', _l('ماذا أراجع؟', 'What to review?')),
        PetAction('quiz', _l('اختبرني', 'Quiz me')),
        PetAction('stats', _l('تقدّمي', 'My progress')),
        PetAction('word', _l('كلمة اليوم', 'Word of the day')),
        PetAction('joke', _l('نكتة', 'Joke')),
      ];

  // ───────────── main entry ─────────────

  static PetReply reply(String input) {
    final raw = input.trim();
    final n = norm(raw);
    if (n.isEmpty) return PetReply(_l('لم أسمعك جيداً، حاول مجدداً', 'I didn\'t catch that, try again'), face: '_b');

    // add card:  add apple = تفاحة   /   اضف apple = تفاحة
    final add = RegExp(r'^(add|اضف|أضف|اضافه|إضافة)\s+(.+?)\s*(=|:|-|،|,)\s*(.+)$', caseSensitive: false).firstMatch(raw);
    if (add != null) return _addCard(add.group(2)!.trim(), add.group(4)!.trim());

    // pronounce
    final say = RegExp(r'^(انطق|قل|اقرا|اقرأ|say|pronounce|speak|read)\s+(.+)$', caseSensitive: false).firstMatch(raw);
    if (say != null) {
      final w = say.group(2)!.trim();
      final c = _find(w);
      final lang = (c != null && norm(c.back) == norm(w)) ? s.backLang : s.frontLang;
      return PetReply('${_sound()} “$w”', face: '_h', speak: '$lang|$w');
    }

    // meaning / translation
    final mean = RegExp(r'(ما معنى|ماذا تعني|معنى|ما ترجمه|ترجم|ترجمه|what does|meaning of|translate|how do you say)\s*(.*)', caseSensitive: false)
        .firstMatch(n);
    if (mean != null) {
      var term = mean.group(2) ?? '';
      term = term.replaceAll(RegExp(r'\b(mean|means|in english|in arabic)\b'), '').replaceAll(RegExp(r'^(كلمه|كلمة|word)\s+'), '').trim();
      if (term.isNotEmpty) return _lookup(term);
    }

    if (_has(n, ['شكرا', 'شكراً', 'thanks', 'thank you', 'thx'])) {
      return PetReply('${_sound()} ${_pick([_l('على الرحب والسعة!', 'Anytime!'), _l('أنا سعيد بمساعدتك', 'Happy to help!'), _l('أنت رائع!', 'You\'re awesome!')])}', face: '_h');
    }
    if (_has(n, ['مع السلامه', 'وداعا', 'bye', 'goodbye', 'see you', 'سلام'])) {
      return PetReply('${_sound()} ${_l('إلى اللقاء! لا تنسَ مراجعتك غداً', 'See you! Don\'t forget tomorrow\'s review')}', face: '_h');
    }

    if (_has(n, ['اختبرني', 'اختبار سريع', 'سؤال', 'quiz me', 'test me', 'quiz', 'اسالني'])) {
      return const PetReply('', autoAction: 'quiz');
    }
    if (_has(n, ['كلمه اليوم', 'كلمه جديده', 'word of the day', 'random word', 'اعطني كلمه'])) return wordOfDay();
    if (_has(n, ['صعبه', 'اخطاء', 'ضعيفه', 'hard words', 'difficult', 'mistakes', 'weak'])) return hardWords();
    if (_has(n, ['ماذا اراجع', 'ماذا اذاكر', 'ماذا ادرس', 'اراجع', 'مراجعه', 'what should i', 'review', 'study', 'due', 'اذاكر', 'ادرس'])) return dueInfo();
    if (_has(n, ['تقدمي', 'احصائيات', 'احصاءات', 'تقدم', 'سلسله', 'كم بطاقه', 'stats', 'progress', 'streak', 'how am i doing', 'how many cards'])) return statsInfo();
    if (_has(n, ['هدفي', 'هدف اليوم', 'daily goal', 'goal'])) return goalInfo();

    if (_has(n, ['جوعان', 'اطعمني', 'اكل', 'feed', 'hungry', 'food'])) {
      final f = s.petFullness.round();
      return PetReply(
          f < 40
              ? '${_sound()} ${_l('نعم جوعان ($f%)! الإطعام يكلّف $kFeed عملات', 'Yes, hungry ($f%)! Feeding costs $kFeed coins')}'
              : '${_sound()} ${_l('أنا شبعان ($f%) شكراً!', 'I\'m full ($f%), thanks!')}',
          face: f < 40 ? '_b' : '_h',
          actions: [PetAction('feed', _l('أطعمه', 'Feed'))]);
    }
    if (_has(n, ['العب', 'نلعب', 'play with', 'play', 'مللت', 'bored'])) {
      return PetReply('${_sound()} ${_l('هيا نلعب!', 'Let\'s play!')}', face: '_h', actions: [PetAction('play', _l('العب معه', 'Play'))]);
    }
    if (_has(n, ['كيف حالك', 'كيفك', 'شلونك', 'how are you', 'how r u', 'whats up', 'ما اخبارك'])) return mood();

    if (_has(n, ['حفزني', 'تحفيز', 'شجعني', 'motivate', 'motivation', 'encourage', 'inspire'])) return motivate();
    if (_has(n, ['نكته', 'اضحكني', 'joke', 'funny', 'make me laugh'])) return joke();
    if (_has(n, ['كم الساعه', 'الوقت', 'التاريخ', 'اي يوم', 'what time', 'time is it', 'date', 'what day'])) return timeInfo();
    if (_has(n, ['ما اسمك', 'من انت', 'who are you', 'your name', 'what are you'])) {
      return PetReply('${_sound()} ${_l('أنا ${s.petName}، مساعدك الصغير. أعمل بدون إنترنت وبدون أي مفتاح!', 'I\'m ${s.petName}, your little helper. I work offline, no key needed!')}', face: '_h');
    }

    // how-to / feature help
    final h = _help(n);
    if (h != null) return h;

    if (_has(n, ['ماذا تستطيع', 'مساعده', 'ساعدني', 'help', 'what can you do', 'commands', 'اوامر'])) return helpMenu();

    if (_has(n, ['مرحبا', 'اهلا', 'هلا', 'السلام عليكم', 'صباح الخير', 'مساء الخير', 'hello', 'hi', 'hey', 'good morning', 'good evening'])) {
      return PetReply('${_sound()} ${_pick([_l('أهلاً بك!', 'Hello there!'), _l('مرحباً! جاهز للتعلّم؟', 'Hi! Ready to learn?'), _l('يا هلا!', 'Hey!')])}', face: '_h', actions: _quick());
    }

    // last resort: maybe the text is one of the user's words
    final c = _find(raw);
    if (c != null) return _cardReply(c);

    return PetReply(
      '${_sound()} ${_l('لم أفهم تماماً. جرّب: "ماذا أراجع؟" أو "معنى apple" أو "اضف cat = قطة".', 'I\'m not sure I got that. Try "what to review?", "meaning of apple" or "add cat = قطة".')}',
      face: '_b',
      actions: [PetAction('help', _l('ماذا تستطيع؟', 'What can you do?')), ..._quick().take(2)],
    );
  }

  static const int kFeed = 5;

  // ───────────── intents ─────────────

  static PetReply _addCard(String front, String back) {
    if (front.isEmpty || back.isEmpty) {
      return PetReply(_l('اكتب: اضف كلمة = معناها', 'Write: add word = meaning'), face: '_b');
    }
    final exists = _find(front);
    if (exists != null && norm(exists.front) == norm(front)) {
      return PetReply('${_sound()} ${_l('هذه البطاقة موجودة أصلاً:', 'That card already exists:')}\n${_cardLine(exists)}', face: '_b');
    }
    final c = CardItem(id: s.newId(), front: front, back: back);
    s.addCard(c);
    return PetReply('${_sound()} ${_l('أضفت بطاقة:', 'Added a card:')}\n$front  =  $back', face: '_h', speak: '${s.frontLang}|$front', actions: [PetAction('quiz', _l('اختبرني', 'Quiz me'))]);
  }

  static PetReply _cardReply(CardItem c) {
    return PetReply('${_sound()}\n${_cardLine(c)}', face: '_h', speak: '${s.frontLang}|${c.front}', actions: [PetAction('speak:${s.frontLang}|${c.front}', _l('انطقها', 'Pronounce'))]);
  }

  static PetReply _lookup(String term) {
    final c = _find(term);
    if (c != null) return _cardReply(c);
    return PetReply(
      '${_sound()} ${_l('"$term" ليست في بطاقاتك. أضفها هكذا: اضف $term = المعنى', '"$term" isn\'t in your cards. Add it like: add $term = meaning')}',
      face: '_b',
      actions: [PetAction('tab:0', _l('إنشاء بطاقات', 'Create cards'))],
    );
  }

  /// Reply shown when a quiz cannot start (not enough cards).
  static PetReply quizUnavailable() {
    {
      return PetReply('${_sound()} ${_l('أحتاج بطاقتين على الأقل لأختبرك. أضف بعض الكلمات أولاً!', 'I need at least 2 cards to quiz you. Add some words first!')}',
          face: '_b', actions: [PetAction('tab:0', _l('إنشاء بطاقات', 'Create cards'))]);
    }
  }

  static PetReply quizQuestion(PetQuiz q) {
    return PetReply(_l('ما معنى: ${q.card.front} ؟', 'What does “${q.card.front}” mean?'),
        actions: [for (int i = 0; i < q.options.length; i++) PetAction('ans:$i', q.options[i])],
        speak: '${s.frontLang}|${q.card.front}');
  }

  static PetReply feedback(PetQuiz q, bool ok) {
    final praise = [
      _l('صحيح! أحسنت', 'Correct! Well done'),
      _l('ممتاز! استمر', 'Excellent! Keep going'),
      _l('إجابة رائعة', 'Great answer'),
    ];
    return PetReply(
      ok
          ? '${_sound()} ${_pick(praise)} ✓'
          : '${_sound()} ${_l('الجواب الصحيح:', 'Correct answer:')} ${q.card.front} = ${q.card.back}',
      face: ok ? '_h' : '_b',
      actions: [PetAction('quiz', _l('سؤال آخر', 'Next question')), PetAction('stats', _l('تقدّمي', 'My progress'))],
    );
  }

  static PetReply wordOfDay() {
    if (s.cards.isEmpty) {
      return PetReply('${_sound()} ${_l('لا توجد بطاقات بعد. أضف كلماتك!', 'No cards yet. Add some words!')}', face: '_b', actions: [PetAction('tab:0', _l('إنشاء بطاقات', 'Create cards'))]);
    }
    final today = DateTime.now();
    final seed = today.year * 400 + today.month * 31 + today.day;
    final c = s.cards[Random(seed).nextInt(s.cards.length)];
    return PetReply('${_sound()} ${_l('كلمة اليوم:', 'Word of the day:')}\n${_cardLine(c)}', face: '_h', speak: '${s.frontLang}|${c.front}', actions: [PetAction('speak:${s.frontLang}|${c.front}', _l('انطقها', 'Pronounce'))]);
  }

  static PetReply hardWords() {
    final hard = s.cards.where((c) => c.wrong > 0).toList()..sort((a, b) => (b.wrong - b.right).compareTo(a.wrong - a.right));
    if (hard.isEmpty) return PetReply('${_sound()} ${_l('لا توجد كلمات صعبة، أنت رائع!', 'No hard words yet, great job!')}', face: '_h');
    final top = hard.take(5).map((c) => '• ${c.front} = ${c.back}  (✗${c.wrong})').join('\n');
    return PetReply('${_sound()} ${_l('أكثر كلماتك صعوبة:', 'Your toughest words:')}\n$top', face: '_b', actions: [PetAction('quiz', _l('اختبرني', 'Quiz me')), PetAction('tab:1', _l('راجعها', 'Review'))]);
  }

  static PetReply dueInfo() {
    final due = s.dueCount;
    if (s.cards.isEmpty) {
      return PetReply('${_sound()} ${_l('ابدأ بإضافة بطاقات أولاً.', 'Start by adding some cards.')}', face: '_b', actions: [PetAction('tab:0', _l('إنشاء بطاقات', 'Create cards'))]);
    }
    if (due == 0) {
      return PetReply('${_sound()} ${_l('لا شيء مستحق الآن. يمكنك اختبار نفسك أو تعلّم كلمات جديدة.', 'Nothing due now. Quiz yourself or learn new words.')}', face: '_h', actions: [PetAction('quiz', _l('اختبرني', 'Quiz me')), PetAction('tab:0', _l('أضف كلمات', 'Add words'))]);
    }
    return PetReply('${_sound()} ${_l('عندك $due بطاقة جاهزة للمراجعة الآن. الأفضل أن تبدأ!', 'You have $due cards due now. Let\'s start!')}', face: '_h', actions: [PetAction('tab:1', _l('ابدأ المراجعة', 'Start review'))]);
  }

  static PetReply statsInfo() {
    final b = StringBuffer(_sound());
    b.writeln();
    b.writeln(_l('📚 البطاقات: ${s.cards.length}', '📚 Cards: ${s.cards.length}'));
    b.writeln(_l('⏰ للمراجعة: ${s.dueCount}', '⏰ Due: ${s.dueCount}'));
    b.writeln(_l('🔥 السلسلة: ${s.streak} يوم (الأفضل ${s.bestStreak})', '🔥 Streak: ${s.streak} days (best ${s.bestStreak})'));
    b.writeln(_l('✅ اليوم: ${s.todayCount}/${s.dailyGoal}', '✅ Today: ${s.todayCount}/${s.dailyGoal}'));
    b.writeln(_l('🏆 متقَنة: ${s.masteredCount}', '🏆 Mastered: ${s.masteredCount}'));
    b.write(_l('🪙 العملات: ${s.coins}', '🪙 Coins: ${s.coins}'));
    return PetReply(b.toString(), face: '_h', actions: [PetAction('screen:progress', _l('التفاصيل', 'Details'))]);
  }

  static PetReply goalInfo() {
    final left = s.dailyGoal - s.todayCount;
    return PetReply(
      left <= 0
          ? '${_sound()} ${_l('حققت هدف اليوم (${s.dailyGoal})! 🎉', 'Daily goal reached (${s.dailyGoal})! 🎉')}'
          : '${_sound()} ${_l('باقي $left بطاقة لهدف اليوم (${s.dailyGoal}).', '$left more cards for today\'s goal (${s.dailyGoal}).')}',
      face: left <= 0 ? '_h' : '',
      actions: left <= 0 ? const [] : [PetAction('tab:1', _l('ابدأ المراجعة', 'Start review'))],
    );
  }

  static PetReply mood() {
    final f = s.petFullness, j = s.petJoy;
    String m;
    String face = '_h';
    if (f < 25) {
      m = _l('جوعان قليلاً...', 'A little hungry...');
      face = '_b';
    } else if (j < 25) {
      m = _l('أشتاق للعب معك', 'I miss playing with you');
      face = '_b';
    } else if (f > 70 && j > 70) {
      m = _l('أنا في قمة السعادة!', 'I\'m super happy!');
    } else {
      m = _l('بخير، شكراً لسؤالك', 'Doing fine, thanks for asking');
    }
    return PetReply('${_sound()} $m', face: face, actions: [PetAction('feed', _l('أطعمه', 'Feed')), PetAction('play', _l('العب معه', 'Play'))]);
  }

  static PetReply motivate() {
    final l = [
      _l('كل بطاقة تراجعها تقرّبك من الطلاقة. استمر!', 'Every card you review brings you closer to fluency. Keep going!'),
      _l('الاستمرار اليومي أقوى من الدراسة الطويلة مرة واحدة.', 'Daily practice beats one long session.'),
      _l('الخطأ جزء من التعلّم، وأنا فخور بك!', 'Mistakes are part of learning, and I\'m proud of you!'),
      _l('10 دقائق اليوم أفضل من ساعة كل أسبوع.', '10 minutes today beats an hour once a week.'),
      _l('أنت أقرب مما تظن. بطاقة واحدة فقط الآن!', 'You\'re closer than you think. Just one card now!'),
    ];
    return PetReply('${_sound()} ${_pick(l)}', face: '_h', actions: [PetAction('tab:1', _l('ابدأ', 'Start'))]);
  }

  static PetReply joke() {
    final l = [
      _l('لماذا أخذ الطالب سلّماً إلى المدرسة؟ لأنه سمع أن التعليم عالٍ!', 'Why did the student bring a ladder to school? Because he heard it was high school!'),
      _l('ما أسرع لغة في العالم؟ اللغة التي تنساها قبل مراجعتها!', 'What\'s the fastest language to learn? The one you review on time!'),
      _l('قال المعلم: كرّر خلفي. فقال الببغاء: أنا أصلاً أفعل ذلك بلا بطاقات!', 'Teacher: repeat after me. Parrot: I already do that without flashcards!'),
      _l('أنا لا أنسى الكلمات... أنا فقط أؤجّل تذكّرها.', 'I never forget words... I just remember them later.'),
      _l('لماذا الكتاب حزين؟ لأن عنده مشاكل كثيرة!', 'Why is the math book sad? It has too many problems!'),
    ];
    return PetReply('${_sound()} ${_pick(l)}', face: '_h', actions: [PetAction('joke', _l('نكتة أخرى', 'Another'))]);
  }

  static PetReply timeInfo() {
    final d = DateTime.now();
    const arDays = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
    const enDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    final hh = d.hour.toString().padLeft(2, '0');
    final mm = d.minute.toString().padLeft(2, '0');
    final day = s.uiLang == 'ar' ? arDays[d.weekday - 1] : enDays[d.weekday - 1];
    return PetReply('${_sound()} $day ${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}  $hh:$mm', face: '_h');
  }

  static PetReply helpMenu() {
    return PetReply(
      '${_sound()} ${_l('أستطيع:', 'I can:')}\n'
      '• ${_l('اختبارك من بطاقاتك: "اختبرني"', 'Quiz you from your cards: "quiz me"')}\n'
      '• ${_l('معنى كلمة: "معنى apple"', 'Look up a word: "meaning of apple"')}\n'
      '• ${_l('إضافة بطاقة: "اضف cat = قطة"', 'Add a card: "add cat = قطة"')}\n'
      '• ${_l('نطق كلمة: "انطق hello"', 'Pronounce: "say hello"')}\n'
      '• ${_l('تقدمك، أهدافك، كلمة اليوم، كلماتك الصعبة', 'Your progress, goal, word of the day, hard words')}\n'
      '• ${_l('شرح التطبيق: "كيف أنشئ بطاقات؟"', 'Explain the app: "how do I create cards?"')}\n'
      '${_l('وكل ذلك بدون إنترنت أو مفتاح.', 'All of it offline, no key needed.')}',
      face: '_h',
      actions: _quick(),
    );
  }

  static PetReply? _help(String n) {
    PetReply r(String ar, String en, List<PetAction> a) => PetReply('${_sound()} ${_l(ar, en)}', face: '_h', actions: a);

    if (_has(n, ['الصوت لا يعمل', 'لا يوجد صوت', 'لا اسمع', 'مشكله الصوت', 'نطق لا يعمل', 'no sound', 'voice not working', 'cant hear', 'tts', 'سماعه'])) {
      return r('افتح شاشة اختبار الصوت: تجرّب كل المحركات وتعرف أيها يعمل ولماذا يفشل الباقي.', 'Open the voice test: it tries every engine and shows which works and why the others fail.',
          [PetAction('screen:voice', _l('اختبار الصوت', 'Voice test'))]);
    }
    if (_has(n, ['كيف انشئ', 'كيف اضيف', 'انشاء بطاقات', 'اضافه بطاقات', 'create card', 'add card', 'new card', 'make flashcards'])) {
      return r('تبويب "إنشاء": اكتب كلمة ومعناها يدوياً، أو الصق نصاً بصيغة كلمة، ترجمة (سطر لكل بطاقة). أو اكتب لي: اضف كلمة = معنى', 'In the Create tab type a word and its meaning, or paste lines like word, translation. Or tell me: add word = meaning',
          [PetAction('tab:0', _l('افتح إنشاء', 'Open Create'))]);
    }
    if (_has(n, ['العاب', 'لعبه', 'games', 'game'])) {
      return r('تبويب الألعاب فيه تحديات لحفظ الكلمات وتجمع منها عملات.', 'The Games tab has word challenges that earn you coins.', [PetAction('tab:2', _l('افتح الألعاب', 'Open Games'))]);
    }
    if (_has(n, ['تلخيص', 'لخص', 'summarize', 'summary'])) {
      return r('تبويب التلخيص يلخّص نصاً أو PDF أو فيديو يوتيوب (يحتاج مفتاح AI من الإعدادات).', 'The Summary tab condenses text, PDFs or YouTube (needs an AI key in Settings).', [PetAction('tab:3', _l('افتح التلخيص', 'Open Summary'))]);
    }
    if (_has(n, ['قصه', 'قصص', 'story', 'stories'])) {
      return r('تبويب القصص يكتب قصة من كلماتك لتراها في سياق.', 'The Stories tab writes a story from your words so you see them in context.', [PetAction('tab:5', _l('افتح القصص', 'Open Stories'))]);
    }
    if (_has(n, ['مفتاح', 'api', 'ذكاء اصطناعي', 'مزود', 'provider', 'token', 'settings', 'اعدادات', 'الاعدادات'])) {
      return r('مفتاح الذكاء الاصطناعي والمزوّد واللغات والمظهر كلها في الإعدادات. أنا لا أحتاج لأي منها.', 'The AI key, provider, languages and theme are in Settings. I don\'t need any of them.', [PetAction('screen:settings', _l('الإعدادات', 'Settings'))]);
    }
    if (_has(n, ['تركيز', 'بومودورو', 'focus', 'pomodoro', 'timer', 'مؤقت'])) {
      return r('وضع التركيز: مؤقت دراسة بدون تشتيت.', 'Focus mode: a distraction-free study timer.', [PetAction('screen:focus', _l('وضع التركيز', 'Focus mode'))]);
    }
    if (_has(n, ['نسخه احتياطيه', 'استرجاع', 'backup', 'restore', 'export'])) {
      return r('النسخ الاحتياطي يحفظ بطاقاتك وتقدمك في ملف يمكنك استرجاعه.', 'Backup saves your cards and progress to a file you can restore.', [PetAction('screen:backup', _l('النسخ الاحتياطي', 'Backup'))]);
    }
    if (_has(n, ['متجر', 'عملات', 'shop', 'coins', 'خلفيات', 'backgrounds'])) {
      return r('تكسب عملة عن كل مراجعة. أنفقها على الخلفيات والشخصيات من القائمة (⋯).', 'You earn a coin per review. Spend them on backgrounds and skins from the ⋯ menu.', [PetAction('screen:shop', _l('المتجر', 'Shop'))]);
    }
    return null;
  }
}
