import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'common.dart';
import 'pet_brain.dart';
import 'pet_chat.dart';
import 'state.dart';
import 'theme.dart';

/// Your pet walks along the bottom of the home screen, rests sometimes, sleeps
/// at night, shows an offline helper tip every so often and opens the chat when
/// tapped. Only the pet and its bubble take touches; everything else passes through.
class PetRoamer extends StatefulWidget {
  const PetRoamer({super.key});

  @override
  State<PetRoamer> createState() => _PetRoamerState();
}

class _PetRoamerState extends State<PetRoamer> with SingleTickerProviderStateMixin {
  late final Ticker _tk;
  final Random _r = Random();
  double _x = 30;
  double _dir = 1;
  double _pause = 0;
  double _acc = 0;
  double _w = 360;
  bool _bob = false;
  Duration _prev = Duration.zero;
  String? _tip;
  Timer? _tipT;
  Timer? _hideT;
  bool _happy = false;

  static const double _size = 44; // sprite size in logical pixels

  bool get _asleep {
    final h = DateTime.now().hour;
    return h >= 22 || h < 6;
  }

  @override
  void initState() {
    super.initState();
    _tk = createTicker(_step)..start();
    _tipT = Timer.periodic(const Duration(seconds: 45), (_) => _showTip());
    Future<void>.delayed(const Duration(seconds: 4), _showTip);
  }

  @override
  void dispose() {
    _tk.dispose();
    _tipT?.cancel();
    _hideT?.cancel();
    super.dispose();
  }

  void _showTip() {
    if (!mounted || _asleep) return;
    final tip = PetBrain.tip();
    if (tip == null) return;
    setState(() => _tip = tip);
    _hideT?.cancel();
    _hideT = Timer(const Duration(seconds: 7), () {
      if (mounted) setState(() => _tip = null);
    });
  }

  void _open() {
    setState(() {
      _tip = null;
      _happy = true;
    });
    Future<void>.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _happy = false);
    });
    pushPage(context, const PetChatScreen());
  }

  void _step(Duration d) {
    final dt = ((d - _prev).inMicroseconds / 1000000.0).clamp(0.0, 0.2);
    _prev = d;
    _acc += dt;
    if (_acc < 0.16) return;
    final step = _acc;
    _acc = 0;
    if (!AppState.I.bgMotion || _asleep || AppState.I.petJoy < 25) {
      return;
    }
    if (_pause > 0) {
      _pause -= step;
      _bob = false;
    } else {
      _x += _dir * 22 * step;
      _bob = !_bob;
      final maxX = max(0.0, _w - _size - 4);
      if (_x < 0) {
        _x = 0;
        _dir = 1;
      } else if (_x > maxX) {
        _x = maxX;
        _dir = -1;
      }
      if (_r.nextDouble() < 0.03) _pause = 1 + _r.nextDouble() * 3;
      if (_r.nextDouble() < 0.01) _dir = -_dir;
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        _w = c.maxWidth;
        final asleep = _asleep;
        final walking = _pause <= 0 && !asleep && AppState.I.petJoy >= 25 && AppState.I.bgMotion;
        final frame = asleep
            ? '_b'
            : _happy
                ? '_h'
                : walking
                    ? (_bob ? '_w' : '_v')
                    : (AppState.I.petJoy < 25 || AppState.I.petFullness < 25 ? '_b' : '');
        final sprite = PetSprite(AppState.I.petKind, size: _size, frame: frame);
        final bubbleLeft = (_x - 10).clamp(4.0, max(4.0, _w - 210)).toDouble();
        return Stack(
          textDirection: TextDirection.ltr,
          clipBehavior: Clip.none,
          children: [
            if (_tip != null)
              Positioned(
                left: bubbleLeft,
                bottom: _size + 6,
                child: GestureDetector(
                  onTap: _open,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 200),
                    child: PixelBox(
                      u: 2,
                      color: C.white,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      child: Text(_tip!,
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: C.ink)),
                    ),
                  ),
                ),
              ),
            Positioned(
              left: _x,
              bottom: 0,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _open,
                child: Opacity(
                  opacity: asleep ? 0.8 : 1,
                  child: Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.diagonal3Values(_dir < 0 ? -1 : 1, 1, 1),
                    child: Transform.translate(
                      offset: Offset(0, _bob && walking ? -2 : 0),
                      child: sprite,
                    ),
                  ),
                ),
              ),
            ),
            if (asleep)
              Positioned(
                left: _x + 30,
                bottom: 30,
                child: Text('z Z',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: C.dark)),
              ),
          ],
        );
      },
    );
  }
}
