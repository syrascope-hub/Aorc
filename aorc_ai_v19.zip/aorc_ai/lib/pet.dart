import 'dart:math';

import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'pet_chat.dart';
import 'sprites_pets.dart';
import 'theme.dart';

const List<String> kPetKinds = kPetKinds2;
const int kFeedCost = 5;

/// Virtual pet: grows with your reviews, gets hungry and lonely over time.
class PetScreen extends StatefulWidget {
  const PetScreen({super.key});
  @override
  State<PetScreen> createState() => _PetScreenState();
}

class _PetScreenState extends State<PetScreen> with TickerProviderStateMixin {
  AppState get s => AppState.I;
  late final AnimationController _idle =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();
  late final AnimationController _jump =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 520));
  final TextEditingController _name = TextEditingController();
  String _pick = 'cat';
  String _bubble = '';

  @override
  void dispose() {
    _idle.dispose();
    _jump.dispose();
    _name.dispose();
    super.dispose();
  }

  bool _happy = false;

  String _frame() {
    if (_happy || _jump.isAnimating) return '_h';
    final f = s.petFullness, j = s.petJoy;
    if (f < 25 || j < 25) return '_b'; // tired / hungry: eyes half shut
    return _idle.value > 0.9 ? '_b' : '';
  }

  void _say(String key) => setState(() => _bubble = t(key));

  Future<void> _tapPet() async {
    _jump.forward(from: 0);
    _happy = true;
    Future<void>.delayed(const Duration(milliseconds: 1400), () {
      if (mounted) setState(() => _happy = false);
    });
    Sfx.play('ok');
    await s.playWithPet();
    _say('pet_play_msg');
  }

  Future<void> _feed() async {
    if (!await s.feedPet(kFeedCost)) {
      if (mounted) toast(context, t('pet_no_coins'));
      return;
    }
    _jump.forward(from: 0);
    Sfx.play('win');
    _say('pet_fed_msg');
  }

  String _mood() {
    final f = s.petFullness;
    final j = s.petJoy;
    if (f < 25) return t('pet_hungry');
    if (j < 25) return t('pet_lonely');
    if (f > 70 && j > 70) return t('pet_great');
    return t('pet_ok');
  }

  Widget _bar(String label, double v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          SizedBox(width: 88, child: tx(label, bold: true, size: 14)),
          Expanded(
            child: Row(
              children: [
                for (int i = 0; i < 10; i++)
                  Expanded(
                    child: Container(
                      height: 16,
                      margin: const EdgeInsets.symmetric(horizontal: 1.5),
                      color: v >= i * 10 + 5 ? C.ink : C.light,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(width: 40, child: tx('${v.round()}%', size: 13, bold: true)),
        ],
      ),
    );
  }

  Widget _adopt() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        infoBox(t('pet_adopt_help')),
        const SizedBox(height: 14),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1,
          children: [
            for (final k in kPetKinds)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  Sfx.play('flip');
                  setState(() => _pick = k);
                },
                child: PixelBox(
                  color: _pick == k ? C.creamDeep : C.white,
                  padding: const EdgeInsets.all(8),
                  child: Center(child: PetSprite(k, size: 68, frame: _pick == k ? '_h' : '')),
                ),
              ),
          ],
        ),
        const SizedBox(height: 14),
        tx(t('pet_name'), size: 13, color: C.dark),
        const SizedBox(height: 4),
        PixelField(controller: _name, hint: t('pet_name_hint')),
        const SizedBox(height: 16),
        PixelButton(
          label: t('pet_adopt'),
          icon: 'heart',
          expand: true,
          onTap: () async {
            await s.adoptPet(_pick, _name.text);
            Sfx.play('win');
            if (mounted) setState(() => _bubble = t('pet_hello'));
          },
        ),
      ],
    );
  }

  Widget _home() {
    final kind = s.petKind;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        PixelBox(
          color: C.white,
          padding: const EdgeInsets.fromLTRB(14, 18, 14, 14),
          child: Column(
            children: [
              SizedBox(
                height: 28,
                child: _bubble.isEmpty
                    ? null
                    : Center(child: tx(_bubble, size: 14, bold: true, align: TextAlign.center)),
              ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _tapPet,
                child: SizedBox(
                  height: 190,
                  child: Center(
                    child: AnimatedBuilder(
                      animation: Listenable.merge([_idle, _jump]),
                      builder: (_, __) {
                        final bob = sin(_idle.value * 2 * pi) * 4;
                        final up = sin(_jump.value * pi) * 46;
                        return Transform.translate(
                          offset: Offset(0, bob - up),
                          child: PetSprite(kind, size: 192, frame: _frame()),
                        );
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              tx(s.petName, size: 22, bold: true),
              tx('${t('level')} ${s.petLevel}', size: 13, color: C.dark),
              const SizedBox(height: 4),
              tx(_mood(), size: 13.5, color: C.dark, align: TextAlign.center),
            ],
          ),
        ),
        const SizedBox(height: 14),
        PixelButton(
          label: t('pc_open'),
          icon: 'chat',
          expand: true,
          onTap: () => pushPage(context, const PetChatScreen()),
        ),
        const SizedBox(height: 14),
        _bar(t('pet_food'), s.petFullness),
        _bar(t('pet_joy'), s.petJoy),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: PixelButton(
                label: '${t('pet_feed')}  $kFeedCost',
                icon: 'coin',
                onTap: _feed,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PixelButton(
                label: t('pet_play'),
                icon: 'heart',
                filled: false,
                onTap: _tapPet,
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        infoBox(t('pet_help')),
        const SizedBox(height: 14),
        PixelButton(
          label: t('pet_change'),
          small: true,
          filled: false,
          expand: true,
          onTap: () async {
            if (await confirmDialog(context, t('pet_change_confirm'))) {
              await s.releasePet();
              if (mounted) setState(() => _bubble = '');
            }
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('pet'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => s.hasPet ? _home() : _adopt(),
      ),
    );
  }
}
