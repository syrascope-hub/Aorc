import 'package:flutter/material.dart';

import 'backgrounds.dart';
import 'home.dart';
import 'onboarding.dart';
import 'state.dart';
import 'services.dart';
import 'strings.dart';
import 'theme.dart';

/// Bold animated splash. Plays on every launch, then fades into the app.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2600));
  late final AnimationController _w =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
  static const String _logo = 'AORC AI';

  @override
  void initState() {
    super.initState();
    Sfx.play('start');
    _c.forward().then((_) {
      if (!mounted) return;
      _w.forward().then((_) {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            transitionDuration: Duration.zero,
            pageBuilder: (_, __, ___) =>
                AppState.I.onboarded ? const HomeShell(reveal: true) : const OnboardingScreen(),
          ),
        );
      });
    });
  }

  @override
  void dispose() {
    _c.dispose();
    _w.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.cream,
      body: BgBackdrop(
        id: 'none',
        child: AnimatedBuilder(
          animation: Listenable.merge([_c, _w]),
          builder: (context, _) {
            final v = _c.value;
            final pop = Curves.elasticOut.transform((v / 0.45).clamp(0.0, 1.0));
            final textIn = Curves.easeOutCubic.transform(((v - 0.3) / 0.3).clamp(0.0, 1.0));
            final subIn = ((v - 0.6) / 0.2).clamp(0.0, 1.0);
            return Stack(
              children: [
                Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Transform.scale(
                        scale: 0.2 + 0.8 * pop,
                        child: Transform.rotate(
                          angle: (1 - pop) * -0.35,
                          child: PixelBox(
                            color: C.accent,
                            padding: const EdgeInsets.all(22),
                            child: Icon(Icons.smart_toy_rounded, size: 84, color: onAccent()),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      Opacity(
                        opacity: textIn,
                        child: Transform.translate(
                          offset: Offset(0, 18 * (1 - textIn)),
                          child: const PixelFont(_logo, scale: 7),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 24,
                        child: Opacity(
                          opacity: subIn,
                          child: tx(t('splash_sub'), size: 15, bold: true, color: C.dark),
                        ),
                      ),
                      const SizedBox(height: 34),
                      SizedBox(
                        width: 200,
                        child: PixelBox(
                          u: 2,
                          shadow: false,
                          padding: const EdgeInsets.all(3),
                          child: Align(
                            alignment: AlignmentDirectional.centerStart,
                            child: FractionallySizedBox(
                              widthFactor: v.clamp(0.04, 1.0),
                              child: Container(
                                height: 12,
                                decoration: BoxDecoration(
                                  color: C.accent2,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned.fill(
                  child: IgnorePointer(
                    child: Opacity(opacity: _w.value, child: ColoredBox(color: C.ink)),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
