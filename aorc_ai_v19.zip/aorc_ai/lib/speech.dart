import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

import 'piper.dart';
import 'state.dart';
import 'strings.dart';
import 'tts_engines.dart';

/// Lets the speech engine show a message from anywhere (set in main.dart).
final GlobalKey<ScaffoldMessengerState> rootMessenger = GlobalKey<ScaffoldMessengerState>();

class _Clip {
  final Uint8List bytes;
  final String mime;
  const _Clip(this.bytes, this.mime);
}

class VoiceResult {
  final bool ok;
  final String detail;
  const VoiceResult(this.ok, this.detail);
}

/// Speech with a guaranteed fallback chain:
///   chosen engine -> then kTtsChain (tts_engines.dart): Piper -> device voice
///   -> ResponsiveVoice -> Google -> Polly.
/// Every failure is recorded in [errors] so the voice test screen can show why.
class Speech {
  static final FlutterTts _tts = FlutterTts();
  static AudioPlayer? _online;
  static final http.Client _hc = http.Client();

  static final Map<String, _Clip> _cache = {};
  static final List<String> _order = [];

  /// Last error per engine: system, piper, responsive, google, polly, hf, openai.
  static final Map<String, String> errors = {};
  static String? lastEngine;
  static final ValueNotifier<String?> engineUsed = ValueNotifier<String?>(null);

  static bool _ready = false;
  static bool _sysSpeaking = false;
  static String? _lang;
  static String? _voiceKey;
  static double? _rate;
  static int _gen = 0;
  static Completer<bool>? _startW;
  static Completer<void>? _doneW;
  static DateTime _sysBadUntil = DateTime.fromMillisecondsSinceEpoch(0);
  static DateTime _lastNotice = DateTime.fromMillisecondsSinceEpoch(0);

  /// The one player used for every clip engine. Created lazily with an audio
  /// context that asks for transient focus (so music ducks, and short sound
  /// effects played by [Sfx] never cut the voice off).
  static AudioPlayer _player() {
    var p = _online;
    if (p == null) {
      p = AudioPlayer();
      _online = p;
      unawaited(p
          .setAudioContext(AudioContext(
            android: const AudioContextAndroid(
              contentType: AndroidContentType.speech,
              usageType: AndroidUsageType.media,
              audioFocus: AndroidAudioFocus.gainTransientMayDuck,
            ),
            iOS: AudioContextIOS(category: AVAudioSessionCategory.playback),
          ))
          .catchError((_) {}));
    }
    return p;
  }

  /// Completes when [p] finishes the current clip, or after [max]. (The old
  /// `stream.first.timeout(onTimeout: () {})` threw a type error on every clip,
  /// which made every online engine fail.)
  static Future<void> _completion(AudioPlayer p, Duration max) {
    final c = Completer<void>();
    final sub = p.onPlayerComplete.listen((_) {
      if (!c.isCompleted) c.complete();
    });
    final timer = Timer(max, () {
      if (!c.isCompleted) c.complete();
    });
    c.future.whenComplete(() {
      sub.cancel();
      timer.cancel();
    });
    return c.future;
  }

  static void _ok(Completer<bool>? c, bool v) {
    if (c != null && !c.isCompleted) c.complete(v);
  }

  static void _fin(Completer<void>? c) {
    if (c != null && !c.isCompleted) c.complete();
  }

  static String _key(String engine) => ttsErrorKey(engine);

  static String _short(Object e) {
    final s = e.toString();
    return s.length > 160 ? s.substring(0, 160) : s;
  }

  static Future<void> init() async {
    if (_ready) return;
    _ready = true;
    try {
      _tts.setStartHandler(() {
        _sysSpeaking = true;
        _ok(_startW, true);
      });
      _tts.setCompletionHandler(() {
        _sysSpeaking = false;
        _fin(_doneW);
      });
      _tts.setCancelHandler(() {
        _sysSpeaking = false;
        _fin(_doneW);
      });
      _tts.setErrorHandler((m) {
        _sysSpeaking = false;
        errors['system'] = _short(m);
        _ok(_startW, false);
        _fin(_doneW);
      });
      await _tts.awaitSpeakCompletion(false);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
    } catch (e) {
      errors['system'] = _short(e);
    }
    try {
      await _tts.setQueueMode(0);
    } catch (_) {}
    final eng = AppState.I.sysEngine;
    if (eng.isNotEmpty) {
      try {
        await _tts.setEngine(eng);
      } catch (_) {}
    }
    unawaited(Piper.refresh());
  }

  /// Forget cached language / voice so the next word applies new settings.
  static void invalidate() {
    _lang = null;
    _voiceKey = null;
    _rate = null;
    _cache.clear();
    _order.clear();
  }

  // ───────────── device voice ─────────────

  /// flutter_tts returns bool on some versions and the raw Android code on
  /// others (0 = language, 1 = language+country, 2 = variant are all usable;
  /// negative = missing data / unsupported).
  static bool _yes(dynamic v) => v == true || (v is int && v >= 0);

  /// Prepares the device engine. Returns false (and records why) if unusable.
  static Future<bool> warm(String lang) async {
    await init();
    try {
      final s = AppState.I;
      if (_lang != lang) {
        try {
          final engines = await _tts.getEngines;
          if (engines is List && engines.isEmpty) {
            errors['system'] = 'no text-to-speech engine installed on this phone';
            _sysBadUntil = DateTime.now().add(const Duration(minutes: 2));
            return false;
          }
        } catch (_) {}
        var use = lang;
        if (!_yes(await _tts.isLanguageAvailable(lang))) {
          final base = lang.split('-').first;
          if (_yes(await _tts.isLanguageAvailable(base))) {
            use = base;
          } else {
            errors['system'] = 'voice data for "$lang" is not installed';
            return false;
          }
        }
        await _tts.setLanguage(use);
        _lang = lang;
        _voiceKey = null;
      }
      if (_rate != s.speechRate) {
        await _tts.setSpeechRate(s.speechRate);
        _rate = s.speechRate;
      }
      final vk = '$lang|${s.voiceGender}|${s.sysVoice}';
      if (_voiceKey != vk) {
        await _applyVoice(lang);
        _voiceKey = vk;
      }
      return true;
    } catch (e) {
      errors['system'] = _short(e);
      return false;
    }
  }

  static String _genderOf(String name) {
    final n = name.toLowerCase();
    if (n.contains('female')) return 'f';
    if (n.contains('male')) return 'm';
    return '';
  }

  /// Installed device voices for [lang], each {name, locale, gender}.
  static Future<List<Map<String, String>>> systemVoices(String lang) async {
    await init();
    final code = lang.split('-').first.toLowerCase();
    final out = <Map<String, String>>[];
    try {
      final vs = await _tts.getVoices;
      if (vs is List) {
        for (final v in vs) {
          if (v is! Map) continue;
          final name = (v['name'] ?? '').toString();
          final loc = (v['locale'] ?? '').toString();
          if (name.isEmpty) continue;
          if (!loc.toLowerCase().replaceAll('_', '-').startsWith(code)) continue;
          out.add({'name': name, 'locale': loc, 'gender': _genderOf(name)});
        }
      }
    } catch (_) {}
    return out;
  }

  static Future<void> _applyVoice(String lang) async {
    final s = AppState.I;
    final list = await systemVoices(lang);
    if (list.isEmpty) return;
    Map<String, String>? pick;
    if (s.sysVoice.isNotEmpty) {
      for (final v in list) {
        if (v['name'] == s.sysVoice) pick = v;
      }
    }
    if (pick == null) {
      for (final v in list) {
        if (v['gender'] == s.voiceGender) {
          pick = v;
          break;
        }
      }
    }
    if (pick == null) return; // keep the engine's default voice
    try {
      await _tts.setVoice({'name': pick['name']!, 'locale': pick['locale']!});
    } catch (_) {}
  }

  /// Text report about the device engine (for the voice test screen).
  static Future<String> systemInfo(String lang) async {
    await init();
    final b = StringBuffer();
    try {
      final e = await _tts.getEngines;
      b.writeln('engines: ${e is List ? (e.isEmpty ? 'none' : e.join(', ')) : e}');
    } catch (x) {
      b.writeln('engines: ${_short(x)}');
    }
    try {
      b.writeln('default: ${await _tts.getDefaultEngine}');
    } catch (_) {}
    try {
      b.writeln('$lang: ${_yes(await _tts.isLanguageAvailable(lang)) ? 'available' : 'NOT installed'}');
    } catch (x) {
      b.writeln('$lang: ${_short(x)}');
    }
    return b.toString().trim();
  }

  static Future<List<String>> systemEngines() async {
    await init();
    try {
      final e = await _tts.getEngines;
      if (e is List) return e.map((x) => x.toString()).toList();
    } catch (_) {}
    return [];
  }

  static Future<void> useEngine(String pkg) async {
    final s = AppState.I;
    s.sysEngine = pkg;
    await s.saveSettings();
    try {
      await _tts.setEngine(pkg);
    } catch (e) {
      errors['system'] = _short(e);
    }
    _sysBadUntil = DateTime.fromMillisecondsSinceEpoch(0);
    invalidate();
  }

  // ───────────── control ─────────────

  static Future<void> stop() async {
    _gen++;
    _fin(_doneW);
    try {
      if (_sysSpeaking) await _tts.stop();
      await _online?.stop();
    } catch (_) {}
  }

  static List<String> _chain(String e) {
    final first = (e == 'auto' || !isKnownEngine(e)) ? null : e;
    return [if (first != null) first, ...kTtsChain.where((x) => x != first)];
  }

  static String _clean(String text) {
    var txt = text.replaceAll(RegExp(r'[*_#`$]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (txt.length > 3500) txt = txt.substring(0, 3500);
    return txt;
  }

  /// Speaks [text]. With [wait] the future completes when the speech ends.
  static Future<void> speak(String text, String lang, {bool wait = false}) async {
    final txt = _clean(text);
    if (txt.isEmpty) return;
    final gen = ++_gen;
    if (_online != null) unawaited(_online!.stop().catchError((_) {}));
    if (_sysSpeaking) {
      try {
        await _tts.stop().timeout(const Duration(seconds: 1));
      } catch (_) {}
      _sysSpeaking = false;
    }
    for (final e in _chain(AppState.I.ttsEngine)) {
      if (gen != _gen) return;
      if (e == 'system' && DateTime.now().isBefore(_sysBadUntil)) continue;
      final ok = e == 'system'
          ? await _speakSystem(txt, lang, gen, wait)
          : await _speakClips(e, txt, lang, gen, wait);
      if (gen != _gen) return;
      if (ok) {
        lastEngine = e;
        engineUsed.value = e;
        return;
      }
    }
    _notifyFail();
  }

  static void _notifyFail() {
    final now = DateTime.now();
    if (now.difference(_lastNotice).inSeconds < 20) return;
    _lastNotice = now;
    final m = rootMessenger.currentState;
    if (m == null) return;
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(
      duration: const Duration(seconds: 6),
      content: Text(t('voice_all_failed')),
    ));
  }

  static Future<bool> _speakSystem(String txt, String lang, int gen, bool wait) async {
    if (!await warm(lang)) return false;
    if (gen != _gen) return true;
    final started = Completer<bool>();
    final done = Completer<void>();
    _startW = started;
    _doneW = done;
    dynamic r;
    try {
      r = await _tts.speak(txt);
    } catch (e) {
      errors['system'] = _short(e);
      return false;
    }
    if (r == 0) {
      errors['system'] = 'speak() returned 0 (engine not ready)';
      _sysBadUntil = DateTime.now().add(const Duration(seconds: 90));
      return false;
    }
    final ok = await started.future.timeout(const Duration(seconds: 6), onTimeout: () {
      errors['system'] ??= 'the engine never started speaking (6 s)';
      return false;
    });
    if (!ok) {
      try {
        await _tts.stop();
      } catch (_) {}
      _sysBadUntil = DateTime.now().add(const Duration(seconds: 90));
      return false;
    }
    errors.remove('system');
    if (wait) await done.future.timeout(const Duration(seconds: 120), onTimeout: () {});
    return true;
  }

  static Future<bool> _speakClips(String engine, String text, String lang, int gen, bool wait) async {
    try {
      final code = lang.split('-').first;
      final chunks = _chunks(text);
      if (chunks.isEmpty) return false;
      var next = _get(engine, code, chunks.first);
      for (int i = 0; i < chunks.length; i++) {
        final clip = await next;
        if (gen != _gen) return true;
        if (clip == null) return i > 0;
        if (i + 1 < chunks.length) next = _get(engine, code, chunks[i + 1]);
        final player = _player();
        final done = _completion(player, const Duration(seconds: 60));
        await player.play(BytesSource(clip.bytes, mimeType: clip.mime));
        if (i + 1 < chunks.length || wait) await done;
        if (gen != _gen) return true;
      }
      return true;
    } catch (e) {
      errors[_key(engine)] = _short(e);
      return false;
    }
  }

  /// Downloads / synthesises the audio ahead of time (clip engines only).
  static void prefetch(String text, String lang) {
    final s = AppState.I;
    final code = lang.split('-').first;
    var e = s.ttsEngine;
    if (e == 'system') return;
    if (e == 'auto') {
      if (Piper.pick(code, s.voiceGender) == null) return;
      e = 'piper';
    }
    final c = _chunks(_clean(text));
    if (c.isNotEmpty) unawaited(_get(e, code, c.first));
  }

  // ───────────── diagnostics ─────────────

  static String samplePhrase(String lang) {
    switch (lang.split('-').first) {
      case 'ar':
        return 'مرحباً، هذا اختبار للصوت.';
      case 'fr':
        return 'Bonjour, ceci est un test de la voix.';
      case 'de':
        return 'Hallo, das ist ein Test der Stimme.';
      case 'es':
        return 'Hola, esto es una prueba de voz.';
      case 'it':
        return 'Ciao, questa è una prova della voce.';
      case 'ru':
        return 'Привет, это проверка голоса.';
      case 'tr':
        return 'Merhaba, bu bir ses testidir.';
      case 'pt':
        return 'Olá, este é um teste de voz.';
      case 'zh':
        return '你好，这是语音测试。';
      default:
        return 'Hello, this is a voice test.';
    }
  }

  /// Plays one engine alone (no fallback) and reports what happened.
  static Future<VoiceResult> test(String engine, String lang) async {
    await init();
    final gen = ++_gen;
    try {
      await _online?.stop();
      if (_sysSpeaking) await _tts.stop();
    } catch (_) {}
    errors.remove(_key(engine));
    final sw = Stopwatch()..start();
    final phrase = samplePhrase(lang);
    bool ok;
    if (engine == 'system') {
      _sysBadUntil = DateTime.fromMillisecondsSinceEpoch(0);
      ok = await _speakSystem(phrase, lang, gen, false);
    } else {
      ok = await _speakClips(engine, phrase, lang, gen, false);
    }
    return VoiceResult(ok, ok ? '${sw.elapsedMilliseconds} ms' : (errors[_key(engine)] ?? 'unknown error'));
  }


  /// Plays one specific downloaded Piper voice (used by the voice screen).
  static Future<VoiceResult> testVoice(PiperVoice v) async {
    await init();
    final gen = ++_gen;
    try {
      await _online?.stop();
      if (_sysSpeaking) await _tts.stop();
    } catch (_) {}
    final sw = Stopwatch()..start();
    try {
      final lang = v.lang;
      final sample = samplePhrase(lang);
      final speed = (AppState.I.speechRate / 0.45).clamp(0.6, 1.6).toDouble();
      final wav = await Piper.synth(v, sample, speed);
      if (gen != _gen) return const VoiceResult(true, 'cancelled');
      await _player().play(BytesSource(wav, mimeType: 'audio/wav'));
      return VoiceResult(true, '${sw.elapsedMilliseconds} ms');
    } catch (e) {
      errors['piper'] = _short(e);
      return VoiceResult(false, _short(e));
    }
  }

  // ───────────── text chunks and clip engines ─────────────

  static List<String> _chunks(String text) {
    const max = 180;
    final out = <String>[];
    var cur = '';
    for (final part in text.split(RegExp(r'(?<=[.!?؟,،;:])\s+'))) {
      if (part.length > max) {
        if (cur.isNotEmpty) {
          out.add(cur);
          cur = '';
        }
        var buf = '';
        for (final w in part.split(' ')) {
          if (buf.isNotEmpty && buf.length + w.length + 1 > max) {
            out.add(buf);
            buf = w;
          } else {
            buf = buf.isEmpty ? w : '$buf $w';
          }
        }
        if (buf.isNotEmpty) out.add(buf);
        continue;
      }
      if (cur.isNotEmpty && cur.length + part.length + 1 > max) {
        out.add(cur);
        cur = part;
      } else {
        cur = cur.isEmpty ? part : '$cur $part';
      }
    }
    if (cur.isNotEmpty) out.add(cur);
    return out;
  }

  static Future<_Clip?> _get(String engine, String code, String chunk) async {
    final s = AppState.I;
    final k = '$engine|$code|${s.voiceGender}|${engine == 'piper' ? s.speechRate.toStringAsFixed(2) : ''}|$chunk';
    final hit = _cache[k];
    if (hit != null) return hit;
    _Clip? clip;
    try {
      switch (engine) {
        case 'piper':
          clip = await _piper(code, chunk);
          break;
        case 'responsive':
          clip = await _responsive(code, chunk);
          break;
        case 'polly':
          clip = await _polly(code, chunk);
          break;
        case 'gmirror':
          clip = await _gmirror(code, chunk);
          break;
        case 'baidu':
          clip = await _baidu(code, chunk);
          break;
        case 'youdao':
          clip = await _youdao(code, chunk);
          break;
        case 'dictapi':
          clip = await _dictapi(code, chunk);
          break;
        case 'hf':
          clip = await _hfTts(code, chunk);
          break;
        case 'openai':
          clip = await _openaiTts(chunk);
          break;
        case 'slow':
          clip = await _google(code, chunk, slow: true);
          break;
        default:
          clip = await _google(code, chunk);
      }
      if (clip != null) errors.remove(_key(engine));
    } catch (e) {
      errors[_key(engine)] = _short(e);
    }
    if (clip == null) return null;
    _cache[k] = clip;
    _order.add(k);
    if (_order.length > 80) _cache.remove(_order.removeAt(0));
    return clip;
  }

  static bool _okAudio(http.Response r, String key) {
    final ct = (r.headers['content-type'] ?? '').toLowerCase();
    final good = r.statusCode == 200 &&
        r.bodyBytes.length >= 200 &&
        !ct.contains('json') &&
        !ct.contains('html') &&
        !ct.contains('text/');
    if (!good) errors[key] = 'HTTP ${r.statusCode}${ct.isEmpty ? '' : ' ($ct)'}';
    return good;
  }

  static String _mime(http.Response r, String fallback) {
    final ct = (r.headers['content-type'] ?? '').split(';').first.trim();
    return ct.startsWith('audio/') ? ct : fallback;
  }

  static Future<_Clip?> _piper(String code, String chunk) async {
    final s = AppState.I;
    final v = Piper.pick(code, s.voiceGender);
    if (v == null) {
      errors['piper'] = 'no offline voice downloaded for "$code"';
      return null;
    }
    final speed = (s.speechRate / 0.45).clamp(0.6, 1.6).toDouble();
    final wav = await Piper.synth(v, chunk, speed);
    return _Clip(wav, 'audio/wav');
  }

  static Future<_Clip?> _google(String code, String chunk, {bool slow = false}) async {
    final q = Uri.encodeComponent(chunk);
    final urls = [
      'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$code&q=$q${slow ? '&ttsspeed=0.24' : ''}',
      'https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl=$code&q=$q${slow ? '&ttsspeed=0.24' : ''}',
    ];
    for (final u in urls) {
      try {
        final r = await _hc
            .get(Uri.parse(u), headers: {'User-Agent': 'Mozilla/5.0'})
            .timeout(const Duration(seconds: 8));
        if (r.statusCode == 200 && r.bodyBytes.length >= 200) {
          return _Clip(r.bodyBytes, 'audio/mpeg');
        }
        errors['google'] = 'HTTP ${r.statusCode}';
      } catch (e) {
        errors['google'] = _short(e);
      }
    }
    return null;
  }

  // ResponsiveVoice: same web key as the JS script, called over HTTP so it
  // works inside the APK (there is no web page to load the script into).
  static const Map<String, String> _rvLang = {
    'en': 'en-US',
    'ar': 'ar-SA',
    'fr': 'fr-FR',
    'de': 'de-DE',
    'es': 'es-ES',
    'it': 'it-IT',
    'pt': 'pt-BR',
    'ru': 'ru-RU',
    'tr': 'tr-TR',
    'zh': 'zh-CN',
    'ja': 'ja-JP',
    'ko': 'ko-KR',
    'hi': 'hi-IN',
    'fa': 'fa-IR',
    'ur': 'ur-PK',
  };

  static Future<_Clip?> _responsive(String code, String chunk) async {
    final s = AppState.I;
    final lang = _rvLang[code];
    if (lang == null) {
      errors['responsive'] = 'language "$code" is not supported';
      return null;
    }
    final rate = (s.speechRate / 0.45 * 0.5).clamp(0.2, 0.9).toDouble();
    final uri = Uri.https('texttospeech.responsivevoice.org', '/v1/text:synthesize', {
      'text': chunk,
      'lang': lang,
      'engine': 'g1',
      'name': '',
      'pitch': '0.5',
      'rate': rate.toStringAsFixed(2),
      'volume': '1',
      'key': kResponsiveVoiceKey,
      'gender': s.voiceGender == 'm' ? 'male' : 'female',
    });
    final r = await _hc.get(uri, headers: {
      'User-Agent': 'Mozilla/5.0',
      'Referer': 'https://responsivevoice.org/',
    }).timeout(const Duration(seconds: 10));
    return _okAudio(r, 'responsive') ? _Clip(r.bodyBytes, _mime(r, 'audio/mpeg')) : null;
  }


  // ───────────── extra keyless online engines (different hosts, so when one
  // is blocked on a network another usually still works) ─────────────

  /// Google Translate voice through regional hostnames. Some networks block
  /// translate.google.com but let a regional domain through.
  static const List<String> _gHosts = [
    'translate.google.com.hk',
    'translate.google.cn',
    'translate.google.com.eg',
    'translate.google.co.uk',
    'translate.google.de',
  ];

  static Future<_Clip?> _gmirror(String code, String chunk) async {
    String? last;
    for (final h in _gHosts) {
      try {
        final uri = Uri.https(h, '/translate_tts', {
          'ie': 'UTF-8',
          'client': 'tw-ob',
          'tl': code,
          'q': chunk,
        });
        final r = await _hc.get(uri, headers: {'User-Agent': 'Mozilla/5.0'}).timeout(const Duration(seconds: 7));
        if (r.statusCode == 200 && r.bodyBytes.length >= 200) {
          return _Clip(r.bodyBytes, 'audio/mpeg');
        }
        last = '$h: HTTP ${r.statusCode}';
      } catch (e) {
        last = '$h: ${_short(e)}';
      }
    }
    errors['gmirror'] = last ?? 'no host answered';
    return null;
  }

  static const Map<String, String> _baiduLang = {
    'en': 'en',
    'ar': 'ara',
    'fr': 'fra',
    'de': 'de',
    'es': 'spa',
    'it': 'it',
    'ru': 'ru',
    'pt': 'pt',
    'zh': 'zh',
    'ja': 'jp',
    'ko': 'kor',
  };

  static Future<_Clip?> _baidu(String code, String chunk) async {
    final lan = _baiduLang[code];
    if (lan == null) {
      errors['baidu'] = 'language "$code" is not supported';
      return null;
    }
    final uri = Uri.https('fanyi.baidu.com', '/gettts', {
      'lan': lan,
      'text': chunk,
      'spd': '3',
      'source': 'web',
    });
    final r = await _hc.get(uri, headers: {
      'User-Agent': 'Mozilla/5.0',
      'Referer': 'https://fanyi.baidu.com/',
    }).timeout(const Duration(seconds: 10));
    return _okAudio(r, 'baidu') ? _Clip(r.bodyBytes, _mime(r, 'audio/mpeg')) : null;
  }

  static const Map<String, String> _youdaoLe = {
    'fr': 'fr',
    'de': 'de',
    'ko': 'ko',
    'ja': 'jap',
  };

  static Future<_Clip?> _youdao(String code, String chunk) async {
    if (code != 'en' && !_youdaoLe.containsKey(code)) {
      errors['youdao'] = 'language "$code" is not supported';
      return null;
    }
    final q = <String, String>{'audio': chunk};
    if (code == 'en') {
      q['type'] = '2';
    } else {
      q['le'] = _youdaoLe[code]!;
    }
    final uri = Uri.https('dict.youdao.com', '/dictvoice', q);
    final r = await _hc.get(uri, headers: {'User-Agent': 'Mozilla/5.0'}).timeout(const Duration(seconds: 10));
    return _okAudio(r, 'youdao') ? _Clip(r.bodyBytes, _mime(r, 'audio/mpeg')) : null;
  }

  /// Real human recordings of single English words (dictionaryapi.dev).
  static Future<_Clip?> _dictapi(String code, String chunk) async {
    final w = chunk.trim().toLowerCase();
    if (code != 'en' || !RegExp(r"^[a-z][a-z'\-]{0,30}$").hasMatch(w)) {
      errors['dictapi'] = 'only single English words are supported';
      return null;
    }
    final r = await _hc
        .get(Uri.https('api.dictionaryapi.dev', '/api/v2/entries/en/$w'), headers: {'User-Agent': 'Mozilla/5.0'})
        .timeout(const Duration(seconds: 8));
    if (r.statusCode != 200) {
      errors['dictapi'] = 'HTTP ${r.statusCode}';
      return null;
    }
    String? url;
    final data = jsonDecode(utf8.decode(r.bodyBytes));
    if (data is List) {
      for (final e in data) {
        if (e is! Map) continue;
        final ph = e['phonetics'];
        if (ph is! List) continue;
        for (final p in ph) {
          final a = (p is Map ? p['audio'] : null)?.toString() ?? '';
          if (a.isNotEmpty) {
            url = a.startsWith('//') ? 'https:$a' : a;
            break;
          }
        }
        if (url != null) break;
      }
    }
    if (url == null) {
      errors['dictapi'] = 'no recording for "$w"';
      return null;
    }
    final a = await _hc.get(Uri.parse(url), headers: {'User-Agent': 'Mozilla/5.0'}).timeout(const Duration(seconds: 10));
    return _okAudio(a, 'dictapi') ? _Clip(a.bodyBytes, _mime(a, 'audio/mpeg')) : null;
  }

  static const Map<String, Map<String, String>> _pollyVoices = {
    'en': {'f': 'Amy', 'm': 'Brian'},
    'ar': {'f': 'Zeina', 'm': 'Zeina'},
    'fr': {'f': 'Celine', 'm': 'Mathieu'},
    'de': {'f': 'Marlene', 'm': 'Hans'},
    'es': {'f': 'Conchita', 'm': 'Enrique'},
    'it': {'f': 'Carla', 'm': 'Giorgio'},
    'pt': {'f': 'Vitoria', 'm': 'Ricardo'},
    'ru': {'f': 'Tatyana', 'm': 'Maxim'},
    'ja': {'f': 'Mizuki', 'm': 'Takumi'},
    'ko': {'f': 'Seoyeon', 'm': 'Seoyeon'},
    'zh': {'f': 'Zhiyu', 'm': 'Zhiyu'},
    'tr': {'f': 'Filiz', 'm': 'Filiz'},
  };

  static Future<_Clip?> _polly(String code, String chunk) async {
    final voice = _pollyVoices[code]?[AppState.I.voiceGender];
    if (voice == null) {
      errors['polly'] = 'language "$code" is not supported';
      return null;
    }
    final uri = Uri.parse(
        'https://api.streamelements.com/kappa/v2/speech?voice=$voice&text=${Uri.encodeComponent(chunk)}');
    final r = await _hc.get(uri, headers: {'User-Agent': 'Mozilla/5.0'}).timeout(const Duration(seconds: 10));
    return _okAudio(r, 'polly') ? _Clip(r.bodyBytes, _mime(r, 'audio/mpeg')) : null;
  }

  static const Map<String, String> _mms = {
    'en': 'eng',
    'ar': 'ara',
    'fr': 'fra',
    'de': 'deu',
    'es': 'spa',
    'tr': 'tur',
    'ru': 'rus',
    'pt': 'por',
    'hi': 'hin',
    'it': 'ita',
    'fa': 'fas',
    'ur': 'urd',
  };

  static Future<_Clip?> _hfTts(String code, String chunk) async {
    final s = AppState.I;
    final iso = _mms[code];
    if (iso == null || s.aiProvider != 'huggingface' || s.hfToken.trim().isEmpty) {
      errors['hf'] = 'needs the Hugging Face key and provider';
      return null;
    }
    final uri = Uri.parse('https://router.huggingface.co/hf-inference/models/facebook/mms-tts-$iso');
    final r = await _hc
        .post(uri,
            headers: {
              'Authorization': 'Bearer ${s.hfToken.trim()}',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({'inputs': chunk}))
        .timeout(const Duration(seconds: 30));
    return _okAudio(r, 'hf') ? _Clip(r.bodyBytes, _mime(r, 'audio/flac')) : null;
  }

  static Future<_Clip?> _openaiTts(String chunk) async {
    final s = AppState.I;
    final base = s.aiBaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty || s.hfToken.trim().isEmpty || base.contains('huggingface.co')) {
      errors['openai'] = 'needs an OpenAI-compatible provider and key';
      return null;
    }
    final r = await _hc
        .post(Uri.parse('$base/audio/speech'),
            headers: {
              'Authorization': 'Bearer ${s.hfToken.trim()}',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'model': 'tts-1',
              'input': chunk,
              'voice': s.voiceGender == 'm' ? 'onyx' : 'nova',
              'response_format': 'mp3',
            }))
        .timeout(const Duration(seconds: 30));
    return _okAudio(r, 'openai') ? _Clip(r.bodyBytes, _mime(r, 'audio/mpeg')) : null;
  }
}
