import 'dart:math';

import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

// ───────────────────────── Background catalogue ─────────────────────────

class BgDef {
  final String id;
  final String ar;
  final String en;
  final int price;
  final int needStreak; // best streak that unlocks it for free (0 = none)
  final int needReviews; // total reviews that unlock it for free (0 = none)
  const BgDef(this.id, this.ar, this.en, this.price, {this.needStreak = 0, this.needReviews = 0});
  String get name => AppState.I.uiLang == 'ar' ? ar : en;

  bool unlocked(AppState s) =>
      (needStreak > 0 && s.bestStreak >= needStreak) ||
      (needReviews > 0 && s.totalReviews >= needReviews);

  String? hint() {
    if (needStreak > 0) return t('bg_unlock_streak').replaceAll('{n}', '$needStreak');
    if (needReviews > 0) return t('bg_unlock_reviews').replaceAll('{n}', '$needReviews');
    return null;
  }
}

const List<BgDef> kBgs = [
  BgDef('none', 'بدون خلفية', 'No background', 0),
  BgDef('forest', 'غابة', 'Forest', 0),
  BgDef('sakura', 'ساكورا', 'Sakura', 40, needStreak: 7),
  BgDef('sea', 'تحت الماء', 'Underwater', 60),
  BgDef('desert', 'صحراء', 'Desert', 60, needReviews: 100),
  BgDef('snow', 'جبال ثلجية', 'Snowy peaks', 70, needStreak: 14),
  BgDef('city', 'مدينة ليلية', 'Night city', 80),
  BgDef('neon', 'نيون', 'Synthwave', 90),
  BgDef('space', 'فضاء', 'Space', 100, needReviews: 500),
];

// ───────────────────────── Widgets ─────────────────────────

/// Paints [child] over an animated gradient scene. With id 'none' it is a plain
/// page-colored box. A translucent veil keeps text readable.
class BgBackdrop extends StatelessWidget {
  final String id;
  final double extra; // added on top of the user's veil setting
  final Widget child;
  const BgBackdrop({super.key, required this.id, required this.child, this.extra = 0});

  @override
  Widget build(BuildContext context) {
    if (id == 'none') {
      return CustomPaint(
        painter: _DotGridPainter(C.cream, C.ink.withOpacity(0.10)),
        child: child,
      );
    }
    final veil = (AppState.I.bgVeil + extra).clamp(0.0, 0.92);
    return Stack(
      children: [
        Positioned.fill(child: BgScene(id: id)),
        Positioned.fill(
          child: IgnorePointer(
            child: ColoredBox(color: C.cream.withAlpha((veil * 255).round().clamp(0, 255))),
          ),
        ),
        Positioned.fill(child: child),
      ],
    );
  }
}

/// The animated scene itself (no veil): soft gradient with slowly drifting color blobs.
class BgScene extends StatefulWidget {
  final String id;
  const BgScene({super.key, required this.id});

  @override
  State<BgScene> createState() => _BgSceneState();
}

class _BgSceneState extends State<BgScene> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 24));

  @override
  void initState() {
    super.initState();
    if (AppState.I.bgMotion) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final motion = AppState.I.bgMotion;
    if (motion && !_c.isAnimating) {
      _c.repeat();
    } else if (!motion && _c.isAnimating) {
      _c.stop();
    }
    return RepaintBoundary(
      child: CustomPaint(
        size: Size.infinite,
        painter: _ScenePainter(widget.id, _c, AppState.I.bgWeather),
      ),
    );
  }
}

const Map<String, List<int>> _kBgColors = {
  'forest': [0xFF14573A, 0xFF4CC38A, 0xFFB8F0C8],
  'sakura': [0xFFFF8FB8, 0xFFFFC2DA, 0xFFFFF0F6],
  'sea': [0xFF063B73, 0xFF1C8FD1, 0xFF54E0D6],
  'desert': [0xFFFF9F43, 0xFFFFCF70, 0xFFFFF0C2],
  'snow': [0xFF7FB9F0, 0xFFC5E4FF, 0xFFFFFFFF],
  'city': [0xFF140A2E, 0xFF3F1F7A, 0xFFFF5FA2],
  'neon': [0xFF1A0638, 0xFF7A1FD1, 0xFFFF3E9D],
  'space': [0xFF03050F, 0xFF16124A, 0xFF5B3DD6],
};

class _ScenePainter extends CustomPainter {
  final String id;
  final Animation<double> t;
  final String weather; // none | rain | snow | fog
  _ScenePainter(this.id, this.t, this.weather) : super(repaint: t);

  @override
  void paint(Canvas canvas, Size size) {
    final cols = (_kBgColors[id] ?? _kBgColors['forest']!).map((v) => Color(v)).toList();
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cols[0], cols[1]],
        ).createShader(rect),
    );
    final a = t.value * 2 * pi;
    final m = size.shortestSide;
    final blobs = <(double, double, double, int, double)>[
      (0.2, 0.18, 0.55, 2, 0.0),
      (0.85, 0.35, 0.45, 1, 1.7),
      (0.3, 0.75, 0.6, 2, 3.1),
      (0.9, 0.9, 0.4, 1, 4.6),
    ];
    for (final bl in blobs) {
      final cx = size.width * (bl.$1 + 0.05 * sin(a + bl.$5));
      final cy = size.height * (bl.$2 + 0.04 * cos(a + bl.$5));
      final r = m * bl.$3;
      final col = cols[bl.$4];
      canvas.drawCircle(
        Offset(cx, cy),
        r,
        Paint()
          ..shader = RadialGradient(
            colors: [col.withOpacity(0.55), col.withOpacity(0.0)],
          ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: r)),
      );
    }
    _weather(canvas, size);
  }

  void _weather(Canvas canvas, Size size) {
    final v = t.value;
    if (weather == 'rain') {
      final p = Paint()
        ..color = Colors.white.withOpacity(0.55)
        ..strokeWidth = 1.8
        ..strokeCap = StrokeCap.round;
      for (int i = 0; i < 70; i++) {
        final x = ((i * 0.6180339) % 1.0) * size.width;
        final y = (((i * 0.3819660) % 1.0) + v * 30) % 1.0 * (size.height + 40) - 20;
        canvas.drawLine(Offset(x, y), Offset(x - 5, y + 16), p);
      }
    } else if (weather == 'snow') {
      final p = Paint()..color = Colors.white.withOpacity(0.8);
      for (int i = 0; i < 55; i++) {
        final x = (((i * 0.6180339) % 1.0) + 0.03 * sin(v * 2 * pi * 3 + i)) * size.width;
        final y = (((i * 0.3819660) % 1.0) + v * 6) % 1.0 * size.height;
        canvas.drawCircle(Offset(x, y), 1.6 + (i % 3), p);
      }
    } else if (weather == 'fog') {
      for (int i = 0; i < 3; i++) {
        final y = size.height * (0.25 + 0.25 * i) + 14 * sin(v * 2 * pi + i * 2);
        final r = Rect.fromLTWH(-20, y, size.width + 40, size.height * 0.22);
        canvas.drawRect(
          r,
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white.withOpacity(0.0), Colors.white.withOpacity(0.22), Colors.white.withOpacity(0.0)],
            ).createShader(r),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ScenePainter old) => old.id != id || old.weather != weather;
}

/// Brutalist dot grid used when no background is picked.
class _DotGridPainter extends CustomPainter {
  final Color base;
  final Color dot;
  _DotGridPainter(this.base, this.dot);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = base);
    final p = Paint()..color = dot;
    const gap = 24.0;
    for (double y = gap / 2; y < size.height; y += gap) {
      for (double x = gap / 2; x < size.width; x += gap) {
        canvas.drawCircle(Offset(x, y), 1.4, p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DotGridPainter old) => old.base != base || old.dot != dot;
}

// ───────────────────────── Shop / chooser screen ─────────────────────────

class BgShopScreen extends StatelessWidget {
  const BgShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('bgs'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(14),
          children: [
            infoBox(t('bg_help')),
            const SizedBox(height: 12),
            for (final d in kBgs) ...[
              _card(context, d),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, BgDef d) {
    final s = AppState.I;
    final owned = s.ownedBg.contains(d.id) || d.unlocked(s);
    return PixelBox(
      padding: const EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          GestureDetector(
            onTap: d.id == 'none' ? null : () => _fullPreview(context, d),
            child: SizedBox(
              height: 130,
              child: ClipRect(
                child: d.id == 'none'
                    ? ColoredBox(color: C.creamDeep, child: Center(child: tx(d.name, bold: true)))
                    : Stack(
                        fit: StackFit.expand,
                        children: [
                          BgScene(id: d.id),
                          Positioned(
                            left: 6,
                            bottom: 6,
                            child: Container(
                              color: const Color(0x99000000),
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              child: Text(t('bg_preview'),
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: tx(d.name, bold: true, size: 15)),
              if (!owned)
                PixelButton(
                  label: '${d.price}',
                  icon: 'coin',
                  small: true,
                  filled: true,
                  onTap: () {
                    if (s.coins >= d.price) {
                      s.coins -= d.price;
                      s.ownedBg.add(d.id);
                      s.bgHome = d.id;
                      s.saveExtra();
                      Sfx.play('win');
                    } else {
                      toast(context, t('not_enough_coins'));
                    }
                  },
                ),
            ],
          ),
          if (!owned && d.hint() != null) ...[
            const SizedBox(height: 6),
            tx(d.hint()!, size: 12, color: C.dark),
          ],
          if (owned) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: s.bgHome == d.id ? t('bg_in_home') : t('bg_home'),
                    small: true,
                    expand: true,
                    filled: s.bgHome != d.id,
                    onTap: s.bgHome == d.id
                        ? null
                        : () {
                            if (!s.ownedBg.contains(d.id)) s.ownedBg.add(d.id);
                            s.bgHome = d.id;
                            s.saveExtra();
                          },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: PixelButton(
                    label: s.bgGames == d.id ? t('bg_in_games') : t('bg_games'),
                    small: true,
                    expand: true,
                    filled: s.bgGames != d.id,
                    onTap: s.bgGames == d.id
                        ? null
                        : () {
                            if (!s.ownedBg.contains(d.id)) s.ownedBg.add(d.id);
                            s.bgGames = d.id;
                            s.saveExtra();
                          },
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  void _fullPreview(BuildContext context, BgDef d) {
    Sfx.play('tap');
    showDialog<void>(
      context: context,
      barrierColor: Colors.black,
      builder: (_) => GestureDetector(
        onTap: () => Navigator.of(context).maybePop(),
        child: Material(
          color: Colors.black,
          child: Stack(
            fit: StackFit.expand,
            children: [
              BgScene(id: d.id),
              Positioned(
                top: 40,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    color: const Color(0x99000000),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text(d.name,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
