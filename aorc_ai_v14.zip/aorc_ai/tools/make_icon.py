"""Generate assets/icon.png (pixel mascot on cream) with pure Python."""
import struct
import zlib

ROBOT = [
    ".....11.....",
    ".....11.....",
    ".1111111111.",
    ".1444444441.",
    ".1414444141.",
    ".1414444141.",
    ".1444444441.",
    ".1441111441.",
    ".1444444441.",
    ".1111111111.",
    "..1......1..",
    ".111....111.",
]
PAL = {
    "1": (27, 27, 27),
    "4": (255, 255, 255),
}
BG = (246, 237, 214)
SIZE = 512
CELL = 34
W = len(ROBOT[0]) * CELL
H = len(ROBOT) * CELL
OX = (SIZE - W) // 2
OY = (SIZE - H) // 2

rows = []
for y in range(SIZE):
    row = bytearray([0])
    for x in range(SIZE):
        c = BG
        gx, gy = x - OX, y - OY
        if 0 <= gx < W and 0 <= gy < H:
            ch = ROBOT[gy // CELL][gx // CELL]
            if ch in PAL:
                c = PAL[ch]
        row += bytes(c)
    rows.append(bytes(row))

raw = b"".join(rows)


def chunk(tag, data):
    body = tag + data
    return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)


png = b"\x89PNG\r\n\x1a\n"
png += chunk(b"IHDR", struct.pack(">IIBBBBB", SIZE, SIZE, 8, 2, 0, 0, 0))
png += chunk(b"IDAT", zlib.compress(raw, 9))
png += chunk(b"IEND", b"")

with open("assets/icon.png", "wb") as f:
    f.write(png)
print("icon written")
