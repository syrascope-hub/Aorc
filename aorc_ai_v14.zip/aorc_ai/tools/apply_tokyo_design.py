#!/usr/bin/env python3
"""Applies the "Tokyo Night Shop" design (dark palette + animated pixel-art
background inspired by a lofi Japanese shop) to the aorc_ai Flutter project.
Idempotent: safe to run more than once."""
import os
import sys
from pathlib import Path

project = Path(os.environ.get("PROJECT_DIR", "."))
lib = project / "lib"
MARK = "TOKYO_NIGHT_DESIGN"


def read(name):
    return (lib / name).read_text(encoding="utf-8")


def write(name, s):
    (lib / name).write_text(s, encoding="utf-8")


def replace_once(src, old, new, label):
    if old not in src:
        raise SystemExit("Tokyo design patch: anchor not found for " + label)
    return src.replace(old, new, 1)


# ───────────────────────── theme.dart ─────────────────────────
s = read("theme.dart")
if "'tokyo'" not in s:
    s = replace_once(
        s,
        "const List<Pal> kPalettes = [\n",
        "const List<Pal> kPalettes = [\n"
        "  Pal('tokyo', 'طوكيو ليلاً', 'Tokyo Night', Color(0xFFFFE9B8), Color(0xFF0E1630), Color(0xFF172447),\n"
        "      Color(0xFF1B2A52), Color(0xFF8C9BC4), Color(0xFF2A3A6B), Color(0xFFE7C98A)),\n",
        "palette list",
    )
    s = replace_once(
        s,
        "      brightness: Brightness.light,\n      surface: C.cream,",
        "      brightness: C.cream.computeLuminance() < 0.3 ? Brightness.dark : Brightness.light,\n      surface: C.cream,",
        "color scheme brightness",
    )
    write("theme.dart", s)
    print("theme.dart patched")

# ───────────────────────── state.dart ─────────────────────────
s = read("state.dart")
if MARK not in s:
    s = replace_once(s, "String themeId = 'classic';", "String themeId = 'tokyo';", "themeId default")
    s = replace_once(
        s,
        "themeId = _p.getString('themeId') ?? 'classic';",
        "themeId = _p.getString('themeId') ?? 'tokyo';",
        "themeId load",
    )
    s = replace_once(
        s,
        "List<String> ownedBg = ['none', 'forest'];\n  String bgHome = 'forest';\n  String bgGames = 'forest';",
        "List<String> ownedBg = ['none', 'forest', 'izakaya'];\n  String bgHome = 'izakaya';\n  String bgGames = 'izakaya';",
        "bg defaults",
    )
    s = replace_once(
        s,
        "ownedBg = ob.isEmpty ? ['none', 'forest'] : ob;\n    if (!ownedBg.contains('none')) ownedBg.add('none');\n"
        "    bgHome = (j['bgHome'] ?? 'forest').toString();\n    bgGames = (j['bgGames'] ?? 'forest').toString();",
        "ownedBg = ob.isEmpty ? ['none', 'forest', 'izakaya'] : ob;\n    if (!ownedBg.contains('none')) ownedBg.add('none');\n"
        "    if (!ownedBg.contains('izakaya')) ownedBg.add('izakaya');\n"
        "    bgHome = (j['bgHome'] ?? 'izakaya').toString();\n    bgGames = (j['bgGames'] ?? 'izakaya').toString();",
        "bg extra load",
    )
    # one-time migration: existing installs switch to the new look once
    s = replace_once(
        s,
        "    } catch (_) {}\n    _rollQuests();\n  }\n\n  // ── extra (gamification) persistence ──",
        "    } catch (_) {}\n"
        "    // " + MARK + ": one-time switch of existing installs to the new look\n"
        "    if (!(_p.getBool('tokyoDesign1') ?? false)) {\n"
        "      themeId = 'tokyo';\n"
        "      C.p = palById(themeId);\n"
        "      bgHome = 'izakaya';\n"
        "      bgGames = 'izakaya';\n"
        "      if (!ownedBg.contains('izakaya')) ownedBg.add('izakaya');\n"
        "      await _p.setString('themeId', themeId);\n"
        "      await _p.setString('extra', jsonEncode(extraJson()));\n"
        "      await _p.setBool('tokyoDesign1', true);\n"
        "    }\n"
        "    _rollQuests();\n  }\n\n  // ── extra (gamification) persistence ──",
        "migration",
    )
    write("state.dart", s)
    print("state.dart patched")

# ───────────────────────── backgrounds.dart ─────────────────────────
IZAKAYA = r'''
// ───────────────────────── Tokyo night shop (izakaya) ─────────────────────────

void _izakaya(_G g, double t) {
  final rows = g.rows;
  final cols = g.cols;
  final gy = (rows * 0.74).round(); // street level
  final bt = gy - 40; // top of the sign band
  const shopL = 3;
  const shopR = 87;

  // sky + stars
  g.sky(const Color(0xFF050A1F), const Color(0xFF14204A));
  _stars(g, t, 1.0, 70, (rows * 0.3).round());

  // roof (tiles)
  const roofH = 16;
  for (int i = 0; i < roofH; i++) {
    final inset = ((roofH - 1 - i) * 10 / roofH).round();
    final x0 = shopL - 2 + inset;
    final x1 = shopR + 2 - inset;
    final y = bt - roofH + i;
    Color base = const Color(0xFF1E2C52);
    if (i == 0) base = const Color(0xFF3A4C86);
    if (i == roofH - 1) base = const Color(0xFF0A0F24);
    g.r(x0, y, x1 - x0, 1, base);
    if (i > 0 && i < roofH - 1) {
      final off = (i % 2) * 2;
      for (int x = x0 + off; x < x1; x += 4) {
        g.r(x, y, 1, 1, const Color(0xFF141C3A));
      }
      if (i % 3 == 0) g.r(x0, y, x1 - x0, 1, const Color(0xFF283967));
    }
  }

  // black cat on the roof ridge
  const cat = [
    '1.....1',
    '11...11',
    '1111111',
    '1.2.2.1',
    '1111111',
    '.11111.',
  ];
  final cx = 44;
  final cy = bt - roofH - 5;
  for (int y = 0; y < cat.length; y++) {
    for (int x = 0; x < cat[y].length; x++) {
      final ch = cat[y][x];
      if (ch == '1') g.r(cx + x, cy + y, 1, 1, const Color(0xFF05060F));
      if (ch == '2') g.r(cx + x, cy + y, 1, 1, const Color(0xFFF2D14C));
    }
  }
  final tail = sin(t * 2.2) > 0 ? 1 : 0;
  g.r(cx + 7, cy + 4 - tail, 1, 1, const Color(0xFF05060F));
  g.r(cx + 8, cy + 3 - tail, 1, 1, const Color(0xFF05060F));

  // sign band with 4 glowing lantern boards
  g.r(shopL, bt, shopR - shopL, 11, const Color(0xFF2A1E2E));
  g.r(shopL, bt, shopR - shopL, 1, const Color(0xFF3A2A3E));
  for (int i = 0; i < 4; i++) {
    final sx = 7 + i * 21;
    final sy = bt + 1;
    final fl = 0.5 + 0.5 * sin(t * 3 + i * 1.7);
    final glow = _mix(const Color(0xFFF4C86A), const Color(0xFFFFE3A6), fl * 0.5);
    g.r(sx - 1, sy + 9, 16, 2, const Color(0x33F4C86A));
    g.r(sx, sy, 14, 9, const Color(0xFF3B2A1A));
    g.r(sx + 1, sy + 1, 12, 7, glow);
    for (int gx = 0; gx < 5; gx++) {
      for (int gyy = 0; gyy < 3; gyy++) {
        if (_h(i * 37 + gx * 5 + gyy) % 3 != 0) {
          g.r(sx + 2 + gx * 2, sy + 2 + gyy * 2, 2, 1, const Color(0xFF4A2A18));
        }
      }
    }
  }

  // storefront wall + posts
  g.r(shopL, bt + 11, shopR - shopL, gy - (bt + 11), const Color(0xFF1B1626));
  g.r(shopL, bt + 11, 3, gy - (bt + 11), const Color(0xFF2A2030));
  g.r(shopR - 3, bt + 11, 3, gy - (bt + 11), const Color(0xFF2A2030));
  g.r(41, bt + 11, 2, gy - (bt + 11), const Color(0xFF2A2030));
  g.r(58, bt + 11, 2, gy - (bt + 11), const Color(0xFF2A2030));

  // left shop window with shelves
  const wx = 9;
  final wy = gy - 24;
  g.r(wx - 1, wy - 1, 33, 21, const Color(0xFF2A2030));
  for (int i = 0; i < 19; i++) {
    g.r(wx, wy + i, 31, 1,
        _mix(const Color(0xFFE8B45E), const Color(0xFFD08C48), i / 18));
  }
  const prod = [
    0xFFE0524D, 0xFF4FA3D9, 0xFF6CC36B, 0xFFF2D14C, 0xFFB86BD6, 0xFFF08A4B, 0xFF3C4A8A,
  ];
  for (int s = 0; s < 3; s++) {
    final sy = wy + 6 + s * 6;
    g.r(wx, sy, 31, 1, const Color(0xFF6A4326));
    for (int x = wx + 1; x < wx + 30; x += 3) {
      final hh = 3 + (_h(x * 3 + s) % 2);
      g.r(x, sy - hh, 2, hh, _c(prod[_h(x * 7 + s) % prod.length]));
    }
  }
  g.disc(wx + 25, wy + 4, 2, const Color(0xFFD8334A));

  // striped awning over the window
  for (int x = 7; x < 42; x++) {
    final stripe = ((x - 7) ~/ 3).isEven;
    final col = stripe ? const Color(0xFFD8334A) : const Color(0xFFF2E8D5);
    g.r(x, gy - 29, 1, 4, col);
    if ((x - 7) % 3 != 2) g.r(x, gy - 25, 1, 1, col);
  }

  // A-frame chalkboard
  g.r(12, gy - 12, 7, 11, const Color(0xFF3B2A1A));
  g.r(13, gy - 11, 5, 9, const Color(0xFF14161C));
  for (int i = 0; i < 4; i++) {
    g.r(14, gy - 10 + i * 2, 3 - (i % 2), 1, const Color(0xFFBFC6D8));
  }

  // glass door with a person inside
  g.r(43, gy - 27, 15, 27, const Color(0xFF2A2030));
  for (int i = 0; i < 26; i++) {
    g.r(44, gy - 26 + i, 13, 1,
        _mix(const Color(0xFFD6E8F8), const Color(0xFF8FB4D8), i / 25));
  }
  g.r(46, gy - 20, 8, 7, const Color(0xFF4A86C8));
  g.r(47, gy - 19, 3, 1, const Color(0xFF9CC8F2));
  g.r(48, gy - 24, 3, 3, const Color(0xFFE8B896));
  g.r(48, gy - 25, 3, 1, const Color(0xFF2A1E1E));
  g.r(47, gy - 21, 5, 10, const Color(0xFFF2F2F6));
  g.r(48, gy - 11, 3, 10, const Color(0xFF2A2F4A));
  g.r(55, gy - 13, 1, 2, const Color(0xFF2A2030));

  // vending machine
  final vf = 0.85 + 0.15 * sin(t * 7);
  g.r(63, gy - 24, 15, 24, const Color(0xFFC8223A));
  g.r(64, gy - 22, 13, 14, _mix(const Color(0xFF2A1020), const Color(0xFFF4F0E4), vf));
  for (int row = 0; row < 3; row++) {
    for (int k = 0; k < 6; k++) {
      final col = _c(prod[_h(row * 11 + k) % prod.length]);
      g.r(65 + k * 2, gy - 21 + row * 4, 1, 3, col);
      g.r(65 + k * 2, gy - 22 + row * 4, 1, 1, const Color(0xFFFFFFFF));
    }
  }
  g.r(65, gy - 6, 6, 3, const Color(0xFF2A0F18));
  g.r(73, gy - 7, 3, 5, const Color(0xFF8F1A2C));
  g.r(63, gy - 24, 15, 1, const Color(0xFFFF6A7C));

  // person in a red hoodie
  g.r(59, gy - 27, 5, 4, const Color(0xFFD12B3A));
  g.r(60, gy - 25, 3, 2, const Color(0xFFE8B896));
  g.r(58, gy - 23, 7, 12, const Color(0xFFD12B3A));
  g.r(59, gy - 11, 2, 10, const Color(0xFF1C1F33));
  g.r(62, gy - 11, 2, 10, const Color(0xFF1C1F33));

  // bottles on the ground
  g.r(79, gy - 4, 2, 4, const Color(0xFF4CAF50));
  g.r(79, gy - 6, 1, 2, const Color(0xFF4CAF50));
  g.r(81, gy - 4, 1, 4, const Color(0xFFE0A030));

  // vertical neon sign
  final nf = 0.75 + 0.25 * sin(t * 5 + 1);
  g.r(79, gy - 31, 9, 31, const Color(0x222E6BE6));
  g.r(82, gy - 30, 5, 30, _mix(const Color(0xFF0E1E6A), const Color(0xFF1B3FA8), nf));
  g.r(82, gy - 30, 5, 1, const Color(0xFF4F86FF));
  g.r(82, gy - 1, 5, 1, const Color(0xFF4F86FF));
  for (int k = 0; k < 5; k++) {
    for (int j = 0; j < 3; j++) {
      if (_h(k * 13 + j) % 4 != 0) g.r(83 + (j % 3), gy - 28 + k * 5 + (j % 2), 1, 2, const Color(0xFFFFFFFF));
    }
  }

  // ivy + bench with a sitting person (left edge)
  for (int y = gy - 28; y < gy - 6; y++) {
    final w = 3 + _h(y) % 4;
    g.r(0, y, w, 1, _h(y * 3) % 3 == 0 ? const Color(0xFF3F8A4B) : const Color(0xFF2F6B3A));
  }
  g.r(0, gy - 11, 9, 1, const Color(0xFF4A2E1C));
  g.r(0, gy - 10, 1, 5, const Color(0xFF4A2E1C));
  g.r(0, gy - 5, 9, 2, const Color(0xFF5A3A24));
  g.r(1, gy - 3, 1, 3, const Color(0xFF3A2414));
  g.r(7, gy - 3, 1, 3, const Color(0xFF3A2414));
  g.r(0, gy - 17, 3, 3, const Color(0xFF2A1E1E));
  g.r(0, gy - 14, 4, 9, const Color(0xFF1A1A28));

  // utility pole with wires
  g.r(5, 3, 3, gy - 32, const Color(0xFF1A1424));
  g.r(1, 8, 12, 1, const Color(0xFF1A1424));
  g.r(2, 15, 10, 1, const Color(0xFF1A1424));
  g.r(2, 7, 1, 1, const Color(0xFF3A3250));
  g.r(11, 7, 1, 1, const Color(0xFF3A3250));
  for (int w = 0; w < 3; w++) {
    final y0 = 8 + w * 3;
    for (int x = 8; x < cols; x++) {
      final f = (x - 8) / (cols - 8);
      final y = y0 + (f * 10 + sin(f * pi) * 4).round();
      g.r(x, y, 1, 1, const Color(0xFF0D1226));
    }
  }

  // street + wet reflections
  const curb = Color(0xFF2E3A66);
  for (int y = gy; y < rows; y++) {
    final f = (y - gy) / max(1, rows - gy);
    g.r(0, y, cols, 1, _mix(const Color(0xFF0B1030), const Color(0xFF060A1C), f));
  }
  g.r(0, gy, cols, 1, curb);
  g.r(0, gy + 1, cols, 1, const Color(0xFF1A2348));
  final depth = max(1, rows - gy);
  void refl(int x0, int w, int rgb, int strength) {
    for (int k = 2; k < depth; k++) {
      if ((k + (t * 3).floor()) % 4 == 0) continue;
      final a = (strength * (1 - k / depth)).round().clamp(0, 255);
      if (a < 6) break;
      final dx = (sin(t * 1.5 + k * 0.7) * 1.2).round();
      g.r(x0 + dx, gy + k, w, 1, Color(rgb).withAlpha(a));
    }
  }

  refl(9, 31, 0xFFE8A04C, 90);
  refl(44, 13, 0xFFBFD8F0, 110);
  refl(63, 15, 0xFFD8334A, 120);
  refl(82, 5, 0xFF2E6BE6, 150);
  refl(7, 35, 0xFFD8334A, 40);
  for (int i = 0; i < 4; i++) {
    refl(7 + i * 21, 14, 0xFFF4C86A, 60);
  }
  for (int i = 0; i < 6; i++) {
    final span = cols + 30;
    final x = ((_rf(i + 70) * span + t * (3 + i)) % span) - 15;
    g.r(x, gy + 4 + i * 5, 12 + (i % 3) * 6, 1, const Color(0x442E6BE6));
  }
}

'''

s = read("backgrounds.dart")
if "_izakaya" not in s:
    s = replace_once(
        s,
        "  BgDef('forest', 'غابة', 'Forest', 0),\n",
        "  BgDef('izakaya', 'متجر طوكيو الليلي', 'Tokyo night shop', 0),\n  BgDef('forest', 'غابة', 'Forest', 0),\n",
        "bg catalogue",
    )
    s = replace_once(
        s,
        "    switch (id) {\n      case 'forest':\n        _forest(g, t, hour);\n        break;\n",
        "    switch (id) {\n      case 'izakaya':\n        _izakaya(g, t);\n        break;\n      case 'forest':\n        _forest(g, t, hour);\n        break;\n",
        "scene switch",
    )
    s = replace_once(
        s,
        "// ───────────────────────── Scene painter ─────────────────────────\n",
        IZAKAYA + "// ───────────────────────── Scene painter ─────────────────────────\n",
        "scene painter marker",
    )
    write("backgrounds.dart", s)
    print("backgrounds.dart patched")

print("Tokyo Night design applied.")
