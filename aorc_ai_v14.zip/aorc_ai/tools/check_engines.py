"""CI guard: every speech engine must be wired end to end.

Checks (run from the Flutter project root, after tools/patch_manifest.py):
  - each id in kTtsEngines has engine_<id> (+ _note for non-auto) and
    badge_<id> strings in both languages (badge/name only for engines that speak)
  - piper and system have an implementation in speech.dart
  - kTtsChain only lists engines that exist in the registry
  - no stale online-engine code is left in speech.dart
  - the patched AndroidManifest allows INTERNET and queries TTS_SERVICE
Exits non-zero with ::error:: lines so the workflow stops before building.
"""
import re
import sys
from pathlib import Path

errors = []

reg = Path("lib/tts_engines.dart").read_text(encoding="utf-8")
ids = re.findall(r"TtsEngine\('([a-z_]+)'", reg)
if not ids:
    errors.append("no engines found in lib/tts_engines.dart")

strings = Path("lib/strings.dart").read_text(encoding="utf-8") + Path("lib/strings_voice.dart").read_text(encoding="utf-8")
speech = Path("lib/speech.dart").read_text(encoding="utf-8")

for i in ids:
    need = [f"'engine_{i}'"]
    if i != "auto":
        need += [f"'engine_{i}_note'", f"'badge_{i}'"]
    for key in need:
        n = strings.count(key + ":")
        if n < 2:
            errors.append(f"string {key} is defined {n}x (needs ar + en)")
    if i == "piper" and "_piper(" not in speech:
        errors.append("engine 'piper' has no implementation in speech.dart")
    if i == "system" and "_speakSystem(" not in speech:
        errors.append("engine 'system' has no implementation in speech.dart")

chain = re.search(r"kTtsChain\s*=\s*\[([^\]]*)\]", reg)
for cid in re.findall(r"'([a-z_]+)'", chain.group(1) if chain else ""):
    if cid not in ids:
        errors.append(f"kTtsChain lists unknown engine '{cid}'")
for stale in ("translate_tts", "streamelements", "responsivevoice", "router.huggingface.co", "/audio/speech"):
    if stale in speech:
        errors.append(f"speech.dart still contains an online engine ({stale})")

manifest = Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    xml = manifest.read_text(encoding="utf-8")
    for token in ("android.permission.INTERNET", "android.intent.action.TTS_SERVICE", "android.speech.RecognitionService"):
        if token not in xml:
            errors.append(f"AndroidManifest.xml is missing {token}")
else:
    errors.append("AndroidManifest.xml not found (run patch_manifest first)")

for e in errors:
    print("::error::" + e)
if errors:
    sys.exit(1)
print("Engines OK:", ", ".join(ids))
