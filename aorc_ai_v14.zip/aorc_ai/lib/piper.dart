import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:sherpa_onnx/sherpa_onnx.dart' as sherpa;

/// One downloadable offline neural voice (Piper model packaged by sherpa-onnx).
class PiperVoice {
  final String id; // e.g. en_US-amy-low
  final String lang; // two letters
  final String gender; // f | m
  final String name;
  final int mb; // approximate download size
  const PiperVoice(this.id, this.lang, this.gender, this.name, this.mb);

  String get url =>
      'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-$id.tar.bz2';
}

/// Catalog. If a file name ever disappears upstream the download reports
/// "HTTP 404" in the voice test screen, and only this table needs a fix.
const List<PiperVoice> kPiperVoices = [
  PiperVoice('en_US-amy-low', 'en', 'f', 'Amy', 65),
  PiperVoice('en_US-ryan-low', 'en', 'm', 'Ryan', 65),
  PiperVoice('ar_JO-kareem-low', 'ar', 'm', 'Kareem', 65),
  PiperVoice('fr_FR-siwis-low', 'fr', 'f', 'Siwis', 65),
  PiperVoice('fr_FR-gilles-low', 'fr', 'm', 'Gilles', 65),
  PiperVoice('de_DE-eva_k-x_low', 'de', 'f', 'Eva', 65),
  PiperVoice('de_DE-thorsten-low', 'de', 'm', 'Thorsten', 65),
  PiperVoice('es_ES-davefx-medium', 'es', 'm', 'Davefx', 80),
  PiperVoice('it_IT-paola-medium', 'it', 'f', 'Paola', 80),
  PiperVoice('it_IT-riccardo-x_low', 'it', 'm', 'Riccardo', 65),
  PiperVoice('ru_RU-irina-medium', 'ru', 'f', 'Irina', 80),
  PiperVoice('ru_RU-denis-medium', 'ru', 'm', 'Denis', 80),
  PiperVoice('tr_TR-fahrettin-medium', 'tr', 'm', 'Fahrettin', 80),
  PiperVoice('pt_BR-faber-medium', 'pt', 'm', 'Faber', 80),
  PiperVoice('zh_CN-huayan-medium', 'zh', 'f', 'Huayan', 80),
];

class Piper {
  static final Set<String> _installed = {};
  static Future<void> _q = Future.value();
  static Isolate? _iso;
  static SendPort? _cmd;
  static String? _loaded;

  static Future<String> root() async {
    final d = await getApplicationSupportDirectory();
    final p = '${d.path}/piper';
    await Directory(p).create(recursive: true);
    return p;
  }

  static List<PiperVoice> forLang(String code) =>
      kPiperVoices.where((v) => v.lang == code).toList();

  static bool installed(PiperVoice v) => _installed.contains(v.id);

  /// Rescans the disk for finished downloads.
  static Future<void> refresh() async {
    try {
      final r = await root();
      _installed.clear();
      for (final v in kPiperVoices) {
        if (_complete(r, v)) _installed.add(v.id);
      }
    } catch (_) {}
  }

  static bool _complete(String r, PiperVoice v) {
    final b = '$r/vits-piper-${v.id}';
    return File('$b/${v.id}.onnx').existsSync() &&
        File('$b/tokens.txt').existsSync() &&
        Directory('$b/espeak-ng-data').existsSync();
  }

  /// Best installed voice for [code]: the wanted gender first, any other second.
  static PiperVoice? pick(String code, String gender) {
    final list = forLang(code).where(installed).toList();
    if (list.isEmpty) return null;
    for (final v in list) {
      if (v.gender == gender) return v;
    }
    return list.first;
  }

  static Future<void> download(PiperVoice v, void Function(double p, String phase) onProgress) async {
    final r = await root();
    final tmp = File('$r/${v.id}.tar.bz2');
    final client = http.Client();
    try {
      final req = http.Request('GET', Uri.parse(v.url));
      req.headers['User-Agent'] = 'Mozilla/5.0';
      final res = await client.send(req).timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) throw 'HTTP ${res.statusCode}';
      final total = res.contentLength ?? 0;
      var got = 0;
      final sink = tmp.openWrite();
      try {
        await for (final chunk in res.stream.timeout(const Duration(seconds: 30))) {
          sink.add(chunk);
          got += chunk.length;
          if (total > 0) onProgress(got / total * 0.85, 'download');
        }
      } finally {
        await sink.close();
      }
      onProgress(0.88, 'extract');
      final tp = tmp.path;
      final rr = r;
      await Isolate.run(() => _extract(tp, rr));
      if (!_complete(r, v)) throw 'files missing after extract';
      _installed.add(v.id);
      onProgress(1, 'done');
    } finally {
      client.close();
      try {
        if (tmp.existsSync()) tmp.deleteSync();
      } catch (_) {}
    }
  }

  static Future<void> delete(PiperVoice v) async {
    if (_loaded == v.id) _kill();
    try {
      final r = await root();
      final d = Directory('$r/vits-piper-${v.id}');
      if (d.existsSync()) await d.delete(recursive: true);
    } catch (_) {}
    _installed.remove(v.id);
  }

  static void _kill() {
    _iso?.kill(priority: Isolate.immediate);
    _iso = null;
    _cmd = null;
    _loaded = null;
  }

  static Future<T> _serial<T>(Future<T> Function() f) {
    final c = Completer<T>();
    _q = _q.whenComplete(() async {
      try {
        c.complete(await f());
      } catch (e, st) {
        c.completeError(e, st);
      }
    });
    return c.future;
  }

  static Future<void> _ensure(PiperVoice v) async {
    if (_loaded == v.id && _cmd != null) return;
    _kill();
    final r = await root();
    final rp = ReceivePort();
    final iso = await Isolate.spawn(_entry, [rp.sendPort, r, v.id]);
    dynamic first;
    try {
      first = await rp.first.timeout(const Duration(seconds: 90));
    } finally {
      rp.close();
    }
    if (first is SendPort) {
      _iso = iso;
      _cmd = first;
      _loaded = v.id;
    } else {
      iso.kill(priority: Isolate.immediate);
      throw '$first';
    }
  }

  /// Returns a 16-bit mono WAV for [text]. Runs in a background isolate.
  static Future<Uint8List> synth(PiperVoice v, String text, double speed) {
    return _serial(() async {
      await _ensure(v);
      final rp = ReceivePort();
      try {
        _cmd!.send([rp.sendPort, text, speed]);
        final res = await rp.first.timeout(const Duration(seconds: 60));
        if (res is Uint8List) return res;
        throw '$res';
      } finally {
        rp.close();
      }
    });
  }
}

void _extract(String tarPath, String dest) {
  final bytes = File(tarPath).readAsBytesSync();
  final tarBytes = BZip2Decoder().decodeBytes(bytes);
  final arc = TarDecoder().decodeBytes(tarBytes);
  for (final f in arc.files) {
    if (f.name.contains('..')) continue;
    final path = '$dest/${f.name}';
    if (f.isFile) {
      final o = File(path);
      o.createSync(recursive: true);
      o.writeAsBytesSync(f.content as List<int>);
    } else {
      Directory(path).createSync(recursive: true);
    }
  }
}

void _entry(List<dynamic> a) {
  final main = a[0] as SendPort;
  final root = a[1] as String;
  final id = a[2] as String;
  final cmd = ReceivePort();
  sherpa.OfflineTts? tts;
  try {
    sherpa.initBindings();
    final base = '$root/vits-piper-$id';
    final vits = sherpa.OfflineTtsVitsModelConfig(
      model: '$base/$id.onnx',
      tokens: '$base/tokens.txt',
      dataDir: '$base/espeak-ng-data',
    );
    final mc = sherpa.OfflineTtsModelConfig(
      vits: vits,
      numThreads: 2,
      debug: false,
      provider: 'cpu',
    );
    tts = sherpa.OfflineTts(sherpa.OfflineTtsConfig(model: mc));
    main.send(cmd.sendPort);
  } catch (e) {
    main.send('Piper load failed: $e');
    return;
  }
  cmd.listen((m) {
    final reply = (m as List)[0] as SendPort;
    try {
      final audio = tts!.generate(text: m[1] as String, sid: 0, speed: m[2] as double);
      reply.send(_wav(audio.samples, audio.sampleRate));
    } catch (e) {
      reply.send('Piper synth failed: $e');
    }
  });
}

Uint8List _wav(Float32List s, int rate) {
  final n = s.length;
  final data = n * 2;
  final b = ByteData(44 + data);
  void str(int o, String t) {
    for (int i = 0; i < t.length; i++) {
      b.setUint8(o + i, t.codeUnitAt(i));
    }
  }

  str(0, 'RIFF');
  b.setUint32(4, 36 + data, Endian.little);
  str(8, 'WAVE');
  str(12, 'fmt ');
  b.setUint32(16, 16, Endian.little);
  b.setUint16(20, 1, Endian.little);
  b.setUint16(22, 1, Endian.little);
  b.setUint32(24, rate, Endian.little);
  b.setUint32(28, rate * 2, Endian.little);
  b.setUint16(32, 2, Endian.little);
  b.setUint16(34, 16, Endian.little);
  str(36, 'data');
  b.setUint32(40, data, Endian.little);
  for (int i = 0; i < n; i++) {
    final v = (s[i].clamp(-1.0, 1.0) * 32767).round();
    b.setInt16(44 + i * 2, v, Endian.little);
  }
  return b.buffer.asUint8List();
}
