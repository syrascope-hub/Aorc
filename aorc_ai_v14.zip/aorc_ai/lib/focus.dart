import 'dart:async';

import 'package:flutter/material.dart';

import 'cards_tab.dart';
import 'common.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Pomodoro timer tied to study progress.
class FocusScreen extends StatefulWidget {
  const FocusScreen({super.key});
  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> {
  int minutes = 25;
  bool isBreak = false;
  bool running = false;
  int remaining = 25 * 60;
  DateTime? _end;
  Timer? _timer;
  String? note;

  AppState get s => AppState.I;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _set(int m, {bool brk = false}) {
    _timer?.cancel();
    setState(() {
      minutes = m;
      isBreak = brk;
      running = false;
      remaining = m * 60;
    });
  }

  void _start() {
    _end = DateTime.now().add(Duration(seconds: remaining));
    setState(() {
      running = true;
      note = null;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      final left = _end!.difference(DateTime.now()).inSeconds;
      if (left <= 0) {
        _done();
      } else if (mounted) {
        setState(() => remaining = left);
      }
    });
  }

  void _pause() {
    _timer?.cancel();
    setState(() => running = false);
  }

  void _done() {
    _timer?.cancel();
    Sfx.play('win');
    if (!isBreak) {
      s.bump('focus', minutes);
      s.addCoins(max(1, minutes ~/ 5));
    }
    if (!mounted) return;
    setState(() {
      running = false;
      note = isBreak ? t('break_over') : '${t('focus_done')} +${max(1, minutes ~/ 5)} ${t('coins')}';
      remaining = isBreak ? 25 * 60 : 5 * 60;
      if (!isBreak) {
        isBreak = true;
        minutes = 5;
      } else {
        isBreak = false;
        minutes = 25;
      }
    });
  }

  int max(int a, int b) => a > b ? a : b;

  String get _clock {
    final m = (remaining ~/ 60).toString().padLeft(2, '0');
    final sec = (remaining % 60).toString().padLeft(2, '0');
    return '$m:$sec';
  }

  @override
  Widget build(BuildContext context) {
    final total = minutes * 60;
    return PixelPage(
      title: t('focus'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('focus_help')),
          const SizedBox(height: 14),
          if (!running)
            PixelChips<int>(
              options: [(15, '15'), (25, '25'), (45, '45'), (5, '5 · ${t('break_word')}')],
              value: minutes,
              onChanged: (v) => _set(v, brk: v == 5),
            ),
          const SizedBox(height: 16),
          PixelBox(
            padding: const EdgeInsets.symmetric(vertical: 26),
            child: SizedBox(
              width: double.infinity,
              child: Column(
                children: [
                  Sprite(isBreak ? 'heart' : 'timer', px: 6),
                  const SizedBox(height: 12),
                  Text(_clock,
                      style: const TextStyle(fontSize: 54, fontWeight: FontWeight.w900, height: 1)),
                  const SizedBox(height: 14),
                  PixelBar(value: total == 0 ? 0 : 1 - remaining / total, segs: 20, height: 10),
                ],
              ),
            ),
          ),
          if (note != null) ...[
            const SizedBox(height: 10),
            Center(child: tx(note!, bold: true, size: 15, align: TextAlign.center)),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: running ? t('pause') : t('start'),
                  icon: running ? null : 'bolt',
                  expand: true,
                  onTap: running ? _pause : _start,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: PixelButton(
                  label: t('reset'),
                  filled: false,
                  expand: true,
                  onTap: () => _set(minutes, brk: isBreak),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          PixelButton(
            label: t('srs_review'),
            icon: 'sparkle',
            filled: false,
            expand: true,
            onTap: () => pushPage(context, const ReviewScreen()),
          ),
          const SizedBox(height: 10),
          Center(child: tx('${t('focus_total')}: ${s.stat['focus'] ?? 0} ${t('minutes')}', color: C.gray, bold: true, size: 13)),
        ],
      ),
    );
  }
}
