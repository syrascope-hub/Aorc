import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Picks a photo from the camera or gallery (downscaled for the AI).
Future<Uint8List?> pickPhoto(BuildContext context, {required bool camera}) async {
  try {
    final x = await ImagePicker().pickImage(
      source: camera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 1280,
      maxHeight: 1280,
      imageQuality: 80,
    );
    if (x == null) return null;
    return await x.readAsBytes();
  } catch (_) {
    if (context.mounted) toast(context, t('photo_failed'));
    return null;
  }
}

class _Found {
  final String word, translation;
  bool on = true;
  _Found(this.word, this.translation);
}

/// Photo to cards: name the objects in a picture, or pull vocabulary from a page.
class VisionCardScreen extends StatefulWidget {
  const VisionCardScreen({super.key});
  @override
  State<VisionCardScreen> createState() => _VisionCardScreenState();
}

class _VisionCardScreenState extends State<VisionCardScreen> {
  int mode = 0; // 0 objects, 1 page text
  Uint8List? photo;
  bool busy = false;
  List<_Found> found = [];

  AppState get s => AppState.I;

  Future<void> _pick(bool camera) async {
    final b = await pickPhoto(context, camera: camera);
    if (b != null && mounted) {
      setState(() {
        photo = b;
        found = [];
      });
    }
  }

  Future<void> _analyze() async {
    if (photo == null) return;
    if (!s.aiReady) {
      toast(context, t('need_token'));
      return;
    }
    setState(() => busy = true);
    try {
      final fl = langOf(s.frontLang).en;
      final bl = langOf(s.backLang).en;
      final prompt = mode == 0
          ? 'Look at the image. List the 1 to 6 most important distinct objects you can clearly see. '
              'For each give the word in $fl and its translation in $bl. '
              'Output ONLY a JSON array like [{"word":"...","translation":"..."}].'
          : 'Read the text in this image. Extract up to 25 useful vocabulary words or short phrases '
              '(skip names and numbers). Give each word in $fl (translate it to $fl if the text is in another language) '
              'and its translation in $bl. Output ONLY a JSON array like [{"word":"...","translation":"..."}].';
      final r = await Ai.vision(photo!, prompt, maxTokens: 1500);
      final list = Ai.jsonList(r);
      final out = <_Found>[];
      for (final e in list) {
        if (e is! Map) continue;
        final w = (e['word'] ?? '').toString().trim();
        final tr = (e['translation'] ?? '').toString().trim();
        if (w.isNotEmpty && tr.isNotEmpty) out.add(_Found(w, tr));
      }
      if (out.isEmpty) throw AiError(t('bad_ai_format'));
      if (mounted) setState(() => found = out);
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final list = [
      for (final f in found)
        if (f.on) CardItem(id: s.newId(), front: f.word, back: f.translation),
    ];
    if (list.isEmpty) return;
    await s.addCards(list);
    Sfx.play('win');
    if (mounted) {
      toast(context, '${t('cards_added')}: ${list.length}');
      setState(() => found = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('photo_cards'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('photo_help')),
          const SizedBox(height: 12),
          PixelChips<int>(
            options: [(0, t('photo_objects')), (1, t('photo_page'))],
            value: mode,
            onChanged: (v) => setState(() {
              mode = v;
              found = [];
            }),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                    label: t('camera'),
                    icon: 'camera',
                    expand: true,
                    onTap: () => _pick(true)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: PixelButton(
                    label: t('gallery'),
                    icon: 'folder',
                    filled: false,
                    expand: true,
                    onTap: () => _pick(false)),
              ),
            ],
          ),
          if (photo != null) ...[
            const SizedBox(height: 12),
            Center(
              child: PixelBox(
                padding: const EdgeInsets.all(4),
                u: 2,
                child: Image.memory(photo!, height: 200, fit: BoxFit.contain),
              ),
            ),
            const SizedBox(height: 12),
            PixelButton(
              label: t('analyze'),
              icon: 'sparkle',
              expand: true,
              busy: busy,
              onTap: _analyze,
            ),
          ],
          if (found.isNotEmpty) ...[
            PixelTitle(t('found_words')),
            for (final f in found)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: pixelCheck(f.on, '${f.word}  →  ${f.translation}', () => setState(() => f.on = !f.on)),
              ),
            const SizedBox(height: 10),
            PixelButton(
              label: '${t('create_cards')} (${found.where((f) => f.on).length})',
              icon: 'create',
              expand: true,
              onTap: _save,
            ),
          ],
        ],
      ),
    );
  }
}
