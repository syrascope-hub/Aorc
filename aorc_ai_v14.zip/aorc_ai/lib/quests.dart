import 'package:flutter/material.dart';

import 'common.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

// ───────────────────────── Daily quests ─────────────────────────

class QuestDef {
  final String id, key, sprite;
  final int target, reward;
  const QuestDef(this.id, this.key, this.sprite, this.target, this.reward);
}

const List<QuestDef> kQuests = [
  QuestDef('q_review', 'review', 'cards', 15, 10),
  QuestDef('q_games', 'games', 'games', 2, 8),
  QuestDef('q_combo', 'combo', 'bolt', 5, 8),
  QuestDef('q_chat', 'chat', 'chat', 3, 8),
  QuestDef('q_add', 'add', 'create', 3, 5),
  QuestDef('q_focus', 'focus', 'timer', 10, 6),
  QuestDef('q_pron', 'pron', 'mic', 5, 8),
];

class QuestsScreen extends StatelessWidget {
  const QuestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('quests'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final done = kQuests.where((q) => s.quest(q.key) >= q.target).length;
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              infoBox('${t('quests_help')}  ($done / ${kQuests.length})'),
              const SizedBox(height: 12),
              for (final q in kQuests) _row(context, q),
            ],
          );
        },
      ),
    );
  }

  Widget _row(BuildContext context, QuestDef q) {
    final s = AppState.I;
    final cur = s.quest(q.key);
    final done = cur >= q.target;
    final claimed = s.questClaimed.contains(q.id);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: PixelBox(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Sprite(q.sprite, px: 3.4),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  tx(t(q.id), size: 14.5, bold: true),
                  const SizedBox(height: 6),
                  PixelBar(value: cur / q.target, segs: 10, height: 10),
                  const SizedBox(height: 4),
                  tx('${cur > q.target ? q.target : cur} / ${q.target}', size: 12, color: C.gray, bold: true),
                ],
              ),
            ),
            const SizedBox(width: 10),
            if (claimed)
              const Sprite('check', px: 3)
            else
              PixelButton(
                label: '+${q.reward}',
                icon: 'coin',
                small: true,
                filled: done,
                onTap: done
                    ? () {
                        s.questClaimed.add(q.id);
                        s.addCoins(q.reward);
                        Sfx.play('win');
                      }
                    : null,
              ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── Achievements ─────────────────────────

class AchDef {
  final String id, sprite;
  final int target, reward;
  final int Function(AppState) cur;
  const AchDef(this.id, this.sprite, this.target, this.reward, this.cur);
}

final List<AchDef> kAchs = [
  AchDef('ach_cards10', 'cards', 10, 5, (s) => s.cards.length),
  AchDef('ach_cards100', 'cards', 100, 30, (s) => s.cards.length),
  AchDef('ach_rev100', 'check', 100, 20, (s) => s.totalReviews),
  AchDef('ach_rev1000', 'check', 1000, 100, (s) => s.totalReviews),
  AchDef('ach_streak7', 'flame', 7, 25, (s) => s.bestStreak),
  AchDef('ach_streak30', 'flame', 30, 100, (s) => s.bestStreak),
  AchDef('ach_master20', 'star', 20, 30, (s) => s.masteredCount),
  AchDef('ach_survival15', 'heart', 15, 20, (s) => s.stat['survival_best'] ?? 0),
  AchDef('ach_boss1', 'skull', 1, 15, (s) => s.stat['boss'] ?? 0),
  AchDef('ach_boss5', 'sword', 5, 50, (s) => s.stat['boss'] ?? 0),
  AchDef('ach_chat20', 'chat', 20, 20, (s) => s.stat['chat'] ?? 0),
  AchDef('ach_focus120', 'timer', 120, 20, (s) => s.stat['focus'] ?? 0),
  AchDef('ach_pron50', 'mic', 50, 25, (s) => s.stat['pron'] ?? 0),
  AchDef('ach_level', 'trophy', 1, 10, (s) => s.placement.isEmpty ? 0 : 1),
];

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('achievements'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(14),
          children: [
            for (final a in kAchs) _row(a),
          ],
        ),
      ),
    );
  }

  Widget _row(AchDef a) {
    final s = AppState.I;
    final cur = a.cur(s);
    final done = cur >= a.target;
    final claimed = s.achClaimed.contains(a.id);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: PixelBox(
        color: done ? C.white : C.creamDeep,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Sprite(done ? a.sprite : 'lock', px: 3.4),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  tx(t(a.id), size: 14.5, bold: true),
                  const SizedBox(height: 4),
                  tx('${cur > a.target ? a.target : cur} / ${a.target}',
                      size: 12, color: C.gray, bold: true),
                ],
              ),
            ),
            if (claimed)
              const Sprite('check', px: 3)
            else
              PixelButton(
                label: '+${a.reward}',
                icon: 'coin',
                small: true,
                filled: done,
                onTap: done
                    ? () {
                        s.achClaimed.add(a.id);
                        s.addCoins(a.reward);
                        Sfx.play('win');
                      }
                    : null,
              ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── Shop ─────────────────────────

class ShopItem {
  final String sprite;
  final int price;
  const ShopItem(this.sprite, this.price);
}

const List<ShopItem> kShop = [
  ShopItem('robot', 0),
  ShopItem('star', 30),
  ShopItem('heart', 30),
  ShopItem('bulb', 60),
  ShopItem('flame', 50),
  ShopItem('cat', 80),
  ShopItem('ghost', 100),
  ShopItem('skull', 150),
  ShopItem('alien', 120),
  ShopItem('crown', 250),
];

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('shop'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(14),
          children: [
            infoBox(t('shop_help')),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.05,
              children: [for (final it in kShop) _card(context, it)],
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, ShopItem it) {
    final s = AppState.I;
    final owned = s.owned.contains(it.sprite);
    final equipped = s.mascot == it.sprite;
    return PixelBox(
      color: equipped ? C.creamDeep : C.white,
      padding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(child: Center(child: Sprite(it.sprite, px: 6))),
          const SizedBox(height: 6),
          PixelButton(
            label: equipped
                ? t('equipped')
                : (owned ? t('equip') : '${it.price}'),
            icon: owned ? null : 'coin',
            small: true,
            filled: !owned,
            expand: true,
            onTap: equipped
                ? null
                : () {
                    if (owned) {
                      s.mascot = it.sprite;
                      s.saveExtra();
                    } else if (s.coins >= it.price) {
                      s.coins -= it.price;
                      s.owned.add(it.sprite);
                      s.mascot = it.sprite;
                      s.saveExtra();
                      Sfx.play('win');
                    } else {
                      toast(context, t('not_enough_coins'));
                    }
                  },
          ),
        ],
      ),
    );
  }
}
