import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

Future<String?> promptText(BuildContext context, String title, {String initial = ''}) async {
  final c = TextEditingController(text: initial);
  final res = await showDialog<String>(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: C.cream,
      shape: RoundedRectangleBorder(side: BorderSide(color: C.ink, width: 3)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PixelTitle(title),
            PixelField(controller: c),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: t('cancel'),
                    filled: false,
                    onTap: () => Navigator.pop(ctx),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PixelButton(label: t('save'), onTap: () => Navigator.pop(ctx, c.text.trim())),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
  if (res == null || res.isEmpty) return null;
  return res;
}

/// Horizontal deck selector shown above the cards.
class DeckBar extends StatelessWidget {
  const DeckBar({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    Widget chip(String id, String label) {
      final on = s.activeDeck == id;
      return Padding(
        padding: const EdgeInsetsDirectional.only(end: 6),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Sfx.play('tap');
            s.setActiveDeck(id);
          },
          child: PixelBox(
            u: 2,
            shadow: false,
            color: on ? C.ink : C.white,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            child: Text(label,
                style: TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w800, color: on ? C.cream : C.ink)),
          ),
        ),
      );
    }

    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => SizedBox(
      height: 38,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          chip('all', t('deck_all')),
          for (final d in s.decks) chip(d.id, deckLabel(d)),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => pushPage(context, const DecksScreen()),
            child: const PixelBox(
              u: 2,
              shadow: false,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              child: Sprite('folder', px: 2),
            ),
          ),
        ],
      ),
      ),
    );
  }
}

class DecksScreen extends StatelessWidget {
  const DecksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('decks'),
      actions: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () async {
            final n = await promptText(context, t('new_deck'));
            if (n != null) await s.addDeck(n);
          },
          child: const PixelBox(padding: EdgeInsets.all(8), child: Sprite('create', px: 2.6)),
        ),
      ],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(14),
          children: [
            infoBox(t('decks_help')),
            const SizedBox(height: 12),
            _row(context, 'all', t('deck_all'), s.cards.length, null),
            for (final d in s.decks)
              _row(context, d.id, deckLabel(d), s.cards.where((c) => c.deckId == d.id).length, d),
          ],
        ),
      ),
    );
  }

  Widget _row(BuildContext context, String id, String label, int count, Deck? d) {
    final s = AppState.I;
    final on = s.activeDeck == id;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Sfx.play('tap');
          s.setActiveDeck(id);
        },
        child: PixelBox(
          color: on ? C.ink : C.white,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Sprite('folder', px: 3, tint: on ? C.cream : C.ink),
              const SizedBox(width: 10),
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900, color: on ? C.cream : C.ink)),
              ),
              Text('$count',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w800, color: on ? C.cream : C.gray)),
              if (d != null) ...[
                const SizedBox(width: 10),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () async {
                    final n = await promptText(context, t('rename'), initial: deckLabel(d));
                    if (n != null) {
                      d.name = n;
                      await s.saveDecks();
                    }
                  },
                  child: Sprite('create', px: 2.4, tint: on ? C.cream : C.ink),
                ),
                if (d.id != 'default') ...[
                  const SizedBox(width: 10),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () async {
                      if (await confirmDialog(context, t('confirm_delete_deck'))) {
                        await s.deleteDeck(d);
                      }
                    },
                    child: Sprite('trash', px: 2.4, tint: on ? C.cream : C.ink),
                  ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }
}
