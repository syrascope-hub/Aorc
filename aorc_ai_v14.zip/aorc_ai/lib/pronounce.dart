import 'package:flutter/material.dart';

import 'common.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'stt.dart';
import 'strings.dart';
import 'theme.dart';

/// Say the word aloud; speech recognition scores how close it was.
class PronounceScreen extends StatefulWidget {
  const PronounceScreen({super.key});
  @override
  State<PronounceScreen> createState() => _PronounceScreenState();
}

class _PronounceScreenState extends State<PronounceScreen> {
  List<CardItem> list = [];
  int idx = 0;
  int count = 5;
  bool started = false;
  bool listening = false;
  bool judged = false;
  String heard = '';
  double sim = 0;
  final List<double> results = [];

  AppState get s => AppState.I;

  @override
  void dispose() {
    Stt.stop();
    super.dispose();
  }

  void _start() {
    final pool = s.scope.where((c) => c.front.trim().split(' ').length <= 3).toList();
    if (pool.isEmpty) return;
    final weak = weakestCards(pool, count * 2)..shuffle();
    list = weak.take(count).toList();
    idx = 0;
    results.clear();
    _reset();
    setState(() => started = true);
  }

  void _reset() {
    heard = '';
    sim = 0;
    judged = false;
    listening = false;
  }

  double _score(String said, String target) {
    final h = normText(said);
    final f = normText(target);
    if (h.isEmpty) return 0;
    if (h == f) return 1;
    if (h.split(' ').contains(f) || h.contains(f)) return 0.92;
    return similarity(h, f);
  }

  void _judge() {
    if (judged) return;
    final target = list[idx].front;
    final v = _score(heard, target);
    judged = true;
    listening = false;
    sim = v;
    results.add(v);
    if (v >= 0.75) {
      s.bump('pron');
      Sfx.play('ok');
    } else {
      Sfx.play('bad');
    }
    setState(() {});
  }

  Future<void> _mic() async {
    if (listening) {
      await Stt.stop();
      if (mounted) _judge();
      return;
    }
    setState(() {
      heard = '';
      judged = false;
    });
    final ok = await Stt.start(s.frontLang, (text, done) {
      if (!mounted) return;
      heard = text;
      if (done) {
        _judge();
      } else {
        setState(() {});
      }
    });
    if (!mounted) return;
    if (!ok) {
      toast(context, t('stt_unavailable'));
    } else {
      setState(() => listening = true);
    }
  }

  void _next() {
    if (idx + 1 >= list.length) {
      final avg = results.isEmpty ? 0.0 : results.reduce((a, b) => a + b) / results.length;
      s.addCoins((avg * list.length).round());
      Sfx.play('win');
      setState(() => idx = list.length);
    } else {
      setState(() {
        idx++;
        _reset();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('pronounce'),
      actions: [coinChip()],
      child: !started ? _intro() : (idx >= list.length ? _summary() : _body()),
    );
  }

  Widget _intro() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        infoBox(t('pronounce_help')),
        PixelTitle(t('words_count')),
        PixelChips<int>(
          options: const [(5, '5'), (10, '10'), (15, '15')],
          value: count,
          onChanged: (v) => setState(() => count = v),
        ),
        const SizedBox(height: 18),
        PixelButton(
          label: t('start'),
          icon: 'mic',
          expand: true,
          onTap: s.scope.isEmpty ? null : _start,
        ),
      ],
    );
  }

  Widget _summary() {
    final avg = results.isEmpty ? 0.0 : results.reduce((a, b) => a + b) / results.length;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('trophy', px: 8),
            const SizedBox(height: 16),
            tx('${(avg * 100).round()}%', size: 30, bold: true),
            const SizedBox(height: 6),
            tx('+${(avg * list.length).round()} ${t('coins')}', bold: true),
            const SizedBox(height: 20),
            PixelButton(label: t('play_again'), icon: 'mic', onTap: _start),
            const SizedBox(height: 10),
            PixelButton(
                label: t('back'), filled: false, onTap: () => Navigator.of(context).maybePop()),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    final c = list[idx];
    final verdict = sim >= 0.85 ? t('pron_great') : (sim >= 0.6 ? t('pron_ok') : t('pron_retry'));
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(children: [
          Expanded(child: PixelBar(value: idx / list.length, segs: 12, height: 10)),
          const SizedBox(width: 10),
          tx('${idx + 1} / ${list.length}', bold: true, color: C.gray),
        ]),
        const SizedBox(height: 14),
        PixelBox(
          padding: const EdgeInsets.all(18),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              children: [
                Text(c.front,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                tx(c.back, size: 15, color: C.dark),
                const SizedBox(height: 12),
                SpeakBtn(c.front, s.frontLang),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        Center(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _mic,
            child: PixelBox(
              color: listening ? C.ink : C.white,
              padding: const EdgeInsets.all(22),
              child: Sprite('mic', px: 6, tint: listening ? C.cream : C.ink),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Center(child: tx(listening ? t('listening') : t('tap_to_speak'), bold: true, color: C.gray)),
        if (heard.isNotEmpty) ...[
          const SizedBox(height: 12),
          Center(child: tx('“$heard”', size: 18, bold: true, align: TextAlign.center)),
        ],
        if (judged) ...[
          const SizedBox(height: 12),
          PixelBox(
            color: sim >= 0.75 ? C.ink : C.white,
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              child: Column(
                children: [
                  Text('${(sim * 100).round()}%',
                      style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          color: sim >= 0.75 ? C.cream : C.ink)),
                  Text(verdict,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: sim >= 0.75 ? C.cream : C.ink)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: t('retry'),
                  filled: false,
                  expand: true,
                  onTap: () {
                    if (results.isNotEmpty) results.removeLast();
                    setState(_reset);
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(child: PixelButton(label: t('next'), expand: true, onTap: _next)),
            ],
          ),
        ],
      ],
    );
  }
}
