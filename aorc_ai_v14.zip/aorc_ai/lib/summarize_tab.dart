import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

import 'rich.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class SummarizeTab extends StatefulWidget {
  const SummarizeTab({super.key});
  @override
  State<SummarizeTab> createState() => _SummarizeTabState();
}

class _SummarizeTabState extends State<SummarizeTab> {
  int mode = 0; // 0 text, 1 youtube, 2 pdf
  String length = 'medium';
  String outLang = 'ar';
  final text = TextEditingController();
  final link = TextEditingController();
  String pdfName = '';
  String pdfText = '';
  bool busy = false;
  bool pdfBusy = false;
  bool vocabBusy = false;
  String? result;
  String lastSource = '';

  AppState get s => AppState.I;

  @override
  void dispose() {
    text.dispose();
    link.dispose();
    super.dispose();
  }

  String? _ytId(String u) {
    final m = RegExp(r'(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})').firstMatch(u);
    return m?.group(1);
  }

  Future<String> _transcript(String url) async {
    final id = _ytId(url);
    if (id == null) throw AiError(t('bad_link'));
    final yt = YoutubeExplode();
    try {
      final manifest = await yt.videos.closedCaptions.getManifest(id);
      if (manifest.tracks.isEmpty) throw AiError(t('no_captions'));
      final track = await yt.videos.closedCaptions.get(manifest.tracks.first);
      return track.captions.map((c) => c.text).join(' ');
    } finally {
      yt.close();
    }
  }

  Future<void> _pickPdf() async {
    setState(() => pdfBusy = true);
    try {
      final res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        withData: true,
      );
      if (res == null || res.files.isEmpty) return;
      final f = res.files.first;
      Uint8List? bytes = f.bytes;
      if (bytes == null && f.path != null) bytes = await File(f.path!).readAsBytes();
      if (bytes == null) throw AiError(t('pdf_fail'));
      final doc = PdfDocument(inputBytes: bytes);
      final extracted = PdfTextExtractor(doc).extractText();
      doc.dispose();
      if (extracted.trim().isEmpty) throw AiError(t('pdf_empty'));
      setState(() {
        pdfName = f.name;
        pdfText = extracted;
      });
    } catch (e) {
      if (mounted) toast(context, e is AiError ? e.msg : t('pdf_fail'));
    } finally {
      if (mounted) setState(() => pdfBusy = false);
    }
  }

  String get _outLangName {
    switch (outLang) {
      case 'ar':
        return 'Arabic';
      case 'en':
        return 'English';
      default:
        return 'the same language as the content';
    }
  }

  String get _outTts {
    switch (outLang) {
      case 'ar':
        return 'ar-SA';
      case 'en':
        return 'en-US';
      default:
        return s.frontLang;
    }
  }

  Future<void> _run() async {
    setState(() => busy = true);
    try {
      String source;
      if (mode == 0) {
        source = text.text.trim();
      } else if (mode == 1) {
        source = (await _transcript(link.text.trim())).trim();
      } else {
        source = pdfText.trim();
      }
      if (source.isEmpty) {
        if (mounted) toast(context, t('need_text'));
        return;
      }
      if (source.length > 14000 && mounted) toast(context, t('truncated'));
      final how = length == 'short'
          ? 'in 5 to 7 short bullet points'
          : length == 'long'
              ? 'as a detailed structured summary with headings, bullet points and key terms (about 500 words)'
              : 'as a structured summary with headings and bullet points (about 250 words)';
      final reply = await Ai.chat(
        'Summarize the following content $how. Write in $_outLangName. Use Markdown. '
        'Write any math using LaTeX: \$...\$ for inline and \$\$...\$\$ for display formulas.\n\n'
        'Content:\n${clip(source, 14000)}',
        system: 'You are an expert study assistant who writes clear, accurate summaries.',
        maxTokens: 1500,
        temp: 0.3,
      );
      lastSource = source;
      if (mounted) {
        setState(() => result = reply);
        Sfx.play('ok');
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _vocab() async {
    if (lastSource.isEmpty) return;
    setState(() => vocabBusy = true);
    try {
      final reply = await Ai.chat(
        'From the content below, pick the 10 most useful vocabulary words or key terms. '
        'Output exactly one per line in the form: term | translation to ${langOf(s.backLang).en}. '
        'Terms must be in ${langOf(s.frontLang).en}. No numbering, no other text.\n\n'
        'Content:\n${clip(lastSource, 8000)}',
        system: 'You are a precise bilingual dictionary.',
        maxTokens: 600,
        temp: 0.3,
      );
      final rows = parseCardLines(reply).where((r) => r[1].isNotEmpty).toList();
      for (final r in rows) {
        await s.addCard(CardItem(id: s.newId(), front: r[0], back: r[1]));
      }
      Sfx.play('win');
      if (mounted) toast(context, '${t('cards_added')}: ${rows.length}');
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => vocabBusy = false);
    }
  }

  void _quiz() {
    s.requestQuiz(clip(lastSource, 8000));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        PixelChips<int>(
          options: [(0, t('s_text')), (1, t('s_youtube')), (2, t('s_pdf'))],
          value: mode,
          onChanged: (v) => setState(() => mode = v),
        ),
        const SizedBox(height: 12),
        if (mode == 0)
          PixelField(
            controller: text,
            hint: t('s_text_hint'),
            minLines: 6,
            maxLines: 12,
            suffix: GestureDetector(
              onTap: () async {
                final d = await Clipboard.getData('text/plain');
                if (d?.text != null) setState(() => text.text = d!.text!);
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 6),
                child: Sprite('cards', px: 2.2),
              ),
            ),
          ),
        if (mode == 1) ...[
          PixelField(
            controller: link,
            hint: 'https://youtu.be/...',
            keyboard: TextInputType.url,
            dir: TextDirection.ltr,
          ),
          const SizedBox(height: 6),
          tx(t('yt_note'), size: 12, color: C.dark, height: 1.4),
        ],
        if (mode == 2) ...[
          PixelButton(
            label: pdfName.isEmpty ? t('pick_pdf') : pdfName,
            icon: 'summary',
            filled: false,
            expand: true,
            busy: pdfBusy,
            onTap: _pickPdf,
          ),
          if (pdfText.isNotEmpty) ...[
            const SizedBox(height: 6),
            tx('${t('chars')}: ${pdfText.length}', size: 12, color: C.dark),
          ],
        ],
        PixelTitle(t('length')),
        PixelChips<String>(
          options: [('short', t('l_short')), ('medium', t('l_medium')), ('long', t('l_long'))],
          value: length,
          onChanged: (v) => setState(() => length = v),
        ),
        PixelTitle(t('out_lang')),
        PixelChips<String>(
          options: [('ar', 'العربية'), ('en', 'English'), ('src', t('same_lang'))],
          value: outLang,
          onChanged: (v) => setState(() => outLang = v),
        ),
        const SizedBox(height: 16),
        PixelButton(
          label: t('summarize'),
          icon: 'sparkle',
          expand: true,
          busy: busy,
          onTap: _run,
        ),
        if (result != null) ...[
          const SizedBox(height: 16),
          PixelBox(
            padding: const EdgeInsets.all(14),
            child: SizedBox(
              width: double.infinity,
              child: Directionality(
                textDirection: outLang == 'en' ? TextDirection.ltr : (outLang == 'ar' ? TextDirection.rtl : Directionality.of(context)),
                child: RichMath(result!, size: 15),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: t('listen'),
                  icon: 'speaker',
                  small: true,
                  filled: false,
                  onTap: () => Speech.speak(result!, _outTts),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: PixelButton(
                  label: t('copy'),
                  small: true,
                  filled: false,
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: result!));
                    toast(context, t('copied'));
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          PixelButton(
            label: t('extract_vocab'),
            icon: 'cards',
            expand: true,
            filled: false,
            busy: vocabBusy,
            onTap: _vocab,
          ),
          const SizedBox(height: 10),
          PixelButton(label: t('make_quiz'), icon: 'quiz', expand: true, onTap: _quiz),
        ],
      ],
    );
  }
}
