import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'cards_tab.dart';
import 'rich.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'story_reader.dart';

class StoriesTab extends StatelessWidget {
  const StoriesTab({super.key});

  void _open(BuildContext context, StoryItem? st) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StoryEditor(story: st ?? StoryItem(id: AppState.I.newId(), lang: AppState.I.frontLang)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.I,
      builder: (context, _) {
        final list = AppState.I.stories;
        return ListView(
          padding: const EdgeInsets.all(14),
          children: [
            PixelButton(
              label: t('new_story'),
              icon: 'create',
              expand: true,
              onTap: () => _open(context, null),
            ),
            const SizedBox(height: 14),
            if (list.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 40),
                child: Column(
                  children: [
                    const Sprite('stories', px: 7),
                    const SizedBox(height: 14),
                    tx(t('no_stories'), size: 15, bold: true, align: TextAlign.center, height: 1.5),
                  ],
                ),
              ),
            for (final st in list)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    Sfx.play('tap');
                    _open(context, st);
                  },
                  child: PixelBox(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      children: [
                        if (st.image != null) ...[
                          cardImage(st.image, 58),
                          const SizedBox(width: 12),
                        ],
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              tx(st.title.isEmpty ? t('untitled') : st.title, size: 16, bold: true),
                              const SizedBox(height: 3),
                              Text(
                                st.body.replaceAll('\n', ' '),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 12.5, color: C.dark, height: 1.35),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class StoryEditor extends StatefulWidget {
  final StoryItem story;
  const StoryEditor({super.key, required this.story});
  @override
  State<StoryEditor> createState() => _StoryEditorState();
}

class _StoryEditorState extends State<StoryEditor> {
  late final TextEditingController title = TextEditingController(text: widget.story.title);
  late final TextEditingController body = TextEditingController(text: widget.story.body);
  final idea = TextEditingController();
  late String lang = widget.story.lang;
  String? busyAction;
  String? undo;
  bool deleted = false;
  bool reading = false;

  AppState get s => AppState.I;

  @override
  void dispose() {
    _commit();
    title.dispose();
    body.dispose();
    idea.dispose();
    super.dispose();
  }

  void _commit() {
    if (deleted) return;
    final tt = title.text.trim();
    final bb = body.text.trim();
    final exists = s.stories.any((x) => x.id == widget.story.id);
    if (tt.isEmpty && bb.isEmpty && !exists) return;
    widget.story
      ..title = tt
      ..body = body.text
      ..lang = lang;
    s.upsertStory(widget.story);
  }

  String get _langEn => langOf(lang).en;

  Future<void> _ai(String action) async {
    final b = body.text.trim();
    final hint = idea.text.trim();
    if ((action == 'continue' || action == 'improve' || action == 'grammar' || action == 'title' || action == 'translate' || action == 'cover') && b.isEmpty && title.text.trim().isEmpty) {
      toast(context, t('write_first'));
      return;
    }
    setState(() => busyAction = action);
    try {
      switch (action) {
        case 'write':
          {
            final r = await Ai.chat(
              'Write an original short story (about 200 words) in $_langEn. '
              '${hint.isEmpty ? 'Choose any creative idea.' : 'Idea: $hint.'} '
              'Output a short title on the first line starting with "# ", then the story.',
              system: 'You are a gifted storyteller.',
              maxTokens: 1000,
            );
            final p = splitTitle(r);
            undo = body.text;
            if (p.$1.isNotEmpty) title.text = p.$1;
            body.text = p.$2;
            break;
          }
        case 'continue':
          {
            final r = await Ai.chat(
              'Continue this story in $_langEn with the next 120 to 150 words, keeping the same style and characters. '
              '${hint.isEmpty ? '' : 'Direction: $hint. '}Output only the continuation.\n\nStory:\n${clip(b, 6000)}',
              system: 'You are a gifted storyteller.',
              maxTokens: 700,
            );
            undo = body.text;
            body.text = '${body.text.trimRight()}\n\n${r.trim()}';
            break;
          }
        case 'improve':
          {
            final r = await Ai.chat(
              'Rewrite this story in $_langEn with richer style and better flow, keeping the same plot. '
              'Output only the rewritten story.\n\n${clip(b, 6000)}',
              system: 'You are a skilled editor.',
              maxTokens: 1500,
            );
            undo = body.text;
            body.text = r.trim();
            break;
          }
        case 'grammar':
          {
            final r = await Ai.chat(
              'Fix spelling and grammar only, change nothing else. Output only the corrected text.\n\n${clip(b, 6000)}',
              system: 'You are a careful proofreader.',
              maxTokens: 1500,
              temp: 0.1,
            );
            undo = body.text;
            body.text = r.trim();
            break;
          }
        case 'title':
          {
            final r = await Ai.chat(
              'Suggest one short, catchy title in $_langEn for this story. Output only the title.\n\n${clip(b, 3000)}',
              maxTokens: 40,
              temp: 0.8,
            );
            title.text = r.replaceAll('"', '').replaceAll('#', '').replaceAll('*', '').trim();
            break;
          }
        case 'words':
          {
            if (s.scope.isEmpty) {
              toast(context, t('no_cards'));
              break;
            }
            final pool = List<CardItem>.of(s.scope)..shuffle();
            final words = pool.take(min(6, pool.length)).map((c) => c.front).join(', ');
            final r = await Ai.chat(
              'Write the next paragraph (about 100 words) of this story in $_langEn that naturally uses these words: $words. '
              'Output only the paragraph.\n\nStory so far:\n${clip(b, 4000)}',
              system: 'You are a creative storyteller for language learners.',
              maxTokens: 600,
            );
            undo = body.text;
            body.text = '${body.text.trimRight()}\n\n${r.trim()}';
            break;
          }
        case 'translate':
          {
            final r = await Ai.chat(
              'Translate this story to ${langOf(s.backLang).en}. Output only the translation.\n\n${clip(b, 6000)}',
              maxTokens: 1800,
              temp: 0.2,
            );
            if (mounted) _showText(t('translation'), r.trim(), s.backLang);
            break;
          }
        case 'cover':
          {
            final subject = clip('${title.text.trim()}. ${clip(b, 200)}', 240);
            final bytes = await Ai.image(
                'pixel art illustration, 16-bit retro game style, a scene from a story: $subject');
            widget.story.image = await s.saveImage('${widget.story.id}c', bytes);
            break;
          }
      }
      Sfx.play('ok');
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busyAction = null);
    }
  }

  void _showText(String heading, String content, String ttsLang) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: C.cream,
        insetPadding: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(side: BorderSide(color: C.ink, width: 3)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PixelTitle(heading),
              Flexible(
                child: SingleChildScrollView(
                  child: Directionality(
                    textDirection: ttsLang.startsWith('ar') ? TextDirection.rtl : TextDirection.ltr,
                    child: RichMath(content, size: 15),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  SpeakBtn(content, ttsLang),
                  const SizedBox(width: 8),
                  Expanded(
                    child: PixelButton(
                      label: t('copy'),
                      small: true,
                      filled: false,
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: content));
                        toast(context, t('copied'));
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _btn(String action, String icon, String label) {
    return PixelButton(
      label: label,
      icon: icon,
      small: true,
      filled: false,
      busy: busyAction == action,
      onTap: busyAction == null ? () => _ai(action) : null,
    );
  }

  Future<void> _delete() async {
    deleted = true;
    await s.deleteStory(widget.story);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final rtl = lang.startsWith('ar');
    return PixelPage(
      title: t('tab_stories'),
      actions: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _delete,
          child: const PixelBox(padding: EdgeInsets.all(8), child: Sprite('trash', px: 3)),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
        children: [
          if (widget.story.image != null)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: PixelBox(
                  padding: const EdgeInsets.all(4),
                  u: 2,
                  child: cardImage(widget.story.image, 180),
                ),
              ),
            ),
          PixelField(controller: title, hint: t('story_title')),
          const SizedBox(height: 10),
          PixelChips<String>(
            options: [
              for (final c in const ['en-US', 'ar-SA', 'fr-FR', 'de-DE', 'es-ES', 'tr-TR'])
                (c, langName(c)),
            ],
            value: lang,
            onChanged: (v) => setState(() => lang = v),
          ),
          const SizedBox(height: 10),
          PixelChips<bool>(
            options: [(false, t('edit')), (true, t('read_mode'))],
            value: reading,
            onChanged: (v) => setState(() => reading = v),
          ),
          const SizedBox(height: 8),
          if (reading)
            PixelBox(
              padding: const EdgeInsets.all(14),
              child: SizedBox(
                width: double.infinity,
                child: StoryReader(text: body.text, rtl: rtl),
              ),
            )
          else
            PixelField(
              controller: body,
              hint: t('story_body_hint'),
              minLines: 12,
              maxLines: 40,
              dir: rtl ? TextDirection.rtl : TextDirection.ltr,
            ),
          PixelTitle(t('ai_helper')),
          PixelField(controller: idea, hint: t('idea_hint')),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _btn('write', 'sparkle', t('a_write')),
              _btn('continue', 'create', t('a_continue')),
              _btn('words', 'cards', t('a_words')),
              _btn('improve', 'stories', t('a_improve')),
              _btn('grammar', 'check', t('a_grammar')),
              _btn('title', 'summary', t('a_title')),
              _btn('translate', 'games', t('a_translate')),
              _btn('cover', 'star', t('a_cover')),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: t('listen'),
                  icon: 'speaker',
                  filled: false,
                  onTap: () => Speech.speak(body.text, lang),
                ),
              ),
              const SizedBox(width: 10),
              if (undo != null)
                Expanded(
                  child: PixelButton(
                    label: t('undo'),
                    filled: false,
                    onTap: () => setState(() {
                      body.text = undo!;
                      undo = null;
                    }),
                  ),
                ),
              if (undo != null) const SizedBox(width: 10),
              Expanded(
                child: PixelButton(
                  label: t('save'),
                  icon: 'check',
                  onTap: () {
                    _commit();
                    toast(context, t('saved'));
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
