import 'dart:math';

import 'package:flutter/material.dart';

import 'card_detail.dart';
import 'common.dart';
import 'progress.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Extra statistics: retention, hardest cards, 7-day forecast, deck mastery.
class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('insights'),
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final cards = s.cards;
          int right = 0, wrong = 0;
          for (final c in cards) {
            right += c.right;
            wrong += c.wrong;
          }
          final ret = right + wrong == 0 ? 0.0 : right / (right + wrong);
          final now = DateTime.now();
          final today = DateTime(now.year, now.month, now.day);
          final forecast = List<int>.filled(7, 0);
          for (final c in cards) {
            if (c.isNew) continue;
            final d = DateTime.fromMillisecondsSinceEpoch(c.due);
            final day = DateTime(d.year, d.month, d.day).difference(today).inDays;
            final k = day < 0 ? 0 : day;
            if (k < 7) forecast[k]++;
          }
          final maxF = max(1, forecast.reduce(max));
          final hard = weakestCards(cards.where((c) => c.right + c.wrong > 0).toList(), 10);
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              PixelTitle(t('retention')),
              PixelBox(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    tx('${(ret * 100).round()}%', size: 26, bold: true),
                    const SizedBox(width: 14),
                    Expanded(child: PixelBar(value: ret, segs: 12)),
                  ],
                ),
              ),
              PixelTitle(t('forecast')),
              PixelBox(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    for (int i = 0; i < 7; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 56,
                              child: tx(
                                  i == 0
                                      ? t('today')
                                      : (i == 1 ? t('tomorrow') : '+$i ${t('u_d')}'),
                                  size: 12,
                                  bold: true,
                                  color: C.gray),
                            ),
                            Expanded(child: PixelBar(value: forecast[i] / maxF, segs: 14, height: 10)),
                            SizedBox(
                              width: 34,
                              child: tx('${forecast[i]}', size: 13, bold: true, align: TextAlign.end),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              PixelTitle(t('deck_mastery')),
              for (final d in s.decks)
                Builder(builder: (context) {
                  final list = cards.where((c) => c.deckId == d.id).toList();
                  if (list.isEmpty) return const SizedBox.shrink();
                  final m = list.where((c) => c.interval >= 21).length;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: PixelBox(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Expanded(child: tx(deckLabel(d), bold: true)),
                            tx('$m / ${list.length}', bold: true, color: C.gray, size: 13),
                          ]),
                          const SizedBox(height: 6),
                          PixelBar(value: m / list.length, segs: 12, height: 10),
                        ],
                      ),
                    ),
                  );
                }),
              PixelTitle(t('hardest')),
              if (hard.isEmpty) tx(t('no_data_yet'), color: C.gray, bold: true),
              for (final c in hard)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => showCardAi(context, c),
                    child: PixelBox(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        children: [
                          if (c.isLeech) ...[const Sprite('skull', px: 2.6), const SizedBox(width: 8)],
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                tx(c.front, size: 15, bold: true),
                                tx(c.back, size: 13, color: C.dark),
                              ],
                            ),
                          ),
                          tx('${c.wrong}✗ ${c.right}✓', size: 12.5, bold: true, color: C.gray),
                          const SizedBox(width: 8),
                          const Sprite('sparkle', px: 2.4),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
