import 'package:speech_to_text/speech_to_text.dart';

import 'services.dart';

/// Thin wrapper over speech_to_text.
class Stt {
  static final SpeechToText _s = SpeechToText();
  static bool _ready = false;

  static bool get listening => _s.isListening;

  static Future<bool> init() async {
    if (_ready) return true;
    try {
      _ready = await _s.initialize();
    } catch (_) {
      _ready = false;
    }
    return _ready;
  }

  /// Starts listening in [lang] (e.g. en-US). Returns false when unavailable.
  static Future<bool> start(String lang, void Function(String text, bool done) onResult) async {
    if (!await init()) return false;
    await Speech.stop();
    try {
      await _s.listen(
        onResult: (r) => onResult(r.recognizedWords, r.finalResult),
        localeId: lang.replaceAll('-', '_'),
        listenFor: const Duration(seconds: 25),
        pauseFor: const Duration(seconds: 3),
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> stop() async {
    try {
      await _s.stop();
    } catch (_) {}
  }
}
