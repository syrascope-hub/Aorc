import 'dart:math';

import 'package:flutter/material.dart';

import 'home.dart';
import 'onboarding.dart';
import 'state.dart';
import 'services.dart';
import 'strings.dart';
import 'theme.dart';

/// Animated pixel splash. Plays on every launch, then wipes into the app with blocks.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _CheckerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const cell = 28.0;
    final p = Paint()
      ..color = C.creamDeep
      ..isAntiAlias = false;
    for (int y = 0; y * cell < size.height; y++) {
      for (int x = 0; x * cell < size.width; x++) {
        if ((x + y).isEven) canvas.drawRect(Rect.fromLTWH(x * cell, y * cell, cell, cell), p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3600));
  late final AnimationController _w =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
  late final List<Point<int>> _order;
  static const String _logo = 'AORC AI';
  static const List<Offset> _stars = [
    Offset(0.12, 0.14),
    Offset(0.86, 0.2),
    Offset(0.18, 0.82),
    Offset(0.82, 0.76),
    Offset(0.5, 0.07),
    Offset(0.07, 0.5),
    Offset(0.93, 0.5),
  ];

  @override
  void initState() {
    super.initState();
    final rows = kSprites['robot']!;
    final cells = <Point<int>>[];
    for (int y = 0; y < rows.length; y++) {
      for (int x = 0; x < rows[y].length; x++) {
        if (rows[y][x] != '.') cells.add(Point(x, y));
      }
    }
    cells.shuffle(Random(5));
    _order = cells;
    Sfx.play('start');
    _c.forward().then((_) {
      if (!mounted) return;
      _w.forward().then((_) {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            transitionDuration: Duration.zero,
            pageBuilder: (_, __, ___) =>
                AppState.I.onboarded ? const HomeShell(reveal: true) : const OnboardingScreen(),
          ),
        );
      });
    });
  }

  @override
  void dispose() {
    _c.dispose();
    _w.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const px = 9.0;
    final rows = kSprites['robot']!;
    return Scaffold(
      backgroundColor: C.cream,
      body: AnimatedBuilder(
        animation: Listenable.merge([_c, _w]),
        builder: (context, _) {
          final v = _c.value;
          final f = (v / 0.5).clamp(0.0, 1.0);
          final shown = (_order.length * f).floor();
          final hop = (v > 0.5 && (v * 10).floor() % 2 == 0) ? -6.0 : 0.0;
          final letters = ((v - 0.35) / 0.35 * _logo.length).clamp(0.0, _logo.length.toDouble()).floor();
          final blocks = (v * 12).floor();
          return Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: _CheckerPainter())),
              for (int i = 0; i < _stars.length; i++)
                if (((v * 8).floor() + i) % 3 != 0)
                  Align(
                    alignment: Alignment(_stars[i].dx * 2 - 1, _stars[i].dy * 2 - 1),
                    child: const Sprite('star', px: 3),
                  ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Transform.translate(
                      offset: Offset(0, hop),
                      child: SizedBox(
                        width: rows[0].length * px,
                        height: rows.length * px,
                        child: CustomPaint(
                          painter: SpritePainter(rows, px, order: _order, limit: shown),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    PixelFont(
                      _logo.substring(0, letters),
                      scale: 6,
                      reserve: true,
                      reserveLen: _logo.length,
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      height: 22,
                      child: v > 0.75 ? tx(t('splash_sub'), size: 15, bold: true, color: C.dark) : null,
                    ),
                    const SizedBox(height: 34),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        for (int i = 0; i < 12; i++)
                          Container(
                            width: 14,
                            height: 14,
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            color: i < blocks ? C.ink : C.light,
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(painter: WipePainter(_w.value, C.ink, 9)),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
