import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Lets the user choose a picture from the gallery (optional, null when cancelled).
/// The picture is scaled down so cards stay light.
Future<Uint8List?> pickGalleryImage(BuildContext context) async {
  try {
    final x = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 85,
    );
    if (x == null) return null;
    return await x.readAsBytes();
  } catch (_) {
    if (context.mounted) toast(context, t('photo_failed'));
    return null;
  }
}

/// Big tappable row used by the games list and the "more" hub.
Widget menuTile(String icon, String title, String desc, VoidCallback onTap, {String? badge}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Sfx.play('tap');
        onTap();
      },
      child: PixelBox(
        padding: EdgeInsets.all(12 + 3 * (AppState.I.btnScale - 1) * 2),
        child: Row(
          children: [
            PixelBox(
              color: C.cream,
              u: 2,
              shadow: false,
              padding: const EdgeInsets.all(8),
              child: Sprite(icon, px: 3.6 * AppState.I.btnScale),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  tx(title, size: 15.5 + 2.5 * (AppState.I.btnScale - 1) * 2, bold: true),
                  const SizedBox(height: 3),
                  tx(desc, size: 12.5, color: C.dark, height: 1.35),
                ],
              ),
            ),
            if (badge != null)
              PixelBox(
                u: 2,
                shadow: false,
                color: C.ink,
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                child: Text(badge,
                    style: TextStyle(
                        color: C.cream, fontSize: 11.5, fontWeight: FontWeight.w900)),
              ),
          ],
        ),
      ),
    ),
  );
}

Future<bool> confirmDialog(BuildContext context, String msg) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: C.cream,
      shape: RoundedRectangleBorder(side: BorderSide(color: C.ink, width: 3)),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            tx(msg, size: 16, bold: true, align: TextAlign.center, height: 1.4),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: t('cancel'),
                    filled: false,
                    onTap: () => Navigator.pop(ctx, false),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PixelButton(label: t('ok'), onTap: () => Navigator.pop(ctx, true)),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
  return ok == true;
}

/// Shows a toast and returns false when the user has fewer than [n] cards.
bool needCards(BuildContext context, int n, {List<CardItem>? pool}) {
  final have = (pool ?? AppState.I.scope).length;
  if (have < n) {
    toast(context, '${t('need_cards_n')} $n (${t('you_have')} $have)');
    return false;
  }
  return true;
}

Future<T?> pushPage<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute(builder: (_) => page));

// ───────────────────────── text similarity ─────────────────────────

String normText(String s) => s
    .toLowerCase()
    .replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), '')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();

int levenshtein(String a, String b) {
  if (a == b) return 0;
  if (a.isEmpty) return b.length;
  if (b.isEmpty) return a.length;
  var prev = List<int>.generate(b.length + 1, (i) => i);
  for (int i = 1; i <= a.length; i++) {
    final cur = List<int>.filled(b.length + 1, 0);
    cur[0] = i;
    for (int j = 1; j <= b.length; j++) {
      final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
      cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
    }
    prev = cur;
  }
  return prev[b.length];
}

/// 0..1 similarity of two strings after normalisation.
double similarity(String a, String b) {
  final x = normText(a);
  final y = normText(b);
  if (x.isEmpty && y.isEmpty) return 1;
  final m = max(x.length, y.length);
  if (m == 0) return 1;
  return 1 - levenshtein(x, y) / m;
}

// ───────────────────────── card helpers ─────────────────────────

/// Cards the learner struggles with most (highest error ratio first).
List<CardItem> weakestCards(List<CardItem> pool, int n) {
  final list = List<CardItem>.of(pool);
  double score(CardItem c) {
    final tot = c.right + c.wrong;
    final ratio = tot == 0 ? 0.35 : c.wrong / tot;
    return ratio + (c.isDue ? 0.2 : 0) + (c.isLeech ? 0.3 : 0);
  }

  list.sort((a, b) => score(b).compareTo(score(a)));
  return list.take(n).toList();
}

List<CardItem> randomCards(List<CardItem> pool, int n) {
  final list = List<CardItem>.of(pool)..shuffle();
  return list.take(n).toList();
}

String deckLabel(Deck d) => d.id == 'default' && d.name.isEmpty ? t('deck_default') : d.name;

Widget pixelCheck(bool on, String label, VoidCallback onTap) {
  return GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onTap,
    child: Row(
      children: [
        PixelBox(
          u: 2,
          shadow: false,
          color: on ? C.ink : C.white,
          padding: const EdgeInsets.all(5),
          child: SizedBox(
            width: 10,
            height: 10,
            child: on ? Sprite('check', px: 1.6, tint: C.cream) : null,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(child: tx(label, size: 13.5)),
      ],
    ),
  );
}

/// Small coin counter chip.
Widget coinChip() {
  return ListenableBuilder(
    listenable: AppState.I,
    builder: (context, _) => PixelBox(
      u: 2,
      shadow: false,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Sprite('coin', px: 2),
          const SizedBox(width: 5),
          tx('${AppState.I.coins}', bold: true, size: 13),
        ],
      ),
    ),
  );
}

Widget infoBox(String text) => PixelBox(
      color: C.creamDeep,
      child: SizedBox(width: double.infinity, child: tx(text, size: 13, height: 1.45)),
    );

/// Shows a dialog with scrollable [child] and a close button.
Future<void> showPixelDialog(BuildContext context, String title, Widget child) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: C.cream,
      insetPadding: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(side: BorderSide(color: C.ink, width: 3)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PixelTitle(title),
            Flexible(child: SingleChildScrollView(child: child)),
            const SizedBox(height: 12),
            PixelButton(
              label: t('close'),
              filled: false,
              expand: true,
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    ),
  );
}
