import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'common.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Daily review reminder.
class Notifier {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    if (_ready) return;
    try {
      tzdata.initializeTimeZones();
      try {
        final name = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(name));
      } catch (_) {}
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _p.initialize(const InitializationSettings(android: android));
      _ready = true;
    } catch (_) {}
  }

  static Future<bool> requestPermission() async {
    await init();
    try {
      final impl = _p.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final ok = await impl?.requestNotificationsPermission();
      return ok ?? true;
    } catch (_) {
      return false;
    }
  }

  /// Schedules (or cancels) the daily reminder from the saved settings.
  static Future<void> apply() async {
    await init();
    if (!_ready) return;
    final s = AppState.I;
    try {
      await _p.cancel(1);
      if (!s.reminderOn) return;
      final now = tz.TZDateTime.now(tz.local);
      var when = tz.TZDateTime(tz.local, now.year, now.month, now.day, s.reminderHour, s.reminderMin);
      if (!when.isAfter(now)) when = when.add(const Duration(days: 1));
      await _p.zonedSchedule(
        1,
        t('app_name'),
        t('reminder_body'),
        when,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'daily_review',
            'Daily review',
            channelDescription: 'Daily flashcard review reminder',
            importance: Importance.high,
            priority: Priority.high,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    } catch (_) {}
  }
}

class ReminderScreen extends StatefulWidget {
  const ReminderScreen({super.key});
  @override
  State<ReminderScreen> createState() => _ReminderScreenState();
}

class _ReminderScreenState extends State<ReminderScreen> {
  AppState get s => AppState.I;

  String get _time =>
      '${s.reminderHour.toString().padLeft(2, '0')}:${s.reminderMin.toString().padLeft(2, '0')}';

  Future<void> _toggle(bool v) async {
    if (v) {
      final ok = await Notifier.requestPermission();
      if (!ok) {
        if (mounted) toast(context, t('notif_denied'));
        return;
      }
    }
    s.reminderOn = v;
    await s.saveSettings();
    await Notifier.apply();
    if (mounted) setState(() {});
  }

  Future<void> _pick() async {
    final r = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: s.reminderHour, minute: s.reminderMin),
    );
    if (r == null) return;
    s.reminderHour = r.hour;
    s.reminderMin = r.minute;
    await s.saveSettings();
    await Notifier.apply();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('reminder'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('reminder_help')),
          PixelTitle(t('reminder')),
          PixelChips<bool>(
            options: [(true, t('on')), (false, t('off'))],
            value: s.reminderOn,
            onChanged: _toggle,
          ),
          if (s.reminderOn) ...[
            PixelTitle(t('reminder_time')),
            Row(
              children: [
                PixelBox(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  child: tx(_time, size: 24, bold: true),
                ),
                const SizedBox(width: 12),
                PixelButton(label: t('change'), icon: 'timer', filled: false, onTap: _pick),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
