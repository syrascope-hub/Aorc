import 'package:flutter/material.dart';
import 'package:flutter_math_fork/flutter_math.dart';

import 'theme.dart';

final RegExp _mathRe = RegExp(
  r'\$\$(.+?)\$\$|\$([^\$\n]+?)\$|\\\((.+?)\\\)|\\\[(.+?)\\\]',
  dotAll: true,
);

/// Light Markdown (headings, bullets, **bold**) + LaTeX ($..$, $$..$$, \(..\), \[..\]).
class RichMath extends StatelessWidget {
  final String text;
  final double size;
  final Color? color;
  final TextAlign? align;
  const RichMath(this.text, {super.key, this.size = 15, this.color, this.align});

  @override
  Widget build(BuildContext context) {
    // Join multi-line display math into one line so the line-based pass keeps it intact.
    final src = text.replaceAllMapped(
      RegExp(r'\$\$(.+?)\$\$', dotAll: true),
      (m) => '\$\$${m.group(1)!.replaceAll('\n', ' ')}\$\$',
    );
    final children = <Widget>[];
    for (final raw in src.split('\n')) {
      var line = raw.trimRight();
      if (line.trim().isEmpty) {
        children.add(const SizedBox(height: 6));
        continue;
      }
      double sz = size;
      bool bold = false;
      String prefix = '';
      final h = RegExp(r'^\s{0,3}(#{1,4})\s+(.*)$').firstMatch(line);
      if (h != null) {
        line = h.group(2)!;
        bold = true;
        sz = size + 4 - (h.group(1)!.length - 1);
      } else {
        final b = RegExp(r'^\s*[-*•]\s+(.*)$').firstMatch(line);
        if (b != null) {
          line = b.group(1)!;
          prefix = '• ';
        } else {
          final n = RegExp(r'^\s*(\d+)[.)]\s+(.*)$').firstMatch(line);
          if (n != null) {
            prefix = '${n.group(1)}. ';
            line = n.group(2)!;
          }
        }
      }
      final style = TextStyle(
        fontSize: sz,
        color: color ?? C.ink,
        height: 1.5,
        fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
      );
      children.add(
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Text.rich(
            TextSpan(
              style: style,
              children: [
                if (prefix.isNotEmpty)
                  TextSpan(text: prefix, style: const TextStyle(fontWeight: FontWeight.w900)),
                ..._inline(line, style),
              ],
            ),
            textAlign: align,
          ),
        ),
      );
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }
}

List<InlineSpan> _inline(String s, TextStyle style) {
  final out = <InlineSpan>[];
  int pos = 0;
  for (final m in _mathRe.allMatches(s)) {
    if (m.start > pos) out.addAll(_bold(s.substring(pos, m.start)));
    final tex = (m.group(1) ?? m.group(2) ?? m.group(3) ?? m.group(4) ?? '').trim();
    final display = m.group(1) != null || m.group(4) != null;
    out.add(
      WidgetSpan(
        alignment: PlaceholderAlignment.middle,
        child: Math.tex(
          tex,
          textStyle: style,
          mathStyle: display ? MathStyle.display : MathStyle.text,
          onErrorFallback: (e) => Text(tex, style: style),
        ),
      ),
    );
    pos = m.end;
  }
  if (pos < s.length) out.addAll(_bold(s.substring(pos)));
  return out;
}

List<InlineSpan> _bold(String s) {
  final parts = s.split('**');
  final out = <InlineSpan>[];
  for (int i = 0; i < parts.length; i++) {
    if (parts[i].isEmpty) continue;
    out.add(TextSpan(
      text: parts[i],
      style: i.isOdd ? const TextStyle(fontWeight: FontWeight.w900) : null,
    ));
  }
  return out;
}
