import 'package:flutter/material.dart';

import 'home.dart';
import 'piper.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// First-run setup: languages, voice type, offline neural voice.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  AppState get s => AppState.I;
  int step = 0;
  double? prog;
  String phase = 'download';
  String? err;

  @override
  void initState() {
    super.initState();
    Speech.init();
  }

  @override
  void dispose() {
    Speech.stop();
    super.dispose();
  }

  Future<void> _finish() async {
    s.onboarded = true;
    await s.saveSettings();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        transitionDuration: Duration.zero,
        pageBuilder: (_, __, ___) => const HomeShell(reveal: true),
      ),
    );
  }

  PiperVoice? _voice() {
    final list = Piper.forLang(s.frontLang.split('-').first);
    if (list.isEmpty) return null;
    for (final v in list) {
      if (v.gender == s.voiceGender) return v;
    }
    return list.first;
  }

  Future<void> _download(PiperVoice v) async {
    setState(() {
      prog = 0;
      phase = 'download';
      err = null;
    });
    try {
      await Piper.download(v, (p, ph) {
        if (mounted) {
          setState(() {
            prog = p;
            phase = ph;
          });
        }
      });
    } catch (e) {
      final m = e.toString();
      err = m.length > 140 ? m.substring(0, 140) : m;
    }
    Speech.invalidate();
    if (mounted) setState(() => prog = null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.cream,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
              child: Row(
                children: [
                  for (int i = 0; i < 3; i++)
                    Expanded(
                      child: Container(
                        height: 10,
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        decoration: BoxDecoration(
                          color: i <= step ? C.ink : C.white,
                          border: Border.all(color: C.ink, width: 2),
                        ),
                      ),
                    ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _finish,
                    child: tx(t('onb_skip'), bold: true, size: 13, color: C.gray),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  tx(t('onb_welcome'), bold: true, size: 22),
                  const SizedBox(height: 6),
                  if (step == 0) ..._langs(),
                  if (step == 1) ..._voiceType(),
                  if (step == 2) ..._offline(),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  if (step > 0) ...[
                    Expanded(
                      child: PixelButton(
                        label: t('back'),
                        filled: false,
                        onTap: () => setState(() => step--),
                      ),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    child: PixelButton(
                      label: step == 2 ? t('onb_start') : t('next'),
                      onTap: prog != null
                          ? null
                          : () {
                              if (step == 2) {
                                _finish();
                              } else {
                                setState(() => step++);
                              }
                            },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _langs() {
    List<(String, String)> opts() => [for (final l in kLangs) (l.code, langName(l.code))];
    return [
      PixelTitle(t('onb_ui')),
      PixelChips<String>(
        options: const [('ar', 'العربية'), ('en', 'English')],
        value: s.uiLang,
        onChanged: (v) {
          s.uiLang = v;
          s.saveSettings();
          setState(() {});
        },
      ),
      PixelTitle(t('onb_learn')),
      PixelChips<String>(
        options: opts(),
        value: s.frontLang,
        onChanged: (v) {
          s.frontLang = v;
          s.saveSettings();
          Speech.invalidate();
          setState(() {});
        },
      ),
      PixelTitle(t('onb_trans')),
      PixelChips<String>(
        options: opts(),
        value: s.backLang,
        onChanged: (v) {
          s.backLang = v;
          s.saveSettings();
          Speech.invalidate();
          setState(() {});
        },
      ),
    ];
  }

  List<Widget> _voiceType() {
    return [
      PixelTitle(t('voice_gender')),
      PixelChips<String>(
        options: [('f', t('voice_female')), ('m', t('voice_male'))],
        value: s.voiceGender,
        onChanged: (v) {
          setState(() => s.voiceGender = v);
          s.saveSettings();
          Speech.invalidate();
          Speech.speak(Speech.samplePhrase(s.frontLang), s.frontLang);
        },
      ),
      const SizedBox(height: 12),
      PixelButton(
        label: langName(s.frontLang),
        icon: 'speaker',
        expand: true,
        filled: false,
        onTap: () => Speech.speak(Speech.samplePhrase(s.frontLang), s.frontLang),
      ),
      const SizedBox(height: 8),
      tx(t('voice_gender_note'), size: 12, color: C.dark, height: 1.4),
    ];
  }

  List<Widget> _offline() {
    final v = _voice();
    return [
      PixelTitle(t('onb_offline')),
      tx(t('onb_offline_sub'), size: 13, color: C.dark, height: 1.45),
      const SizedBox(height: 12),
      if (v == null)
        tx(t('voice_no_piper'), size: 13, color: C.dark)
      else
        PixelBox(
          child: SizedBox(
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Expanded(
                    child: tx('${v.name} · ${v.gender == 'f' ? t('voice_female') : t('voice_male')}',
                        bold: true),
                  ),
                  tx(Piper.installed(v) ? t('voice_installed') : '~${v.mb} ${t('voice_mb')}',
                      size: 12, color: C.gray),
                ]),
                const SizedBox(height: 10),
                if (prog != null) ...[
                  PixelBar(value: prog!, segs: 14, height: 10),
                  const SizedBox(height: 4),
                  tx(t('voice_phase_$phase'), size: 12, color: C.gray),
                ] else if (Piper.installed(v))
                  PixelButton(
                    label: t('voice_try'),
                    small: true,
                    onTap: () => Speech.testVoice(v),
                  )
                else
                  PixelButton(
                    label: t('voice_download'),
                    small: true,
                    onTap: () => _download(v),
                  ),
                if (err != null) ...[
                  const SizedBox(height: 6),
                  tx(err!, size: 12, color: C.dark),
                ],
              ],
            ),
          ),
        ),
    ];
  }
}
