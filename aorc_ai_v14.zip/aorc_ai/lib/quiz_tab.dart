import 'package:flutter/material.dart';

import 'rich.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class _Q {
  final String q;
  final List<String> options;
  final String correct;
  final String expl;
  String? picked;
  _Q(this.q, this.options, this.correct, this.expl);
}

class QuizTab extends StatefulWidget {
  const QuizTab({super.key});
  @override
  State<QuizTab> createState() => _QuizTabState();
}

class _QuizTabState extends State<QuizTab> {
  int phase = 0; // 0 setup, 1 running, 2 results
  int source = 0; // 0 cards, 1 text/topic
  int count = 10;
  String level = 'medium';
  String lang = 'src';
  final text = TextEditingController();
  bool busy = false;
  List<_Q> qs = [];
  int i = 0;
  String quizTitle = '';

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    s.addListener(_onState);
  }

  @override
  void dispose() {
    s.removeListener(_onState);
    text.dispose();
    super.dispose();
  }

  void _onState() {
    final p = s.pendingQuizText;
    if (p != null) {
      s.pendingQuizText = null;
      if (mounted) {
        setState(() {
          text.text = p;
          source = 1;
          phase = 0;
        });
      }
    }
  }

  String get _langName {
    switch (lang) {
      case 'ar':
        return 'Arabic';
      case 'en':
        return 'English';
      default:
        return source == 0 ? langOf(s.frontLang).en : 'the same language as the content';
    }
  }

  Future<void> _generate() async {
    String content;
    String extra;
    if (source == 0) {
      if (s.scope.length < 4) {
        toast(context, '${t('need_cards_n')} 4 (${t('you_have')} ${s.scope.length})');
        return;
      }
      final pick = (List<CardItem>.of(s.scope)..shuffle()).take(30);
      content = 'Vocabulary list (word = meaning):\n${pick.map((c) => '${c.front} = ${c.back}').join('\n')}';
      extra = 'Make the questions varied: meaning, correct usage in a sentence, fill in the blank, odd one out.';
      quizTitle = t('tab_cards');
    } else {
      content = text.text.trim();
      if (content.isEmpty) {
        toast(context, t('need_text'));
        return;
      }
      extra = 'If the content is only a short topic, base the questions on general knowledge of that topic.';
      quizTitle = clip(content.replaceAll('\n', ' '), 28);
    }
    setState(() => busy = true);
    try {
      final reply = await Ai.chat(
        'Create a multiple-choice quiz of $count questions ($level difficulty) based on the content below. '
        'Write the questions in $_langName. $extra '
        'Return ONLY a JSON array. Each item: {"q": "question", "options": ["a","b","c","d"], '
        '"answer": 0, "explanation": "one short sentence"} where "answer" is the 0-based index of the correct option. '
        'Exactly 4 options per question. For math use LaTeX with \$...\$ and escape backslashes for JSON.\n\n'
        'Content:\n${clip(content, 9000)}',
        system: 'You are an exam writer. Output valid JSON only.',
        maxTokens: 2800,
        temp: 0.5,
      );
      final list = Ai.jsonList(reply);
      final out = <_Q>[];
      for (final e in list) {
        try {
          final m = Map<String, dynamic>.from(e as Map);
          final opts = (m['options'] as List).map((x) => x.toString()).toList();
          final raw = m['answer'];
          final ai = raw is int ? raw : int.parse(raw.toString());
          if (opts.length < 2 || ai < 0 || ai >= opts.length) continue;
          final correct = opts[ai];
          opts.shuffle();
          out.add(_Q(m['q'].toString(), opts, correct, (m['explanation'] ?? '').toString()));
        } catch (_) {}
      }
      if (out.isEmpty) throw AiError(t('bad_ai_format'));
      if (mounted) {
        setState(() {
          qs = out;
          i = 0;
          phase = 1;
        });
        Sfx.play('start');
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _pick(String o) {
    final q = qs[i];
    if (q.picked != null) return;
    setState(() => q.picked = o);
    Sfx.play(o == q.correct ? 'ok' : 'bad');
  }

  Future<void> _next() async {
    if (i + 1 >= qs.length) {
      final score = qs.where((q) => q.picked == q.correct).length;
      s.quizHistory.insert(0, {
        'title': quizTitle,
        'score': score,
        'total': qs.length,
        'date': DateTime.now().millisecondsSinceEpoch,
      });
      if (s.quizHistory.length > 20) s.quizHistory = s.quizHistory.sublist(0, 20);
      await s.saveQuizHistory();
      Sfx.play('win');
      if (mounted) setState(() => phase = 2);
    } else {
      setState(() => i++);
    }
  }

  @override
  Widget build(BuildContext context) {
    switch (phase) {
      case 1:
        return _running();
      case 2:
        return _results();
      default:
        return _setup();
    }
  }

  // ───────────── setup ─────────────

  Widget _setup() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        PixelTitle(t('quiz_from')),
        PixelChips<int>(
          options: [(0, t('tab_cards')), (1, t('text_topic'))],
          value: source,
          onChanged: (v) => setState(() => source = v),
        ),
        if (source == 1) ...[
          const SizedBox(height: 10),
          PixelField(controller: text, hint: t('quiz_text_hint'), minLines: 5, maxLines: 10),
        ],
        PixelTitle(t('questions')),
        PixelChips<int>(
          options: const [(5, '5'), (10, '10'), (15, '15')],
          value: count,
          onChanged: (v) => setState(() => count = v),
        ),
        PixelTitle(t('difficulty')),
        PixelChips<String>(
          options: [('easy', t('easy')), ('medium', t('medium')), ('hard', t('hard'))],
          value: level,
          onChanged: (v) => setState(() => level = v),
        ),
        PixelTitle(t('quiz_lang')),
        PixelChips<String>(
          options: [('src', t('same_lang')), ('ar', 'العربية'), ('en', 'English')],
          value: lang,
          onChanged: (v) => setState(() => lang = v),
        ),
        const SizedBox(height: 16),
        PixelButton(
          label: t('make_quiz'),
          icon: 'quiz',
          expand: true,
          busy: busy,
          onTap: _generate,
        ),
        if (s.quizHistory.isNotEmpty) ...[
          PixelTitle(t('history')),
          for (final h in s.quizHistory.take(6))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: PixelBox(
                u: 2,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Expanded(child: tx('${h['title']}', size: 13, bold: true)),
                    const Sprite('star', px: 2),
                    const SizedBox(width: 4),
                    tx('${h['score']} / ${h['total']}', size: 13, bold: true),
                  ],
                ),
              ),
            ),
        ],
      ],
    );
  }

  // ───────────── running ─────────────

  Widget _running() {
    final q = qs[i];
    final answered = q.picked != null;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            tx('${i + 1} / ${qs.length}', bold: true, color: C.gray),
            const Spacer(),
            PixelButton(
              label: t('quit'),
              small: true,
              filled: false,
              onTap: () => setState(() => phase = 0),
            ),
          ],
        ),
        const SizedBox(height: 12),
        PixelBox(
          padding: const EdgeInsets.all(16),
          child: SizedBox(width: double.infinity, child: RichMath(q.q, size: 18)),
        ),
        const SizedBox(height: 14),
        for (final o in q.options)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _optionBox(q, o),
          ),
        if (answered) ...[
          if (q.expl.isNotEmpty)
            PixelBox(
              color: C.creamDeep,
              padding: const EdgeInsets.all(12),
              child: SizedBox(width: double.infinity, child: RichMath(q.expl, size: 14)),
            ),
          const SizedBox(height: 12),
          PixelButton(
            label: i + 1 >= qs.length ? t('finish') : t('next'),
            expand: true,
            onTap: _next,
          ),
        ],
      ],
    );
  }

  Widget _optionBox(_Q q, String o) {
    Color bg = C.white;
    Color fg = C.ink;
    String mark = '';
    if (q.picked != null) {
      if (o == q.correct) {
        bg = C.ink;
        fg = C.cream;
        mark = '✔ ';
      } else if (o == q.picked) {
        bg = C.light;
        fg = C.dark;
        mark = '✖ ';
      }
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _pick(o),
      child: SizedBox(
        width: double.infinity,
        child: PixelBox(
          color: bg,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              if (mark.isNotEmpty) tx(mark, size: 16, bold: true, color: fg),
              Expanded(child: RichMath(o, size: 16, color: fg)),
            ],
          ),
        ),
      ),
    );
  }

  // ───────────── results ─────────────

  Widget _results() {
    final score = qs.where((q) => q.picked == q.correct).length;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const SizedBox(height: 8),
        const Center(child: Sprite('robot', px: 7)),
        const SizedBox(height: 14),
        Center(child: tx('${t('score')}: $score / ${qs.length}', size: 22, bold: true)),
        const SizedBox(height: 16),
        PixelTitle(t('review')),
        for (int k = 0; k < qs.length; k++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: PixelBox(
              u: 2,
              color: qs[k].picked == qs[k].correct ? C.white : C.light,
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichMath('${k + 1}. ${qs[k].q}', size: 14),
                    const SizedBox(height: 6),
                    RichMath('✔ ${qs[k].correct}', size: 14),
                    if (qs[k].picked != qs[k].correct)
                      RichMath('✖ ${qs[k].picked ?? '-'}', size: 14, color: C.dark),
                  ],
                ),
              ),
            ),
          ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: PixelButton(
                label: t('new_quiz'),
                filled: false,
                onTap: () => setState(() => phase = 0),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PixelButton(
                label: t('retry'),
                onTap: () => setState(() {
                  for (final q in qs) {
                    q.picked = null;
                    q.options.shuffle();
                  }
                  i = 0;
                  phase = 1;
                }),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
