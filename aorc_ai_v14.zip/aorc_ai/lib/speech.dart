import 'dart:async';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'piper.dart';
import 'state.dart';
import 'strings.dart';
import 'tts_engines.dart';

/// Lets the speech engine show a message from anywhere (set in main.dart).
final GlobalKey<ScaffoldMessengerState> rootMessenger = GlobalKey<ScaffoldMessengerState>();

class _Clip {
  final Uint8List bytes;
  final String mime;
  const _Clip(this.bytes, this.mime);
}

class VoiceResult {
  final bool ok;
  final String detail;
  const VoiceResult(this.ok, this.detail);
}

/// Speech with a guaranteed fallback chain:
///   chosen engine -> then kTtsChain (tts_engines.dart): Piper (offline neural)
///   -> device voice. The device voice itself rotates through every installed
///   Android speech engine (Google, Samsung, ...) until one speaks.
/// Every failure is recorded in [errors] so the voice test screen can show why.
class Speech {
  static final FlutterTts _tts = FlutterTts();
  static AudioPlayer? _online;

  static final Map<String, _Clip> _cache = {};
  static final List<String> _order = [];

  /// Last error per engine: system, piper.
  static final Map<String, String> errors = {};
  static String? lastEngine;
  static final ValueNotifier<String?> engineUsed = ValueNotifier<String?>(null);

  static bool _ready = false;
  static bool _sysSpeaking = false;
  static String? _lang;
  static String? _voiceKey;
  static double? _rate;
  static int _gen = 0;
  static Completer<bool>? _startW;
  static Completer<void>? _doneW;
  static String _curEngine = ''; // engine package currently set on flutter_tts ('' = phone default)
  static String? _goodEngine; // last engine that really spoke
  static DateTime _sysBadUntil = DateTime.fromMillisecondsSinceEpoch(0);
  static DateTime _lastNotice = DateTime.fromMillisecondsSinceEpoch(0);

  static void _ok(Completer<bool>? c, bool v) {
    if (c != null && !c.isCompleted) c.complete(v);
  }

  static void _fin(Completer<void>? c) {
    if (c != null && !c.isCompleted) c.complete();
  }

  static String _key(String engine) => ttsErrorKey(engine);

  static String _short(Object e) {
    final s = e.toString();
    return s.length > 160 ? s.substring(0, 160) : s;
  }

  static Future<void> init() async {
    if (_ready) return;
    _ready = true;
    try {
      _tts.setStartHandler(() {
        _sysSpeaking = true;
        _ok(_startW, true);
      });
      _tts.setCompletionHandler(() {
        _sysSpeaking = false;
        _fin(_doneW);
      });
      _tts.setCancelHandler(() {
        _sysSpeaking = false;
        _fin(_doneW);
      });
      _tts.setErrorHandler((m) {
        _sysSpeaking = false;
        errors['system'] = _short(m);
        _ok(_startW, false);
        _fin(_doneW);
      });
      await _tts.awaitSpeakCompletion(false);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
    } catch (e) {
      errors['system'] = _short(e);
    }
    try {
      await _tts.setQueueMode(0);
    } catch (_) {}
    final eng = AppState.I.sysEngine;
    if (eng.isNotEmpty) {
      try {
        await _tts.setEngine(eng);
        _curEngine = eng;
      } catch (_) {}
    }
    unawaited(Piper.refresh());
  }

  /// Forget cached language / voice so the next word applies new settings.
  static void invalidate() {
    _lang = null;
    _voiceKey = null;
    _rate = null;
    _cache.clear();
    _order.clear();
  }

  // ───────────── device voice ─────────────

  static bool _yes(dynamic v) => v == true || v == 1;

  /// Prepares the device engine. Returns false (and records why) if unusable.
  static Future<bool> warm(String lang) async {
    await init();
    try {
      final s = AppState.I;
      if (_lang != lang) {
        try {
          final engines = await _tts.getEngines;
          if (engines is List && engines.isEmpty) {
            errors['system'] = 'no text-to-speech engine installed on this phone';
            _sysBadUntil = DateTime.now().add(const Duration(minutes: 2));
            return false;
          }
        } catch (_) {}
        var use = lang;
        if (!_yes(await _tts.isLanguageAvailable(lang))) {
          final base = lang.split('-').first;
          if (_yes(await _tts.isLanguageAvailable(base))) {
            use = base;
          } else {
            errors['system'] = 'voice data for "$lang" is not installed';
            return false;
          }
        }
        await _tts.setLanguage(use);
        _lang = lang;
        _voiceKey = null;
      }
      if (_rate != s.speechRate) {
        await _tts.setSpeechRate(s.speechRate);
        _rate = s.speechRate;
      }
      final vk = '$lang|${s.voiceGender}|${s.sysVoice}';
      if (_voiceKey != vk) {
        await _applyVoice(lang);
        _voiceKey = vk;
      }
      return true;
    } catch (e) {
      errors['system'] = _short(e);
      return false;
    }
  }

  static String _genderOf(String name) {
    final n = name.toLowerCase();
    if (n.contains('female')) return 'f';
    if (n.contains('male')) return 'm';
    return '';
  }

  /// Installed device voices for [lang], each {name, locale, gender}.
  static Future<List<Map<String, String>>> systemVoices(String lang) async {
    await init();
    final code = lang.split('-').first.toLowerCase();
    final out = <Map<String, String>>[];
    try {
      final vs = await _tts.getVoices;
      if (vs is List) {
        for (final v in vs) {
          if (v is! Map) continue;
          final name = (v['name'] ?? '').toString();
          final loc = (v['locale'] ?? '').toString();
          if (name.isEmpty) continue;
          if (!loc.toLowerCase().replaceAll('_', '-').startsWith(code)) continue;
          out.add({'name': name, 'locale': loc, 'gender': _genderOf(name)});
        }
      }
    } catch (_) {}
    return out;
  }

  static Future<void> _applyVoice(String lang) async {
    final s = AppState.I;
    final list = await systemVoices(lang);
    if (list.isEmpty) return;
    Map<String, String>? pick;
    if (s.sysVoice.isNotEmpty) {
      for (final v in list) {
        if (v['name'] == s.sysVoice) pick = v;
      }
    }
    if (pick == null) {
      for (final v in list) {
        if (v['gender'] == s.voiceGender) {
          pick = v;
          break;
        }
      }
    }
    if (pick == null) return; // keep the engine's default voice
    try {
      await _tts.setVoice({'name': pick['name']!, 'locale': pick['locale']!});
    } catch (_) {}
  }

  /// Text report about the device engine (for the voice test screen).
  static Future<String> systemInfo(String lang) async {
    await init();
    final b = StringBuffer();
    try {
      final e = await _tts.getEngines;
      b.writeln('engines: ${e is List ? (e.isEmpty ? 'none' : e.join(', ')) : e}');
    } catch (x) {
      b.writeln('engines: ${_short(x)}');
    }
    try {
      b.writeln('default: ${await _tts.getDefaultEngine}');
    } catch (_) {}
    try {
      b.writeln('$lang: ${_yes(await _tts.isLanguageAvailable(lang)) ? 'available' : 'NOT installed'}');
    } catch (x) {
      b.writeln('$lang: ${_short(x)}');
    }
    return b.toString().trim();
  }

  static Future<List<String>> systemEngines() async {
    await init();
    try {
      final e = await _tts.getEngines;
      if (e is List) return e.map((x) => x.toString()).toList();
    } catch (_) {}
    return [];
  }

  static String engineLabel(String pkg) {
    const names = {
      'com.google.android.tts': 'Google',
      'com.samsung.SMT': 'Samsung',
      'com.svox.pico': 'Pico',
      'com.github.olga_yakovleva.rhvoice.android': 'RHVoice',
      'com.reecedunn.espeak': 'eSpeak',
      'com.microsoft.cognitiveservices.speech.tts': 'Microsoft',
      'com.huawei.hiai': 'Huawei',
      'com.xiaomi.mibrain.speech': 'Xiaomi',
    };
    return names[pkg] ?? pkg.split('.').last;
  }

  /// '' = automatic (last working engine, then Google, then the others).
  static Future<void> useEngine(String pkg) async {
    final s = AppState.I;
    s.sysEngine = pkg;
    await s.saveSettings();
    if (pkg.isNotEmpty) {
      try {
        await _tts.setEngine(pkg);
        _curEngine = pkg;
      } catch (e) {
        errors['system'] = _short(e);
      }
    }
    _goodEngine = null;
    _sysBadUntil = DateTime.fromMillisecondsSinceEpoch(0);
    invalidate();
  }

  // ───────────── control ─────────────

  static Future<void> stop() async {
    _gen++;
    _fin(_doneW);
    try {
      if (_sysSpeaking) await _tts.stop();
      await _online?.stop();
    } catch (_) {}
  }

  static List<String> _chain(String e) {
    final first = (e == 'auto' || !isKnownEngine(e)) ? null : e;
    return [if (first != null) first, ...kTtsChain.where((x) => x != first)];
  }

  static String _clean(String text) {
    var txt = text.replaceAll(RegExp(r'[*_#`$]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (txt.length > 3500) txt = txt.substring(0, 3500);
    return txt;
  }

  /// Speaks [text]. With [wait] the future completes when the speech ends.
  static Future<void> speak(String text, String lang, {bool wait = false}) async {
    final txt = _clean(text);
    if (txt.isEmpty) return;
    final gen = ++_gen;
    if (_online != null) unawaited(_online!.stop().catchError((_) {}));
    if (_sysSpeaking) {
      try {
        await _tts.stop().timeout(const Duration(seconds: 1));
      } catch (_) {}
      _sysSpeaking = false;
    }
    for (final e in _chain(AppState.I.ttsEngine)) {
      if (gen != _gen) return;
      if (e == 'system' && DateTime.now().isBefore(_sysBadUntil)) continue;
      final ok = e == 'system'
          ? await _speakSystem(txt, lang, gen, wait)
          : await _speakClips(e, txt, lang, gen, wait);
      if (gen != _gen) return;
      if (ok) {
        lastEngine = e;
        engineUsed.value = e;
        return;
      }
    }
    _notifyFail();
  }

  static void _notifyFail() {
    final now = DateTime.now();
    if (now.difference(_lastNotice).inSeconds < 20) return;
    _lastNotice = now;
    final m = rootMessenger.currentState;
    if (m == null) return;
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(
      duration: const Duration(seconds: 6),
      content: Text(t('voice_all_failed')),
    ));
  }

  /// Every installed Android speech engine, best first: the one that last
  /// worked, the user's choice, Google, then the rest. Max 3 are tried.
  static Future<List<String>> _systemCandidates() async {
    final installed = await systemEngines();
    if (installed.isEmpty) return [''];
    final out = <String>[];
    void add(String? e) {
      if (e != null && e.isNotEmpty && installed.contains(e) && !out.contains(e)) out.add(e);
    }
    add(_goodEngine);
    add(AppState.I.sysEngine);
    add('com.google.android.tts');
    for (final e in installed) {
      add(e);
    }
    return out.take(3).toList();
  }

  static Future<bool> _useSysEngine(String pkg) async {
    if (pkg.isEmpty || pkg == _curEngine) return true;
    try {
      await _tts.setEngine(pkg);
    } catch (e) {
      errors['system'] = _short(e);
      return false;
    }
    _curEngine = pkg;
    _lang = null; // languages and voices differ per engine
    _voiceKey = null;
    _rate = null;
    return true;
  }

  static Future<bool> _speakSystem(String txt, String lang, int gen, bool wait) async {
    final candidates = await _systemCandidates();
    for (int i = 0; i < candidates.length; i++) {
      if (gen != _gen) return true;
      final pkg = candidates[i];
      if (!await _useSysEngine(pkg)) continue;
      if (await _speakSystemOnce(txt, lang, gen, wait, i == 0 ? 6 : 4)) {
        if (pkg.isNotEmpty) _goodEngine = pkg;
        return true;
      }
    }
    _sysBadUntil = DateTime.now().add(const Duration(seconds: 90));
    return false;
  }

  static Future<bool> _speakSystemOnce(String txt, String lang, int gen, bool wait, int startSecs) async {
    if (!await warm(lang)) return false;
    if (gen != _gen) return true;
    final started = Completer<bool>();
    final done = Completer<void>();
    _startW = started;
    _doneW = done;
    dynamic r;
    try {
      r = await _tts.speak(txt);
    } catch (e) {
      errors['system'] = _short(e);
      return false;
    }
    if (r == 0) {
      errors['system'] = 'speak() returned 0 (engine not ready)';
      return false;
    }
    final ok = await started.future.timeout(Duration(seconds: startSecs), onTimeout: () {
      errors['system'] ??= 'the engine never started speaking ($startSecs s)';
      return false;
    });
    if (!ok) {
      try {
        await _tts.stop();
      } catch (_) {}
      return false;
    }
    errors.remove('system');
    if (wait) await done.future.timeout(const Duration(seconds: 120), onTimeout: () {});
    return true;
  }

  static Future<bool> _speakClips(String engine, String text, String lang, int gen, bool wait) async {
    try {
      final code = lang.split('-').first;
      final chunks = _chunks(text);
      if (chunks.isEmpty) return false;
      var next = _get(engine, code, chunks.first);
      for (int i = 0; i < chunks.length; i++) {
        final clip = await next;
        if (gen != _gen) return true;
        if (clip == null) return i > 0;
        if (i + 1 < chunks.length) next = _get(engine, code, chunks[i + 1]);
        _online ??= AudioPlayer();
        final player = _online!;
        final done = player.onPlayerComplete.first.timeout(const Duration(seconds: 60), onTimeout: () {});
        await player.play(BytesSource(clip.bytes, mimeType: clip.mime));
        if (i + 1 < chunks.length || wait) await done;
        if (gen != _gen) return true;
      }
      return true;
    } catch (e) {
      errors[_key(engine)] = _short(e);
      return false;
    }
  }

  /// Downloads / synthesises the audio ahead of time (clip engines only).
  static void prefetch(String text, String lang) {
    final s = AppState.I;
    final code = lang.split('-').first;
    if (s.ttsEngine == 'system') return;
    if (Piper.pick(code, s.voiceGender) == null) return;
    final c = _chunks(_clean(text));
    if (c.isNotEmpty) unawaited(_get('piper', code, c.first));
  }

  // ───────────── diagnostics ─────────────

  static String samplePhrase(String lang) {
    switch (lang.split('-').first) {
      case 'ar':
        return 'مرحباً، هذا اختبار للصوت.';
      case 'fr':
        return 'Bonjour, ceci est un test de la voix.';
      case 'de':
        return 'Hallo, das ist ein Test der Stimme.';
      case 'es':
        return 'Hola, esto es una prueba de voz.';
      case 'it':
        return 'Ciao, questa è una prova della voce.';
      case 'ru':
        return 'Привет, это проверка голоса.';
      case 'tr':
        return 'Merhaba, bu bir ses testidir.';
      case 'pt':
        return 'Olá, este é um teste de voz.';
      case 'zh':
        return '你好，这是语音测试。';
      default:
        return 'Hello, this is a voice test.';
    }
  }

  /// Plays one engine alone (no fallback) and reports what happened.
  static Future<VoiceResult> test(String engine, String lang) async {
    await init();
    final gen = ++_gen;
    try {
      await _online?.stop();
      if (_sysSpeaking) await _tts.stop();
    } catch (_) {}
    errors.remove(_key(engine));
    final sw = Stopwatch()..start();
    final phrase = samplePhrase(lang);
    bool ok;
    if (engine == 'system') {
      _sysBadUntil = DateTime.fromMillisecondsSinceEpoch(0);
      ok = await _speakSystem(phrase, lang, gen, false);
    } else {
      ok = await _speakClips(engine, phrase, lang, gen, false);
    }
    return VoiceResult(ok, ok ? '${sw.elapsedMilliseconds} ms' : (errors[_key(engine)] ?? 'unknown error'));
  }


  /// Plays one specific downloaded Piper voice (used by the voice screen).
  static Future<VoiceResult> testVoice(PiperVoice v) async {
    await init();
    final gen = ++_gen;
    try {
      await _online?.stop();
      if (_sysSpeaking) await _tts.stop();
    } catch (_) {}
    final sw = Stopwatch()..start();
    try {
      final lang = v.lang;
      final sample = samplePhrase(lang);
      final speed = (AppState.I.speechRate / 0.45).clamp(0.6, 1.6).toDouble();
      final wav = await Piper.synth(v, sample, speed);
      if (gen != _gen) return const VoiceResult(true, 'cancelled');
      _online ??= AudioPlayer();
      await _online!.play(BytesSource(wav, mimeType: 'audio/wav'));
      return VoiceResult(true, '${sw.elapsedMilliseconds} ms');
    } catch (e) {
      errors['piper'] = _short(e);
      return VoiceResult(false, _short(e));
    }
  }

  // ───────────── text chunks and clip engines ─────────────

  static List<String> _chunks(String text) {
    const max = 180;
    final out = <String>[];
    var cur = '';
    for (final part in text.split(RegExp(r'(?<=[.!?؟,،;:])\s+'))) {
      if (part.length > max) {
        if (cur.isNotEmpty) {
          out.add(cur);
          cur = '';
        }
        var buf = '';
        for (final w in part.split(' ')) {
          if (buf.isNotEmpty && buf.length + w.length + 1 > max) {
            out.add(buf);
            buf = w;
          } else {
            buf = buf.isEmpty ? w : '$buf $w';
          }
        }
        if (buf.isNotEmpty) out.add(buf);
        continue;
      }
      if (cur.isNotEmpty && cur.length + part.length + 1 > max) {
        out.add(cur);
        cur = part;
      } else {
        cur = cur.isEmpty ? part : '$cur $part';
      }
    }
    if (cur.isNotEmpty) out.add(cur);
    return out;
  }

  static Future<_Clip?> _get(String engine, String code, String chunk) async {
    final s = AppState.I;
    final k = '$engine|$code|${s.voiceGender}|${engine == 'piper' ? s.speechRate.toStringAsFixed(2) : ''}|$chunk';
    final hit = _cache[k];
    if (hit != null) return hit;
    _Clip? clip;
    try {
      clip = await _piper(code, chunk);
      if (clip != null) errors.remove(_key(engine));
    } catch (e) {
      errors[_key(engine)] = _short(e);
    }
    if (clip == null) return null;
    _cache[k] = clip;
    _order.add(k);
    if (_order.length > 80) _cache.remove(_order.removeAt(0));
    return clip;
  }

  static Future<_Clip?> _piper(String code, String chunk) async {
    final s = AppState.I;
    final v = Piper.pick(code, s.voiceGender);
    if (v == null) {
      errors['piper'] = 'no offline voice downloaded for "$code"';
      return null;
    }
    final speed = (s.speechRate / 0.45).clamp(0.6, 1.6).toDouble();
    final wav = await Piper.synth(v, chunk, speed);
    return _Clip(wav, 'audio/wav');
  }
}
