import 'package:flutter/material.dart';

import 'backgrounds.dart';
import 'cards_tab.dart';
import 'create_tab.dart';
import 'games_tab.dart';
import 'progress.dart';
import 'quiz_tab.dart';
import 'services.dart';
import 'settings_screen.dart';
import 'state.dart';
import 'stories_tab.dart';
import 'strings.dart';
import 'summarize_tab.dart';
import 'theme.dart';
import 'ui_extras.dart';
import 'more_screen.dart';
import 'pet.dart';
import 'pet_roamer.dart';

class HomeShell extends StatelessWidget {
  final bool reveal;
  const HomeShell({super.key, this.reveal = false});

  static const List<(String, String)> _tabs = [
    ('create', 'tab_create'),
    ('cards', 'tab_cards'),
    ('games', 'tab_games'),
    ('summary', 'tab_sum'),
    ('quiz', 'tab_quiz'),
    ('stories', 'tab_stories'),
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          backgroundColor: C.cream,
          body: ListenableBuilder(
            listenable: AppState.I,
            builder: (context, _) => ValueListenableBuilder<int>(
              valueListenable: AppState.I.tab,
              builder: (context, idx, _) {
                return BgBackdrop(
                  id: idx == 2 ? AppState.I.bgGames : AppState.I.bgHome,
                  extra: 0,
                  child: SafeArea(
                    child: Column(
                      children: [
                        _TopBar(title: t(_tabs[idx].$2)),
                        const DailyStrip(),
                        Expanded(
                          child: Stack(
                            children: [
                              IndexedStack(
                                index: idx,
                                children: const [
                                  CreateTab(),
                                  CardsTab(),
                                  GamesTab(),
                                  SummarizeTab(),
                                  QuizTab(),
                                  StoriesTab(),
                                ],
                              ),
                              PixelRevealOverlay(
                                key: ValueKey('reveal$idx'),
                                color: C.cream,
                                ms: 380,
                                cols: 7,
                              ),
                              if (AppState.I.hasPet)
                                const Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  height: 34,
                                  child: IgnorePointer(child: PetRoamer()),
                                ),
                            ],
                          ),
                        ),
                        _NavBar(index: idx, tabs: _tabs),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        if (reveal)
          PixelRevealOverlay(
            key: ValueKey('firstReveal'),
            color: C.ink,
            ms: 800,
            cols: 9,
          ),
      ],
    );
  }
}

class _TopBar extends StatelessWidget {
  final String title;
  const _TopBar({required this.title});

  @override
  Widget build(BuildContext context) {
    // Top bar grows less than the rest so every button still fits on narrow phones.
    final kt = 1 + (AppState.I.btnScale - 1) * 0.6;
    final pet = AppState.I.hasPet;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: BoxDecoration(
        color: C.cream,
        border: Border(bottom: BorderSide(color: C.ink, width: 3)),
      ),
      child: Row(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PetScreen()),
              );
            },
            child: Sprite(pet ? 'pet_${AppState.I.petKind}' : AppState.I.mascot, px: 3),
          ),
          const SizedBox(width: 8),
          const PixelFont('AORC AI', scale: 2.2),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: C.gray),
            ),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const MoreScreen()),
              );
            },
            child: PixelBox(
              padding: EdgeInsets.all(7 * kt),
              child: Sprite('more', px: 2.5 * kt),
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProgressScreen()),
              );
            },
            child: PixelBox(
              padding: EdgeInsets.symmetric(
                  horizontal: 7 * kt, vertical: 5 * kt),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Sprite('flame', px: 2.5 * kt),
                  const SizedBox(width: 5),
                  tx('${AppState.I.streak}', bold: true, size: 14),
                ],
              ),
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
            child: PixelBox(
              padding: EdgeInsets.all(7 * kt),
              child: Sprite('gear', px: 2.5 * kt),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int index;
  final List<(String, String)> tabs;
  const _NavBar({required this.index, required this.tabs});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: C.white,
        border: Border(top: BorderSide(color: C.ink, width: 3)),
      ),
      padding: const EdgeInsets.fromLTRB(4, 6, 4, 6),
      child: Row(
        children: [
          for (int i = 0; i < tabs.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  if (i != index) {
                    Sfx.play('flip');
                    AppState.I.tab.value = i;
                  }
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  padding: EdgeInsets.symmetric(vertical: 5 * AppState.I.btnScale),
                  color: i == index ? C.ink : Colors.transparent,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Sprite(tabs[i].$1, px: 2.4 * AppState.I.btnScale, tint: i == index ? C.cream : C.ink),
                      const SizedBox(height: 3),
                      Text(
                        t(tabs[i].$2),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 9.5 + 2 * (AppState.I.btnScale - 1),
                          fontWeight: FontWeight.w900,
                          color: i == index ? C.cream : C.ink,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
