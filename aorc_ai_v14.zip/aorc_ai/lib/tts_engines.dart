/// Single source of truth for every speech engine.
/// Settings, the voice test screen, the fallback chain and the badge all read
/// this list. Only engines that work without any external service remain:
///  - piper:  offline neural voice (sherpa_onnx), downloaded once
///  - system: flutter_tts on top of the phone's Android speech engines
///            (Google, Samsung, ... all tried automatically, see speech.dart)
class TtsEngine {
  final String id;
  final bool inChain; // part of the automatic fallback chain
  final bool inTestAll; // tested by "run all" in the voice screen
  const TtsEngine(this.id, {this.inChain = false, this.inTestAll = false});
}

const List<TtsEngine> kTtsEngines = [
  TtsEngine('auto'),
  TtsEngine('piper', inChain: true, inTestAll: true),
  TtsEngine('system', inChain: true, inTestAll: true),
];

const List<String> kTtsChain = ['piper', 'system'];
List<String> get kTtsTestAll => [for (final e in kTtsEngines) if (e.inTestAll) e.id];
bool isKnownEngine(String id) => kTtsEngines.any((e) => e.id == id);

/// Maps an engine id to the key used in `Speech.errors`.
String ttsErrorKey(String engine) => engine;
