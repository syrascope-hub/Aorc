import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'stt.dart';
import 'strings.dart';
import 'theme.dart';

const Map<String, String> kScenarioDesc = {
  'restaurant': 'ordering food at a restaurant (you are the waiter)',
  'airport': 'checking in at an airport (you are the airline agent)',
  'interview': 'a job interview (you are the interviewer)',
  'doctor': 'a visit to the doctor (you are the doctor)',
  'shopping': 'shopping in a clothing store (you are the shop assistant)',
  'free': 'a relaxed friendly chat between two friends',
};

const Map<String, String> kScenarioIcon = {
  'restaurant': 'cards',
  'airport': 'games',
  'interview': 'summary',
  'doctor': 'heart',
  'shopping': 'shop',
  'free': 'chat',
};

class _Msg {
  final bool user;
  final String text;
  final String? fix;
  _Msg(this.user, this.text, {this.fix});
}

/// Role-play conversation that nudges the learner to use their own words.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  String scenario = 'restaurant';
  String level = 'A2';
  bool started = false;
  bool busy = false;
  bool listening = false;
  final input = TextEditingController();
  final scroll = ScrollController();
  final List<_Msg> msgs = [];
  final List<Map<String, String>> history = [];
  List<String> targets = [];
  final Set<String> used = {};
  bool bonusGiven = false;

  AppState get s => AppState.I;

  @override
  void dispose() {
    Stt.stop();
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  String get _system {
    final lang = langOf(s.frontLang).en;
    return 'You are a friendly role-play partner for a $lang learner at CEFR level $level. '
        'Scenario: ${kScenarioDesc[scenario]}. Stay in character. Reply only in $lang with 1 to 3 short sentences '
        'and always end with a question or prompt that keeps the dialogue going. '
        '${targets.isEmpty ? '' : 'When it fits naturally, steer the conversation so the learner can use these words: ${targets.join(', ')}. '}'
        'If the learner\'s last message contains a mistake, begin your reply with one line "FIX: <their sentence corrected>" '
        'and then a new line with your in-character reply. If there is no mistake, never write FIX.';
  }

  Future<void> _start() async {
    if (!s.aiReady) {
      toast(context, t('need_token'));
      return;
    }
    targets = randomCards(s.scope, 6).map((c) => c.front).toList();
    used.clear();
    msgs.clear();
    history
      ..clear()
      ..add({'role': 'system', 'content': _system})
      ..add({'role': 'user', 'content': '(Start the conversation with your first line.)'});
    setState(() {
      started = true;
      bonusGiven = false;
    });
    await _ask();
  }

  Future<void> _ask() async {
    setState(() => busy = true);
    try {
      final r = await Ai.chatMessages(history, maxTokens: 300, temp: 0.8);
      history.add({'role': 'assistant', 'content': r});
      String? fix;
      var body = r.trim();
      if (body.toUpperCase().startsWith('FIX:')) {
        final nl = body.indexOf('\n');
        if (nl > 0) {
          fix = body.substring(4, nl).trim();
          body = body.substring(nl + 1).trim();
        } else {
          fix = body.substring(4).trim();
          body = '';
        }
      }
      if (mounted) {
        setState(() {
          if (fix != null && fix.isNotEmpty) msgs.add(_Msg(false, '', fix: fix));
          if (body.isNotEmpty) msgs.add(_Msg(false, body));
        });
        _toEnd();
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent + 120,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _send() async {
    final txt = input.text.trim();
    if (txt.isEmpty || busy) return;
    if (listening) {
      await Stt.stop();
      listening = false;
    }
    input.clear();
    final n = normText(txt);
    int fresh = 0;
    for (final w in targets) {
      if (!used.contains(w) && n.contains(normText(w))) {
        used.add(w);
        fresh++;
      }
    }
    setState(() => msgs.add(_Msg(true, txt)));
    history.add({'role': 'user', 'content': txt});
    s.bump('chat');
    if (fresh > 0) {
      s.addCoins(fresh);
      Sfx.play('ok');
    }
    if (!bonusGiven && targets.isNotEmpty && used.length == targets.length) {
      bonusGiven = true;
      s.addCoins(5);
      if (mounted) toast(context, t('chat_all_used'));
      Sfx.play('win');
    }
    _toEnd();
    await _ask();
  }

  Future<void> _mic() async {
    if (listening) {
      await Stt.stop();
      setState(() => listening = false);
      return;
    }
    final ok = await Stt.start(s.frontLang, (text, done) {
      if (!mounted) return;
      setState(() {
        input.text = text;
        if (done) listening = false;
      });
    });
    if (!mounted) return;
    if (!ok) {
      toast(context, t('stt_unavailable'));
    } else {
      setState(() => listening = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('chat'),
      actions: [coinChip()],
      child: started ? _chat() : _setup(),
    );
  }

  Widget _setup() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        infoBox(t('chat_help')),
        PixelTitle(t('scenario')),
        PixelChips<String>(
          options: [for (final k in kScenarioDesc.keys) (k, t('sc_$k'))],
          value: scenario,
          onChanged: (v) => setState(() => scenario = v),
        ),
        PixelTitle(t('level')),
        PixelChips<String>(
          options: const [('A1', 'A1'), ('A2', 'A2'), ('B1', 'B1'), ('B2', 'B2'), ('C1', 'C1')],
          value: level,
          onChanged: (v) => setState(() => level = v),
        ),
        const SizedBox(height: 18),
        PixelButton(
          label: t('start'),
          icon: kScenarioIcon[scenario],
          expand: true,
          onTap: _start,
        ),
      ],
    );
  }

  Widget _chat() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 6),
          child: Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final w in targets)
                PixelBox(
                  u: 2,
                  shadow: false,
                  color: used.contains(w) ? C.ink : C.white,
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  child: Text(w,
                      style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: used.contains(w) ? C.cream : C.ink)),
                ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            controller: scroll,
            padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
            children: [
              for (final m in msgs) _bubble(m),
              if (busy)
                const Padding(
                  padding: EdgeInsets.all(8),
                  child: Align(alignment: AlignmentDirectional.centerStart, child: PixelLoader()),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
          child: Row(
            children: [
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _mic,
                child: PixelBox(
                  color: listening ? C.ink : C.white,
                  padding: const EdgeInsets.all(9),
                  child: Sprite('mic', px: 2.6, tint: listening ? C.cream : C.ink),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: PixelField(
                  controller: input,
                  hint: t('type_message'),
                  maxLines: 3,
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              PixelButton(icon: 'check', onTap: busy ? null : _send),
            ],
          ),
        ),
      ],
    );
  }

  Widget _bubble(_Msg m) {
    if (m.fix != null) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: PixelBox(
          u: 2,
          shadow: false,
          color: C.creamDeep,
          padding: const EdgeInsets.all(8),
          child: SizedBox(
            width: double.infinity,
            child: Text('✎ ${m.fix}',
                style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, height: 1.4)),
          ),
        ),
      );
    }
    final isUser = m.user;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Align(
        alignment: isUser ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
          child: PixelBox(
            color: isUser ? C.ink : C.white,
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(m.text,
                    style: TextStyle(
                        fontSize: 15,
                        height: 1.4,
                        fontWeight: FontWeight.w600,
                        color: isUser ? C.cream : C.ink)),
                if (!isUser) ...[
                  const SizedBox(height: 6),
                  SpeakBtn(m.text, s.frontLang),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
