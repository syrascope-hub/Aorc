import 'dart:math';

import 'package:flutter/material.dart';

import 'listen_mode.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Small label showing which voice engine produced the last speech.
class EngineBadge extends StatelessWidget {
  const EngineBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String?>(
      valueListenable: Speech.engineUsed,
      builder: (_, e, __) {
        if (e == null) return const SizedBox.shrink();
        return tx('${t('badge_voice')}: ${t('badge_$e')}', size: 10.5, color: C.gray, bold: true);
      },
    );
  }
}

/// Daily progress ring, streak and a quick "listen" button.
class DailyStrip extends StatelessWidget {
  const DailyStrip({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final goal = s.dailyGoal <= 0 ? 1 : s.dailyGoal;
    final n = s.todayCount;
    final v = (n / goal).clamp(0.0, 1.0).toDouble();
    final done = n >= goal;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      decoration: BoxDecoration(
        color: C.white,
        border: Border(bottom: BorderSide(color: C.ink, width: 3)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 40,
            height: 40,
            child: CustomPaint(
              painter: _RingPainter(v, C.ink, C.light),
              child: Center(
                child: done ? const Sprite('check', px: 2.2) : tx('$n', bold: true, size: 12),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                tx(done ? t('daily_goal_done') : '${t('daily_today')}: $n / $goal', bold: true, size: 13),
                const SizedBox(height: 2),
                Row(
                  children: [
                    const Sprite('flame', px: 2),
                    const SizedBox(width: 4),
                    tx('${s.streak} ${t('streak_days')}', size: 11.5, color: C.gray, bold: true),
                  ],
                ),
              ],
            ),
          ),
          PixelButton(
            label: t('quick_listen'),
            icon: 'headphones',
            small: true,
            onTap: () {
              Sfx.play('tap');
              Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const ListenModeScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double v;
  final Color on, off;
  _RingPainter(this.v, this.on, this.off);

  @override
  void paint(Canvas c, Size sz) {
    const segs = 12;
    const stroke = 6.0;
    const gap = 0.16;
    final r = Rect.fromLTWH(stroke / 2, stroke / 2, sz.width - stroke, sz.height - stroke);
    final filled = (v * segs).floor();
    for (int i = 0; i < segs; i++) {
      final p = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke
        ..strokeCap = StrokeCap.butt
        ..color = i < filled ? on : off;
      c.drawArc(r, -pi / 2 + i * 2 * pi / segs + gap / 2, 2 * pi / segs - gap, false, p);
    }
  }

  @override
  bool shouldRepaint(_RingPainter o) => o.v != v || o.on != on || o.off != off;
}
