import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'state.dart';

/// Global trigger for pixel particles and the wrong-answer shake.
/// Called from Sfx.play so every right/wrong answer gets feedback for free.
class Fx {
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static String last = 'ok';

  /// kind: 'ok' (small pop), 'win' (confetti), 'bad' (shake + red flash).
  static void fire(String kind) {
    if (!AppState.I.fx) return;
    last = kind;
    tick.value++;
  }
}

class _P {
  double x, y, vx, vy, life, max, size;
  Color color;
  _P(this.x, this.y, this.vx, this.vy, this.life, this.size, this.color) : max = life;
}

const List<Color> _kColors = [
  Color(0xFFFFD23F),
  Color(0xFFFF5D8F),
  Color(0xFF2EE6FF),
  Color(0xFFFFFFFF),
  Color(0xFF7CFF6B),
  Color(0xFFFF9F1C),
];

/// Wraps the whole app: draws particles above everything and shakes the child.
class FxHost extends StatefulWidget {
  final Widget child;
  const FxHost({super.key, required this.child});

  @override
  State<FxHost> createState() => _FxHostState();
}

class _FxHostState extends State<FxHost> with SingleTickerProviderStateMixin {
  late final Ticker _tk;
  final Random _rnd = Random();
  final List<_P> _ps = [];
  Size _size = const Size(360, 640);
  Duration _prev = Duration.zero;
  double _shake = 0;
  double _flash = 0;

  @override
  void initState() {
    super.initState();
    _tk = createTicker(_step);
    Fx.tick.addListener(_onFire);
  }

  @override
  void dispose() {
    Fx.tick.removeListener(_onFire);
    _tk.dispose();
    super.dispose();
  }

  void _onFire() {
    final w = _size.width;
    final h = _size.height;
    switch (Fx.last) {
      case 'win':
        for (int i = 0; i < 40; i++) {
          _ps.add(_P(
            _rnd.nextDouble() * w,
            -10 - _rnd.nextDouble() * 40,
            (_rnd.nextDouble() - 0.5) * 80,
            120 + _rnd.nextDouble() * 160,
            1.6 + _rnd.nextDouble() * 0.6,
            4 + _rnd.nextInt(2) * 4,
            _kColors[_rnd.nextInt(_kColors.length)],
          ));
        }
        break;
      case 'bad':
        _shake = 0.3;
        _flash = 0.25;
        break;
      default:
        for (int i = 0; i < 14; i++) {
          final a = _rnd.nextDouble() * pi * 2;
          final sp = 110 + _rnd.nextDouble() * 170;
          _ps.add(_P(
            w / 2,
            h * 0.42,
            cos(a) * sp,
            sin(a) * sp - 90,
            0.75 + _rnd.nextDouble() * 0.3,
            4 + _rnd.nextInt(2) * 4,
            _kColors[_rnd.nextInt(_kColors.length)],
          ));
        }
    }
    if (!_tk.isActive) {
      _prev = Duration.zero;
      _tk.start();
    }
  }

  void _step(Duration d) {
    final dt = ((d - _prev).inMicroseconds / 1000000.0).clamp(0.0, 0.05);
    _prev = d;
    for (final p in _ps) {
      p.life -= dt;
      p.vy += 420 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    _ps.removeWhere((p) => p.life <= 0 || p.y > _size.height + 20);
    if (_shake > 0) _shake -= dt;
    if (_flash > 0) _flash -= dt;
    if (_ps.isEmpty && _shake <= 0 && _flash <= 0) {
      _shake = 0;
      _flash = 0;
      _tk.stop();
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        _size = Size(c.maxWidth, c.maxHeight);
        final dx = _shake > 0 ? sin(_shake * 90) * 7 * (_shake / 0.3) : 0.0;
        return Stack(
          textDirection: TextDirection.ltr,
          fit: StackFit.expand,
          children: [
            Transform.translate(offset: Offset(dx, 0), child: widget.child),
            if (_ps.isNotEmpty || _flash > 0)
              IgnorePointer(
                child: CustomPaint(
                  size: Size.infinite,
                  painter: _FxPainter(List<_P>.of(_ps), _flash),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _FxPainter extends CustomPainter {
  final List<_P> ps;
  final double flash;
  _FxPainter(this.ps, this.flash);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..isAntiAlias = false;
    if (flash > 0) {
      paint.color = Color.fromARGB((flash / 0.25 * 70).round().clamp(0, 255), 255, 40, 40);
      canvas.drawRect(Offset.zero & size, paint);
    }
    for (final p in ps) {
      final a = (p.life / p.max).clamp(0.0, 1.0);
      paint.color = p.color.withAlpha((a * 255).round().clamp(0, 255));
      final s = p.size;
      final x = (p.x / 4).floor() * 4.0;
      final y = (p.y / 4).floor() * 4.0;
      canvas.drawRect(Rect.fromLTWH(x, y, s, s), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _FxPainter old) => true;
}
