import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'state.dart';
import 'theme.dart';

/// Your pet walks along the bottom of the home screen, rests sometimes and
/// sleeps at night. Purely visual: it never blocks taps (wrap in IgnorePointer).
class PetRoamer extends StatefulWidget {
  const PetRoamer({super.key});

  @override
  State<PetRoamer> createState() => _PetRoamerState();
}

class _PetRoamerState extends State<PetRoamer> with SingleTickerProviderStateMixin {
  late final Ticker _tk;
  final Random _r = Random();
  double _x = 30;
  double _dir = 1;
  double _pause = 0;
  double _acc = 0;
  double _w = 360;
  bool _bob = false;
  Duration _prev = Duration.zero;

  static const double _sw = 36; // approximate sprite width incl. margin

  bool get _asleep {
    final h = DateTime.now().hour;
    return h >= 22 || h < 6;
  }

  @override
  void initState() {
    super.initState();
    _tk = createTicker(_step)..start();
  }

  @override
  void dispose() {
    _tk.dispose();
    super.dispose();
  }

  void _step(Duration d) {
    final dt = ((d - _prev).inMicroseconds / 1000000.0).clamp(0.0, 0.2);
    _prev = d;
    _acc += dt;
    if (_acc < 0.1) return;
    final step = _acc;
    _acc = 0;
    if (!AppState.I.bgMotion || _asleep || AppState.I.petJoy < 25) {
      return;
    }
    if (_pause > 0) {
      _pause -= step;
      _bob = false;
    } else {
      _x += _dir * 16 * step;
      _bob = !_bob;
      final maxX = max(0.0, _w - _sw);
      if (_x < 0) {
        _x = 0;
        _dir = 1;
      } else if (_x > maxX) {
        _x = maxX;
        _dir = -1;
      }
      if (_r.nextDouble() < 0.03) _pause = 1 + _r.nextDouble() * 3;
      if (_r.nextDouble() < 0.01) _dir = -_dir;
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        _w = c.maxWidth;
        final asleep = _asleep;
        final sprite = Sprite('pet_${AppState.I.petKind}', px: 2.5);
        return Stack(
          textDirection: TextDirection.ltr,
          children: [
            Positioned(
              left: _x,
              bottom: 0,
              child: Opacity(
                opacity: asleep ? 0.75 : 1,
                child: Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.diagonal3Values(_dir < 0 ? -1 : 1, 1, 1),
                  child: Transform.translate(
                    offset: Offset(0, _bob ? -2 : 0),
                    child: sprite,
                  ),
                ),
              ),
            ),
            if (asleep)
              Positioned(
                left: _x + 22,
                bottom: 20,
                child: Text('z Z',
                    style: TextStyle(
                        fontSize: 11, fontWeight: FontWeight.w900, color: C.dark)),
              ),
          ],
        );
      },
    );
  }
}
