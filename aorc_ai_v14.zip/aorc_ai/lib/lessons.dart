import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';
import 'vision_card.dart';

class _Qa {
  final String q, a;
  bool on = true;
  _Qa(this.q, this.a);
}

/// Turns lecture notes (typed, pasted or photographed) into Q&A flashcards.
class LessonsScreen extends StatefulWidget {
  const LessonsScreen({super.key});
  @override
  State<LessonsScreen> createState() => _LessonsScreenState();
}

class _LessonsScreenState extends State<LessonsScreen> {
  final text = TextEditingController();
  int count = 10;
  bool busy = false;
  bool reading = false;
  List<_Qa> items = [];
  late String deckId = AppState.I.activeDeck == 'all' ? 'default' : AppState.I.activeDeck;

  AppState get s => AppState.I;

  @override
  void dispose() {
    text.dispose();
    super.dispose();
  }

  Future<void> _photo(bool camera) async {
    final b = await pickPhoto(context, camera: camera);
    if (b == null || !mounted) return;
    if (!s.aiReady) {
      toast(context, t('need_token'));
      return;
    }
    setState(() => reading = true);
    try {
      final r = await Ai.vision(
        b,
        'Transcribe all the text in this image as plain text, keeping the original language and order. '
        'Output only the text.',
        maxTokens: 2000,
      );
      if (mounted) {
        setState(() => text.text = '${text.text}${text.text.isEmpty ? '' : '\n'}${r.trim()}');
      }
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => reading = false);
    }
  }

  Future<void> _gen() async {
    final src = text.text.trim();
    if (src.isEmpty) {
      toast(context, t('need_text'));
      return;
    }
    setState(() => busy = true);
    try {
      final r = await Ai.chat(
        'From the notes below, write $count high-quality flashcards (question and short answer) that test the key '
        'concepts, definitions and facts. Use the same language as the notes. Keep answers under 25 words. '
        'Output ONLY a JSON array like [{"q":"...","a":"..."}].\n\nNotes:\n${clip(src, 9000)}',
        system: 'You are an expert tutor who writes effective flashcards.',
        maxTokens: 2200,
        temp: 0.3,
      );
      final out = <_Qa>[];
      for (final e in Ai.jsonList(r)) {
        if (e is! Map) continue;
        final q = (e['q'] ?? '').toString().trim();
        final a = (e['a'] ?? '').toString().trim();
        if (q.isNotEmpty && a.isNotEmpty) out.add(_Qa(q, a));
      }
      if (out.isEmpty) throw AiError(t('bad_ai_format'));
      if (mounted) setState(() => items = out);
    } catch (e) {
      if (mounted) toast(context, errText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final list = [
      for (final i in items)
        if (i.on) CardItem(id: s.newId(), front: i.q, back: i.a, deckId: deckId),
    ];
    if (list.isEmpty) return;
    await s.addCards(list);
    s.bump('lessons');
    Sfx.play('win');
    if (mounted) {
      toast(context, '${t('cards_added')}: ${list.length}');
      setState(() => items = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('lessons'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('lessons_help')),
          const SizedBox(height: 12),
          PixelField(
            controller: text,
            hint: t('lessons_hint'),
            minLines: 6,
            maxLines: 14,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: PixelButton(
                  label: t('camera'),
                  icon: 'camera',
                  small: true,
                  filled: false,
                  busy: reading,
                  expand: true,
                  onTap: () => _photo(true),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: PixelButton(
                  label: t('gallery'),
                  icon: 'folder',
                  small: true,
                  filled: false,
                  expand: true,
                  onTap: reading ? null : () => _photo(false),
                ),
              ),
            ],
          ),
          PixelTitle(t('questions')),
          PixelChips<int>(
            options: const [(10, '10'), (15, '15'), (20, '20')],
            value: count,
            onChanged: (v) => setState(() => count = v),
          ),
          const SizedBox(height: 14),
          PixelButton(
            label: t('make_cards_ai'),
            icon: 'sparkle',
            expand: true,
            busy: busy,
            onTap: _gen,
          ),
          if (items.isNotEmpty) ...[
            PixelTitle(t('move_to_deck')),
            PixelChips<String>(
              options: [for (final d in s.decks) (d.id, deckLabel(d))],
              value: deckId,
              onChanged: (v) => setState(() => deckId = v),
            ),
            const SizedBox(height: 10),
            for (final i in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: PixelBox(
                  padding: const EdgeInsets.all(10),
                  child: pixelCheck(i.on, '${i.q}\n→ ${i.a}', () => setState(() => i.on = !i.on)),
                ),
              ),
            const SizedBox(height: 8),
            PixelButton(
              label: '${t('create_cards')} (${items.where((i) => i.on).length})',
              icon: 'create',
              expand: true,
              onTap: _save,
            ),
          ],
        ],
      ),
    );
  }
}
