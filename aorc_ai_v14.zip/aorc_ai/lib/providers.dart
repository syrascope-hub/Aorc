/// AI provider presets. Every preset except [style] == 'anthropic' speaks the
/// OpenAI-compatible chat API (POST {baseUrl}/chat/completions), so any other
/// compatible service can be used through the "custom" preset.
class AiPreset {
  final String id;
  final String label;
  final String baseUrl;
  final String textModel;
  final String visionModel;
  final bool needsKey;
  final String style; // openai | anthropic
  final String keyHint;
  final String imageProvider; // hf | openai | pollinations | none
  final String imageModel;
  const AiPreset(
    this.id,
    this.label,
    this.baseUrl,
    this.textModel,
    this.visionModel, {
    this.needsKey = true,
    this.style = 'openai',
    this.keyHint = 'API key',
    this.imageProvider = 'pollinations',
    this.imageModel = '',
  });
}

const List<AiPreset> kAiPresets = [
  AiPreset('huggingface', 'Hugging Face', 'https://router.huggingface.co/v1',
      'Qwen/Qwen2.5-72B-Instruct', 'Qwen/Qwen2.5-VL-72B-Instruct',
      keyHint: 'hf_...', imageProvider: 'hf', imageModel: 'black-forest-labs/FLUX.1-schnell'),
  AiPreset('openai', 'OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini', 'gpt-4o-mini',
      keyHint: 'sk-...', imageProvider: 'openai', imageModel: 'dall-e-3'),
  AiPreset('gemini', 'Google Gemini', 'https://generativelanguage.googleapis.com/v1beta/openai',
      'gemini-2.0-flash', 'gemini-2.0-flash',
      keyHint: 'AIza...', imageProvider: 'pollinations'),
  AiPreset('anthropic', 'Anthropic Claude', 'https://api.anthropic.com/v1', 'claude-haiku-5-5',
      'claude-haiku-5-5',
      style: 'anthropic', keyHint: 'sk-ant-...', imageProvider: 'pollinations'),
  AiPreset('openrouter', 'OpenRouter', 'https://openrouter.ai/api/v1', 'openai/gpt-4o-mini',
      'openai/gpt-4o-mini',
      keyHint: 'sk-or-...', imageProvider: 'pollinations'),
  AiPreset('groq', 'Groq', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile',
      'meta-llama/llama-4-scout-17b-16e-instruct',
      keyHint: 'gsk_...', imageProvider: 'pollinations'),
  AiPreset('deepseek', 'DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat', 'deepseek-chat',
      keyHint: 'sk-...', imageProvider: 'pollinations'),
  AiPreset('mistral', 'Mistral', 'https://api.mistral.ai/v1', 'mistral-small-latest',
      'pixtral-12b-2409',
      imageProvider: 'pollinations'),
  AiPreset('together', 'Together AI', 'https://api.together.xyz/v1',
      'meta-llama/Llama-3.3-70B-Instruct-Turbo', 'Qwen/Qwen2.5-VL-72B-Instruct',
      imageProvider: 'openai', imageModel: 'black-forest-labs/FLUX.1-schnell'),
  AiPreset('ollama', 'Ollama / LM Studio (local)', 'http://192.168.1.10:11434/v1', 'llama3.2',
      'llava',
      needsKey: false, imageProvider: 'pollinations'),
  AiPreset('custom', 'Custom (OpenAI-compatible)', '', '', '',
      needsKey: false, imageProvider: 'pollinations'),
];

AiPreset presetById(String id) =>
    kAiPresets.firstWhere((p) => p.id == id, orElse: () => kAiPresets.first);

bool aiNeedsKey(String providerId) => presetById(providerId).needsKey;
