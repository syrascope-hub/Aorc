import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'common.dart';
import 'games2.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

const String _prefix = 'AORC1.';

/// Packs cards into a shareable text code (gzip + base64url).
String encodeChallenge(String name, List<CardItem> cards) {
  final s = AppState.I;
  final j = {
    'n': name,
    'fl': s.frontLang,
    'bl': s.backLang,
    'c': [
      for (final c in cards) [c.front, c.back]
    ],
  };
  final bytes = gzip.encode(utf8.encode(jsonEncode(j)));
  return _prefix + base64Url.encode(bytes).replaceAll('=', '');
}

class ChallengeData {
  final String name;
  final List<CardItem> cards;
  ChallengeData(this.name, this.cards);
}

ChallengeData? decodeChallenge(String raw) {
  try {
    var code = raw.replaceAll(RegExp(r'\s+'), '');
    final at = code.indexOf(_prefix);
    if (at < 0) return null;
    code = code.substring(at + _prefix.length);
    final bytes = gzip.decode(base64Url.decode(base64Url.normalize(code)));
    final j = jsonDecode(utf8.decode(bytes)) as Map;
    final cards = <CardItem>[];
    for (final e in (j['c'] as List)) {
      final p = e as List;
      cards.add(CardItem(id: 'ch${cards.length}', front: p[0].toString(), back: p[1].toString()));
    }
    if (cards.length < 4) return null;
    return ChallengeData((j['n'] ?? '').toString(), cards);
  } catch (_) {
    return null;
  }
}

class ChallengeScreen extends StatefulWidget {
  const ChallengeScreen({super.key});
  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> {
  final name = TextEditingController(text: 'Player');
  final codeIn = TextEditingController();
  int count = 12;
  String? code;

  AppState get s => AppState.I;

  @override
  void dispose() {
    name.dispose();
    codeIn.dispose();
    super.dispose();
  }

  void _create() {
    if (!needCards(context, 4)) return;
    final picked = randomCards(s.scope, count);
    final c = encodeChallenge(name.text.trim().isEmpty ? 'Player' : name.text.trim(), picked);
    Clipboard.setData(ClipboardData(text: c));
    setState(() => code = c);
    toast(context, t('code_copied'));
  }

  void _play(ChallengeData d) {
    pushPage(
      context,
      McqEngine(
        mode: McqMode.fixed,
        pool: d.cards,
        total: d.cards.length > 15 ? 15 : d.cards.length,
        title: '${t('challenge')} · ${d.name}',
        onDone: (r) {
          s.bump('games');
          final line = 'AORC-R · ${name.text.trim().isEmpty ? 'Player' : name.text.trim()}: '
              '${r.score}/${r.total} · ${r.seconds}s';
          Clipboard.setData(ClipboardData(text: line));
          return '$line\n${t('result_copied')}';
        },
      ),
    );
  }

  Future<void> _join() async {
    var raw = codeIn.text;
    if (raw.trim().isEmpty) {
      final d = await Clipboard.getData('text/plain');
      raw = d?.text ?? '';
    }
    final d = decodeChallenge(raw);
    if (d == null) {
      if (mounted) toast(context, t('code_bad'));
      return;
    }
    if (mounted) _play(d);
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(
      title: t('challenge'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('challenge_help')),
          PixelTitle(t('your_name')),
          PixelField(controller: name),
          PixelTitle(t('challenge_create')),
          PixelChips<int>(
            options: const [(8, '8'), (12, '12'), (20, '20')],
            value: count,
            onChanged: (v) => setState(() => count = v),
          ),
          const SizedBox(height: 10),
          PixelButton(
            label: t('make_code'),
            icon: 'bolt',
            expand: true,
            onTap: _create,
          ),
          if (code != null) ...[
            const SizedBox(height: 10),
            PixelBox(
              color: C.creamDeep,
              padding: const EdgeInsets.all(10),
              child: SizedBox(
                width: double.infinity,
                child: Text(code!,
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(height: 8),
            PixelButton(
              label: t('copy'),
              small: true,
              filled: false,
              onTap: () {
                Clipboard.setData(ClipboardData(text: code!));
                toast(context, t('code_copied'));
              },
            ),
          ],
          PixelTitle(t('challenge_join')),
          PixelField(controller: codeIn, hint: t('paste_code'), minLines: 2, maxLines: 4),
          const SizedBox(height: 10),
          PixelButton(
            label: t('play_challenge'),
            icon: 'games',
            expand: true,
            filled: false,
            onTap: _join,
          ),
        ],
      ),
    );
  }
}
