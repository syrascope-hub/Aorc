import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

class _Drop {
  final CardItem card;
  final double x; // 0..1 horizontal position
  double y = 0; // 0..1 fall progress
  _Drop(this.card, this.x);
}

/// Translations fall from the top; type the word before they reach the ground.
class WordRainGame extends StatefulWidget {
  const WordRainGame({super.key});
  @override
  State<WordRainGame> createState() => _WordRainGameState();
}

class _WordRainGameState extends State<WordRainGame> {
  final _r = Random();
  final input = TextEditingController();
  final focus = FocusNode();
  final List<_Drop> drops = [];
  Timer? _tick;
  int lives = 3, score = 0;
  double sinceSpawn = 99;
  double elapsed = 0;
  bool over = false;
  String? extra;

  AppState get s => AppState.I;

  @override
  void initState() {
    super.initState();
    _begin();
  }

  @override
  void dispose() {
    _tick?.cancel();
    input.dispose();
    focus.dispose();
    super.dispose();
  }

  void _begin() {
    drops.clear();
    lives = 3;
    score = 0;
    sinceSpawn = 99;
    elapsed = 0;
    over = false;
    extra = null;
    input.clear();
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(milliseconds: 50), (_) => _step());
  }

  void _step() {
    if (!mounted || over) return;
    const dt = 0.05;
    elapsed += dt;
    sinceSpawn += dt;
    final speed = 0.075 + min(0.12, score * 0.004); // fraction of height per second
    final every = max(1.1, 2.6 - score * 0.05);
    bool lost = false;
    setState(() {
      if (sinceSpawn >= every) {
        sinceSpawn = 0;
        final pool = s.scope.where((c) => !drops.any((d) => d.card.id == c.id)).toList();
        if (pool.isNotEmpty) {
          final c = pool[_r.nextInt(pool.length)];
          drops.add(_Drop(c, 0.05 + _r.nextDouble() * 0.6));
        }
      }
      for (final d in drops) {
        d.y += speed * dt;
      }
      final hit = drops.where((d) => d.y >= 1).toList();
      if (hit.isNotEmpty) {
        drops.removeWhere((d) => d.y >= 1);
        lives -= hit.length;
        Sfx.play('bad');
        if (lives <= 0) lost = true;
      }
    });
    if (lost) _finish();
  }

  void _onChanged(String v) {
    final n = normText(v);
    if (n.isEmpty) return;
    for (final d in drops) {
      if (normText(d.card.front) == n) {
        setState(() {
          drops.remove(d);
          score++;
        });
        input.clear();
        Sfx.play('ok');
        return;
      }
    }
  }

  void _finish() {
    _tick?.cancel();
    final prev = s.stat['rain_best'] ?? 0;
    final coins = score ~/ 2;
    s.bumpMax('rain_best', score);
    s.bump('games');
    if (coins > 0) s.addCoins(coins);
    Sfx.play('win');
    setState(() {
      over = true;
      extra = '${score > prev ? '${t('new_record')}\n' : ''}${t('best')}: ${max(prev, score)} · +$coins ${t('coins')}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return PixelPage(games: true, title: t('g_rain'), child: over ? _result() : _body());
  }

  Widget _result() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Sprite('robot', px: 8),
            const SizedBox(height: 16),
            tx(t('game_over'), size: 22, bold: true),
            const SizedBox(height: 8),
            tx('${t('score')}: $score', size: 18, bold: true),
            if (extra != null) ...[
              const SizedBox(height: 8),
              tx(extra!, size: 14, bold: true, align: TextAlign.center, height: 1.5),
            ],
            const SizedBox(height: 20),
            PixelButton(label: t('play_again'), icon: 'games', onTap: () => setState(_begin)),
            const SizedBox(height: 10),
            PixelButton(
                label: t('back'), filled: false, onTap: () => Navigator.of(context).maybePop()),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 6),
          child: Row(
            children: [
              for (int i = 0; i < 3; i++)
                Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Sprite('heart', px: 3, tint: i < lives ? C.ink : C.light),
                ),
              const Spacer(),
              tx('${t('score')}: $score', bold: true, size: 15),
            ],
          ),
        ),
        Expanded(
          child: LayoutBuilder(
            builder: (context, bc) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: C.white,
                  border: Border.all(color: C.ink, width: 3),
                ),
                child: Stack(
                  clipBehavior: Clip.hardEdge,
                  children: [
                    for (final d in drops)
                      Positioned(
                        left: d.x * (bc.maxWidth - 28 - 150),
                        top: d.y * (bc.maxHeight - 40),
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 150),
                          child: PixelBox(
                            u: 2,
                            shadow: false,
                            color: C.cream,
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: Text(d.card.back,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(height: 4, color: C.ink),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
          child: PixelField(
            controller: input,
            hint: t('rain_type'),
            dir: s.frontLang.startsWith('ar') ? TextDirection.rtl : TextDirection.ltr,
            onChanged: _onChanged,
          ),
        ),
      ],
    );
  }
}
