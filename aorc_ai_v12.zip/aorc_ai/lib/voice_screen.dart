import 'package:flutter/material.dart';

import 'common.dart';
import 'piper.dart';
import 'tts_engines.dart';
import 'progress.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

/// Voice test + settings: gender, offline neural voices, device voices, diagnostics.
class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});
  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  AppState get s => AppState.I;

  final Map<String, double> prog = {};
  final Map<String, String> phase = {};
  final Map<String, String> err = {};
  final Map<String, VoiceResult> results = {};
  List<Map<String, String>> sysVoices = [];
  String sysInfo = '';
  List<String> engines = [];
  bool testing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    Speech.stop();
    super.dispose();
  }

  Future<void> _load() async {
    await Speech.init();
    await Piper.refresh();
    final v = await Speech.systemVoices(s.frontLang);
    final i = await Speech.systemInfo(s.frontLang);
    final e = await Speech.systemEngines();
    if (!mounted) return;
    setState(() {
      sysVoices = v;
      sysInfo = i;
      engines = e;
    });
  }

  void _setGender(String g) {
    setState(() => s.voiceGender = g);
    s.saveSettings();
    Speech.invalidate();
    Speech.speak(Speech.samplePhrase(s.frontLang), s.frontLang);
  }

  Future<void> _download(PiperVoice v) async {
    setState(() {
      prog[v.id] = 0;
      phase[v.id] = 'download';
      err.remove(v.id);
    });
    try {
      await Piper.download(v, (p, ph) {
        if (mounted) {
          setState(() {
            prog[v.id] = p;
            phase[v.id] = ph;
          });
        }
      });
    } catch (e) {
      final m = e.toString();
      err[v.id] = m.length > 140 ? m.substring(0, 140) : m;
    }
    Speech.invalidate();
    if (mounted) setState(() => prog.remove(v.id));
  }

  Future<void> _remove(PiperVoice v) async {
    await Piper.delete(v);
    Speech.invalidate();
    if (mounted) setState(() {});
  }

  Future<void> _tryPiper(PiperVoice v) async {
    final r = await Speech.testVoice(v);
    if (!mounted) return;
    toast(context, r.ok ? '✓ ${v.name}' : '✗ ${r.detail}');
  }

  Future<void> _runAll() async {
    setState(() {
      testing = true;
      results.clear();
    });
    final code = s.frontLang.split('-').first;
    for (final e in kTtsTestAll) {
      if (!mounted) return;
      if (e == 'piper' && Piper.pick(code, s.voiceGender) == null) {
        results[e] = VoiceResult(false, t('voice_skip_piper'));
        setState(() {});
        continue;
      }
      final r = await Speech.test(e, s.frontLang);
      results[e] = r;
      if (mounted) setState(() {});
      await Future<void>.delayed(const Duration(milliseconds: 1800));
    }
    if (mounted) setState(() => testing = false);
  }

  Future<void> _useGoogleEngine() async {
    final list = await Speech.systemEngines();
    const pkg = 'com.google.android.tts';
    if (!list.contains(pkg)) {
      if (mounted) toast(context, t('voice_google_missing'));
      return;
    }
    await Speech.useEngine(pkg);
    await _load();
    if (mounted) toast(context, t('voice_engine_set'));
  }

  Future<void> _pickSysVoice(String name) async {
    setState(() => s.sysVoice = name);
    await s.saveSettings();
    Speech.invalidate();
    await Speech.test('system', s.frontLang);
  }

  @override
  Widget build(BuildContext context) {
    final codes = <String>{s.frontLang.split('-').first, s.backLang.split('-').first};
    return PixelPage(
      title: t('voice_screen'),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          infoBox(t('voice_help')),
          PixelTitle(t('voice_gender')),
          PixelChips<String>(
            options: [('f', t('voice_female')), ('m', t('voice_male'))],
            value: s.voiceGender,
            onChanged: _setGender,
          ),
          const SizedBox(height: 6),
          tx(t('voice_gender_note'), size: 12, color: C.dark, height: 1.4),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: PixelButton(
                label: langName(s.frontLang),
                icon: 'speaker',
                small: true,
                filled: false,
                onTap: () => Speech.speak(Speech.samplePhrase(s.frontLang), s.frontLang),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PixelButton(
                label: langName(s.backLang),
                icon: 'speaker',
                small: true,
                filled: false,
                onTap: () => Speech.speak(Speech.samplePhrase(s.backLang), s.backLang),
              ),
            ),
          ]),
          PixelTitle(t('voice_offline')),
          for (final c in codes) ..._piperBlock(c),
          PixelTitle(t('voice_system')),
          _systemBlock(),
          PixelTitle(t('voice_run_all')),
          PixelButton(
            label: testing ? t('voice_testing') : t('voice_run_all'),
            icon: 'check',
            expand: true,
            busy: testing,
            onTap: testing ? null : _runAll,
          ),
          const SizedBox(height: 10),
          for (final e in kTtsTestAll)
            if (results[e] != null) _resultRow(e, results[e]!),
          if (results.isNotEmpty) ...[
            const SizedBox(height: 6),
            tx(t('voice_heard'), size: 12, color: C.dark, height: 1.4),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  List<Widget> _piperBlock(String code) {
    final list = Piper.forLang(code);
    final out = <Widget>[
      Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: tx(langName(kLangs.firstWhere((l) => l.code.startsWith('$code-'), orElse: () => kLangs.first).code),
            bold: true, size: 13),
      ),
    ];
    if (list.isEmpty) {
      out.add(tx(t('voice_no_piper'), size: 12.5, color: C.dark));
      out.add(const SizedBox(height: 10));
      return out;
    }
    for (final v in list) {
      final inst = Piper.installed(v);
      final busy = prog.containsKey(v.id);
      out.add(Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: PixelBox(
          child: SizedBox(
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Expanded(
                    child: tx('${v.name} · ${v.gender == 'f' ? t('voice_female') : t('voice_male')}',
                        bold: true, size: 14),
                  ),
                  tx(inst ? t('voice_installed') : '~${v.mb} ${t('voice_mb')}', size: 12, color: C.gray),
                ]),
                const SizedBox(height: 8),
                if (busy) ...[
                  PixelBar(value: prog[v.id] ?? 0, segs: 14, height: 10),
                  const SizedBox(height: 4),
                  tx(t('voice_phase_${phase[v.id] ?? 'download'}'), size: 12, color: C.gray),
                ] else
                  Row(children: [
                    if (inst) ...[
                      Expanded(
                        child: PixelButton(
                            label: t('voice_try'), small: true, onTap: () => _tryPiper(v)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: PixelButton(
                            label: t('voice_delete'),
                            small: true,
                            filled: false,
                            onTap: () => _remove(v)),
                      ),
                    ] else
                      Expanded(
                        child: PixelButton(
                            label: t('voice_download'), small: true, onTap: () => _download(v)),
                      ),
                  ]),
                if (err[v.id] != null) ...[
                  const SizedBox(height: 6),
                  tx(err[v.id]!, size: 12, color: C.dark),
                ],
              ],
            ),
          ),
        ),
      ));
    }
    return out;
  }

  Widget _systemBlock() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (sysInfo.isNotEmpty)
          PixelBox(
            color: C.creamDeep,
            child: SizedBox(width: double.infinity, child: tx(sysInfo, size: 11.5, height: 1.5)),
          ),
        const SizedBox(height: 10),
        if (engines.contains('com.google.android.tts'))
          PixelButton(
            label: t('voice_use_google_engine'),
            small: true,
            filled: false,
            expand: true,
            onTap: _useGoogleEngine,
          ),
        const SizedBox(height: 10),
        if (sysVoices.isEmpty)
          tx(t('voice_none_installed'), size: 12.5, color: C.dark)
        else
          PixelChips<String>(
            options: [
              ('', t('voice_auto')),
              for (final v in sysVoices.take(14))
                (
                  v['name']!,
                  '${v['gender'] == 'f' ? '♀ ' : v['gender'] == 'm' ? '♂ ' : ''}${v['name']!.split('#').first}'
                ),
            ],
            value: s.sysVoice,
            onChanged: _pickSysVoice,
          ),
      ],
    );
  }

  Widget _resultRow(String e, VoiceResult r) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: PixelBox(
        child: SizedBox(
          width: double.infinity,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              tx(r.ok ? '✓' : '✗', bold: true, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    tx(t('voice_name_$e'), bold: true, size: 14),
                    const SizedBox(height: 2),
                    tx(r.detail, size: 12, color: C.dark, height: 1.35),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
