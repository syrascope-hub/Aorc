"""CI guard: every speech engine must be wired end to end.

Checks (run from the Flutter project root, after tools/patch_manifest.py):
  - each id in kTtsEngines has engine_<id> (+ _note for non-auto) and
    badge_<id> strings in both languages (badge/name only for engines that speak)
  - each non-auto, non-system engine has a `case '<id>':` in speech.dart `_get`
  - the ResponsiveVoice key in tts_engines.dart is the expected one
  - the patched AndroidManifest allows INTERNET and queries TTS_SERVICE
Exits non-zero with ::error:: lines so the workflow stops before building.
"""
import re
import sys
from pathlib import Path

EXPECTED_RV_KEY = "qlpAd0be"
errors = []

reg = Path("lib/tts_engines.dart").read_text(encoding="utf-8")
ids = re.findall(r"TtsEngine\('([a-z_]+)'", reg)
if not ids:
    errors.append("no engines found in lib/tts_engines.dart")

strings = Path("lib/strings.dart").read_text(encoding="utf-8") + Path("lib/strings_voice.dart").read_text(encoding="utf-8")
speech = Path("lib/speech.dart").read_text(encoding="utf-8")

for i in ids:
    need = [f"'engine_{i}'"]
    if i != "auto":
        need += [f"'engine_{i}_note'", f"'badge_{i}'"]
    for key in need:
        n = strings.count(key + ":")
        if n < 2:
            errors.append(f"string {key} is defined {n}x (needs ar + en)")
    if i not in ("auto", "system") and f"case '{i}':" not in speech and i != "online":
        errors.append(f"engine '{i}' has no case in Speech._get")

m = re.search(r"kResponsiveVoiceKey\s*=\s*'([^']*)'", reg)
if not m or m.group(1) != EXPECTED_RV_KEY:
    errors.append("ResponsiveVoice key is missing or changed in lib/tts_engines.dart")

manifest = Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    xml = manifest.read_text(encoding="utf-8")
    for token in ("android.permission.INTERNET", "android.intent.action.TTS_SERVICE", "android.speech.RecognitionService"):
        if token not in xml:
            errors.append(f"AndroidManifest.xml is missing {token}")
else:
    errors.append("AndroidManifest.xml not found (run patch_manifest first)")

for e in errors:
    print("::error::" + e)
if errors:
    sys.exit(1)
print("Engines OK:", ", ".join(ids))
