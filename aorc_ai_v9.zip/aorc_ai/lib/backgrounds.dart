import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'common.dart';
import 'services.dart';
import 'state.dart';
import 'strings.dart';
import 'theme.dart';

// ───────────────────────── Background catalogue ─────────────────────────

class BgDef {
  final String id;
  final String ar;
  final String en;
  final int price;
  final int needStreak; // best streak that unlocks it for free (0 = none)
  final int needReviews; // total reviews that unlock it for free (0 = none)
  const BgDef(this.id, this.ar, this.en, this.price, {this.needStreak = 0, this.needReviews = 0});
  String get name => AppState.I.uiLang == 'ar' ? ar : en;

  bool unlocked(AppState s) =>
      (needStreak > 0 && s.bestStreak >= needStreak) ||
      (needReviews > 0 && s.totalReviews >= needReviews);

  String? hint() {
    if (needStreak > 0) return t('bg_unlock_streak').replaceAll('{n}', '$needStreak');
    if (needReviews > 0) return t('bg_unlock_reviews').replaceAll('{n}', '$needReviews');
    return null;
  }
}

const List<BgDef> kBgs = [
  BgDef('none', 'بدون خلفية', 'No background', 0),
  BgDef('forest', 'غابة', 'Forest', 0),
  BgDef('sakura', 'ساكورا', 'Sakura', 40, needStreak: 7),
  BgDef('sea', 'تحت الماء', 'Underwater', 60),
  BgDef('desert', 'صحراء', 'Desert', 60, needReviews: 100),
  BgDef('snow', 'جبال ثلجية', 'Snowy peaks', 70, needStreak: 14),
  BgDef('city', 'مدينة ليلية', 'Night city', 80),
  BgDef('neon', 'نيون', 'Synthwave', 90),
  BgDef('space', 'فضاء', 'Space', 100, needReviews: 500),
];

// ───────────────────────── Widgets ─────────────────────────

/// Paints [child] over an animated pixel scene. With id 'none' it is a plain
/// page-colored box. A translucent veil keeps text readable.
class BgBackdrop extends StatelessWidget {
  final String id;
  final double extra; // added on top of the user's veil setting
  final Widget child;
  const BgBackdrop({super.key, required this.id, required this.child, this.extra = 0});

  @override
  Widget build(BuildContext context) {
    if (id == 'none') return ColoredBox(color: C.cream, child: child);
    final veil = (AppState.I.bgVeil + extra).clamp(0.0, 0.92);
    return Stack(
      children: [
        Positioned.fill(child: BgScene(id: id)),
        Positioned.fill(
          child: IgnorePointer(
            child: ColoredBox(color: C.cream.withAlpha((veil * 255).round().clamp(0, 255))),
          ),
        ),
        Positioned.fill(child: child),
      ],
    );
  }
}

/// The animated scene itself (no veil). Redraws at ~12 fps for a pixel-art feel.
class BgScene extends StatefulWidget {
  final String id;
  const BgScene({super.key, required this.id});

  @override
  State<BgScene> createState() => _BgSceneState();
}

class _BgSceneState extends State<BgScene> with SingleTickerProviderStateMixin {
  late final Ticker _tk;
  final ValueNotifier<double> _t = ValueNotifier<double>(0);
  double _last = -1;

  @override
  void initState() {
    super.initState();
    _tk = createTicker((d) {
      final s = d.inMicroseconds / 1000000.0;
      if (s - _last >= 1 / 12) {
        _last = s;
        _t.value = s;
      }
    });
    if (AppState.I.bgMotion) _tk.start();
  }

  @override
  void dispose() {
    _tk.dispose();
    _t.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final motion = AppState.I.bgMotion;
    if (motion && !_tk.isActive) {
      _tk.start();
    } else if (!motion && _tk.isActive) {
      _tk.stop();
      _last = -1;
    }
    return RepaintBoundary(
      child: CustomPaint(
        size: Size.infinite,
        painter: _ScenePainter(widget.id, _t, AppState.I.bgWeather, motion),
      ),
    );
  }
}

// ───────────────────────── Painter helpers ─────────────────────────

int _h(int n) {
  var x = n * 374761393 + 668265263;
  x = (x ^ (x >> 13)) * 1274126177;
  return (x ^ (x >> 16)) & 0x7fffffff;
}

double _rf(int n) => (_h(n) % 1000) / 1000.0;

Color _c(int v) => Color(v);

Color _mix(Color a, Color b, double t) => Color.lerp(a, b, t.clamp(0.0, 1.0))!;

/// Darkens a color at night.
Color _nt(Color c, double night) => _mix(c, const Color(0xFF0A0F24), night * 0.6);

class _G {
  final Canvas c;
  final double cell;
  final int cols;
  final int rows;
  final Paint _p = Paint()..isAntiAlias = false;
  _G(this.c, this.cell, this.cols, this.rows);

  void r(num x, num y, num w, num h, Color col) {
    _p.color = col;
    c.drawRect(
      Rect.fromLTWH(x.floor() * cell, y.floor() * cell, w.toDouble() * cell + 0.5,
          h.toDouble() * cell + 0.5),
      _p,
    );
  }

  void disc(int cx, int cy, int rad, Color col) {
    for (int dy = -rad; dy <= rad; dy++) {
      final w = sqrt((rad * rad - dy * dy).toDouble()).round();
      r(cx - w, cy + dy, w * 2 + 1, 1, col);
    }
  }

  void sky(Color top, Color bot) {
    final bands = rows ~/ 2 + 1;
    for (int i = 0; i < bands; i++) {
      r(0, i * 2, cols, 2, _mix(top, bot, bands <= 1 ? 0 : i / (bands - 1)));
    }
  }

  /// Draws items spaced [spacing] apart that scroll left by [t]*[speed].
  void scroll(double t, double speed, int spacing, void Function(int i, double x) draw) {
    final off = t * speed;
    final first = (off / spacing).floor() - 1;
    final last = first + cols ~/ spacing + 3;
    for (int i = first; i <= last; i++) {
      draw(i, i * spacing - off);
    }
  }

  void hills(double t, double speed, int base, double amp, double freq, double phase, Color col,
      {Color? edge}) {
    for (int x = 0; x < cols; x++) {
      final xx = x + t * speed;
      final y = base +
          (sin(xx * freq + phase) * amp + sin(xx * freq * 2.3 + phase * 1.7) * amp * 0.4).round();
      if (edge != null) r(x, y, 1, 1, edge);
      r(x, edge != null ? y + 1 : y, 1, rows - y, col);
    }
  }
}

class _Sky {
  final Color top;
  final Color bot;
  final double night;
  const _Sky(this.top, this.bot, this.night);
}

const List<(double, int, int, double)> _skyKeys = [
  (0.0, 0xFF0B1030, 0xFF1B2250, 1.0),
  (5.0, 0xFF0B1030, 0xFF1B2250, 1.0),
  (6.5, 0xFF5B6FB5, 0xFFF4A77A, 0.4),
  (8.5, 0xFF5EB8F0, 0xFFBFE6FF, 0.0),
  (16.0, 0xFF5EB8F0, 0xFFBFE6FF, 0.0),
  (18.0, 0xFF6A5FB0, 0xFFFF9A5C, 0.3),
  (19.5, 0xFF1B1A45, 0xFF4A3A78, 0.9),
  (24.0, 0xFF0B1030, 0xFF1B2250, 1.0),
];

_Sky _skyAt(double h) {
  for (int i = 0; i < _skyKeys.length - 1; i++) {
    final a = _skyKeys[i];
    final b = _skyKeys[i + 1];
    if (h >= a.$1 && h <= b.$1) {
      final f = (h - a.$1) / (b.$1 - a.$1);
      return _Sky(_mix(_c(a.$2), _c(b.$2), f), _mix(_c(a.$3), _c(b.$3), f),
          a.$4 + (b.$4 - a.$4) * f);
    }
  }
  return const _Sky(Color(0xFF0B1030), Color(0xFF1B2250), 1);
}

void _stars(_G g, double t, double night, int count, int maxY, {double drift = 0}) {
  if (night < 0.15) return;
  for (int i = 0; i < count; i++) {
    final x = ((_rf(i) * g.cols - t * drift) % g.cols + g.cols) % g.cols;
    final y = _rf(i + 500) * maxY;
    final tw = sin(t * 2 + i * 1.7);
    final big = i % 9 == 0;
    final col = tw > 0.3 ? const Color(0xFFFFFFFF) : const Color(0xFF9DA7D8);
    if (night > 0.5 || i % 2 == 0) {
      g.r(x, y, big ? 2 : 1, big ? 2 : 1, col);
    }
  }
}

void _celestial(_G g, double h, int horizon) {
  final isDay = h >= 5.5 && h < 18.5;
  final p = isDay ? (h - 5.5) / 13.0 : (((h < 5.5 ? h + 24 : h) - 18.5) / 11.0);
  final cx = (g.cols * (0.08 + 0.84 * p)).round();
  final cy = (horizon - sin(pi * p) * g.rows * 0.42).round();
  if (isDay) {
    g.disc(cx, cy, 7, const Color(0x55FFF3A0));
    g.disc(cx, cy, 5, const Color(0xFFFFE066));
    g.disc(cx - 1, cy - 1, 3, const Color(0xFFFFF4B0));
  } else {
    g.disc(cx, cy, 5, const Color(0xFFF4F1DE));
    g.r(cx + 1, cy - 2, 2, 2, const Color(0xFFD8D4BC));
    g.r(cx - 3, cy + 1, 2, 2, const Color(0xFFD8D4BC));
  }
}

void _clouds(_G g, double t, double night, int count, int yBase, {double speed = 1.4}) {
  final col = _mix(const Color(0xFFFFFFFF), const Color(0xFF3A4068), night);
  for (int i = 0; i < count; i++) {
    final w = 9 + (_h(i) % 8);
    final span = g.cols + 30;
    final x = ((_rf(i + 40) * span + t * (speed + _rf(i + 9) * 1.6)) % span) - 15;
    final y = yBase + (_rf(i + 3) * 8).floor();
    g.r(x + 2, y, w - 4, 1, col);
    g.r(x, y + 1, w, 2, col);
    g.r(x + 3, y - 1, w - 8 < 2 ? 2 : w - 8, 1, col);
  }
}

void _pine(_G g, double x, int baseY, int ht, Color col, Color trunk) {
  final xi = x.floor();
  g.r(xi, baseY - 2, 1, 2, trunk);
  for (int row = 0; row < ht; row++) {
    final w = (row * 5 ~/ ht) * 2 + 1;
    g.r(xi - w ~/ 2, baseY - 2 - ht + row, w, 1, col);
  }
}

// ───────────────────────── Scene painter ─────────────────────────

class _ScenePainter extends CustomPainter {
  final String id;
  final ValueNotifier<double> time;
  final String weather;
  final bool motion;
  _ScenePainter(this.id, this.time, this.weather, this.motion) : super(repaint: time);

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    const cols = 90;
    final cell = size.width / cols;
    final rows = (size.height / cell).ceil() + 1;
    final g = _G(canvas, cell, cols, rows);
    final t = time.value;
    final now = DateTime.now();
    final hour = now.hour + now.minute / 60.0;
    switch (id) {
      case 'forest':
        _forest(g, t, hour);
        break;
      case 'sakura':
        _sakura(g, t, hour);
        break;
      case 'sea':
        _sea(g, t, hour);
        break;
      case 'desert':
        _desert(g, t, hour);
        break;
      case 'city':
        _city(g, t);
        break;
      case 'snow':
        _snow(g, t, hour);
        break;
      case 'neon':
        _neon(g, t);
        break;
      case 'space':
        _space(g, t);
        break;
    }
    _weather(g, t);
  }

  @override
  bool shouldRepaint(covariant _ScenePainter old) =>
      old.id != id || old.weather != weather || old.motion != motion;

  // ── weather overlay ──
  void _weather(_G g, double t) {
    switch (weather) {
      case 'rain':
        g.r(0, 0, g.cols, g.rows, const Color(0x2A101830));
        for (int i = 0; i < 80; i++) {
          final y = (t * 45 + _rf(i + 300) * g.rows) % g.rows;
          final x = ((_rf(i + 400) * g.cols - y * 0.25) % g.cols + g.cols) % g.cols;
          g.r(x, y, 1, 2, const Color(0xAA9EC9FF));
        }
        if (t % 9 < 0.17) g.r(0, 0, g.cols, g.rows, const Color(0x40FFFFFF));
        break;
      case 'snow':
        for (int i = 0; i < 70; i++) {
          final y = (t * (4 + _rf(i + 50) * 4) + _rf(i + 300) * g.rows) % g.rows;
          final x = ((_rf(i + 400) * g.cols + sin(t * 0.9 + i) * 3) % g.cols + g.cols) % g.cols;
          final big = i % 5 == 0;
          g.r(x, y, big ? 2 : 1, big ? 2 : 1, const Color(0xEEFFFFFF));
        }
        break;
      case 'fog':
        g.r(0, 0, g.cols, g.rows, const Color(0x22FFFFFF));
        for (int i = 0; i < 7; i++) {
          final w = 40 + (_h(i) % 30);
          final span = g.cols + w;
          final x = ((_rf(i + 7) * span + t * (1 + i % 3)) % span) - w;
          g.r(x, g.rows * (0.3 + i * 0.09), w, 3, const Color(0x26FFFFFF));
        }
        break;
    }
  }

  // ── snowy peaks ──
  void _snow(_G g, double t, double hour) {
    final s = _skyAt(hour);
    final n = s.night;
    final hz = (g.rows * 0.58).round();
    g.sky(_mix(s.top, _c(0xFF9FB8E8), 0.2), _mix(s.bot, _c(0xFFE8F0FF), 0.4));
    _stars(g, t, n, 60, hz - 4);
    _celestial(g, hour, hz);
    if (n > 0.5) {
      for (int x = 0; x < g.cols; x++) {
        final y = g.rows * 0.18 + sin(x * 0.08 + t * 0.5) * 5 + sin(x * 0.17 - t * 0.3) * 2;
        final col = _mix(const Color(0xFF4CFFB0), const Color(0xFF9D5CFF), x / g.cols);
        for (int k = 0; k < 10; k++) {
          g.r(x, y + k, 1, 1, col.withAlpha(((1 - k / 10) * 90 * (n - 0.4)).round().clamp(0, 255)));
        }
      }
    }
    _clouds(g, t, n, 3, 6, speed: 0.9);
    void peaks(double speed, int spacing, int base, Color rock, int seed) {
      g.scroll(t, speed, spacing, (i, x) {
        final ht = base + _h(i + seed) % 8;
        for (int row = 0; row < ht; row++) {
          final half = row;
          final col = row < ht * 0.35 ? _nt(_c(0xFFF4F8FF), n) : rock;
          g.r(x - half, hz - ht + row + 2, half * 2 + 1, 1, col);
        }
      });
    }

    peaks(0.5, 46, (g.rows * 0.26).round(), _nt(_c(0xFF8FA3C8), n), 1);
    peaks(1.1, 34, (g.rows * 0.18).round(), _nt(_c(0xFF6E86B3), n), 9);
    g.hills(t, 1.8, hz + 4, 3, 0.12, 1.0, _nt(_c(0xFFEAF2FF), n), edge: _nt(_c(0xFFFFFFFF), n));
    final pineC = _nt(_c(0xFF2F5D50), n);
    final trunk = _nt(_c(0xFF4A3426), n);
    g.scroll(t, 2.6, 13, (i, x) {
      final ht = 7 + _h(i) % 4;
      final xi = (x + _h(i + 3) % 4).floor();
      final base = hz + 10;
      g.r(xi, base - 2, 1, 2, trunk);
      for (int row = 0; row < ht; row++) {
        final w = (row * 5 ~/ ht) * 2 + 1;
        g.r(xi - w ~/ 2, base - 2 - ht + row, w, 1, pineC);
        if (row % 3 == 0) g.r(xi - w ~/ 2, base - 2 - ht + row, w, 1, _nt(_c(0xFFF4F8FF), n));
      }
    });
    final gy = g.rows - 8;
    g.r(0, gy, g.cols, 8, _nt(_c(0xFFE4EEFF), n));
    g.r(0, gy, g.cols, 1, _nt(_c(0xFFFFFFFF), n));
    g.scroll(t, 5.0, 8, (i, x) {
      if (_h(i) % 3 == 0) g.r(x, gy + 2 + _h(i + 1) % 4, 3, 1, _nt(_c(0xFFC6D6F2), n));
    });
    // cabin with chimney smoke
    g.scroll(t, 5.0, 70, (i, x) {
      if (_h(i + 4) % 2 != 0) return;
      final cy = gy;
      g.r(x, cy - 8, 14, 8, _nt(_c(0xFF7A4B2A), n));
      for (int row = 0; row < 5; row++) {
        final w = 6 + row * 2;
        g.r(x + 7 - w ~/ 2, cy - 13 + row, w, 1, _nt(_c(0xFFFFFFFF), n));
      }
      g.r(x + 9, cy - 16, 2, 4, _nt(_c(0xFF5A3A22), n));
      g.r(x + 2, cy - 6, 3, 3, n > 0.3 ? _c(0xFFFFD66B) : _nt(_c(0xFFBFE6FF), n));
      g.r(x + 8, cy - 5, 3, 5, _nt(_c(0xFF4A2A15), n));
      for (int k = 0; k < 5; k++) {
        final sy = cy - 17 - ((t * 4 + k * 3) % 14);
        g.r(x + 9 + sin(t + k) * 1.5, sy, 2, 1, _c(0x66FFFFFF));
      }
    });
  }

  // ── synthwave ──
  void _neon(_G g, double t) {
    final hz = (g.rows * 0.55).round();
    g.sky(_c(0xFF14043A), _c(0xFFFF3E9D));
    _stars(g, t, 1.0, 40, (hz * 0.6).round());
    final cx = g.cols ~/ 2;
    final rad = (g.cols * 0.2).round();
    final cy = hz - rad ~/ 2;
    for (int dy = -rad; dy <= rad; dy++) {
      if (dy > 2 && dy % 5 < dy ~/ 5) continue;
      final w = sqrt((rad * rad - dy * dy).toDouble()).round();
      g.r(cx - w, cy + dy, w * 2 + 1, 1,
          _mix(const Color(0xFFFFE259), const Color(0xFFFF2E93), (dy + rad) / (rad * 2)));
    }
    g.hills(t, 1.0, hz - 3, 5, 0.1, 1.0, _c(0xFF2B0A4F), edge: _c(0xFFFF3E9D));
    // floor
    g.r(0, hz, g.cols, g.rows - hz, _c(0xFF12002B));
    g.r(0, hz, g.cols, 1, _c(0xFFFF3E9D));
    final span = g.rows - hz;
    for (int k = 0; k < 12; k++) {
      final f = ((k + t * 0.7) % 12) / 12;
      g.r(0, hz + f * f * span, g.cols, 1, _mix(const Color(0xFF7A1FA2), const Color(0xFFFF3E9D), f));
    }
    for (int j = -9; j <= 9; j++) {
      for (int y = hz + 1; y < g.rows; y++) {
        final f = (y - hz) / span;
        g.r(cx + j * (2 + f * 11), y, 1, 1, _mix(const Color(0xFF3A1170), const Color(0xFF2EE6FF), f));
      }
    }
    // drifting neon car
    final carX = ((t * 10) % (g.cols + 40)) - 20;
    final carY = hz + span * 0.35;
    g.r(carX, carY, 9, 2, _c(0xFF2EE6FF));
    g.r(carX + 2, carY - 2, 5, 2, _c(0xFF2EE6FF));
    g.r(carX + 3, carY - 1, 3, 1, _c(0xFF12002B));
    g.r(carX - 2, carY, 2, 1, _c(0x99FF3E9D));
  }

  // ── forest ──
  void _forest(_G g, double t, double hour) {
    final s = _skyAt(hour);
    final n = s.night;
    final hz = (g.rows * 0.6).round();
    g.sky(s.top, s.bot);
    _stars(g, t, n, 45, hz - 4);
    _celestial(g, hour, hz);
    _clouds(g, t, n, 5, 4);
    g.hills(t, 0.5, hz - 6, 5, 0.09, 0.0, _nt(_c(0xFF5E9E8F), n));
    g.hills(t, 1.2, hz, 4, 0.12, 2.0, _nt(_c(0xFF2F7A5B), n));
    final tree = _nt(_c(0xFF1E5A3A), n);
    final trunk = _nt(_c(0xFF5A3A22), n);
    g.scroll(t, 2.0, 11, (i, x) {
      final ht = 7 + _h(i) % 4;
      _pine(g, x + (_h(i + 7) % 5), hz + 4, ht, tree, trunk);
    });
    final gy = g.rows - 8;
    g.r(0, gy, g.cols, 8, _nt(_c(0xFF2D5A27), n));
    g.r(0, gy, g.cols, 1, _nt(_c(0xFF4C9A3A), n));
    g.scroll(t, 4.0, 7, (i, x) {
      if (_h(i + 99) % 3 == 0) g.r(x, gy - 1, 1, 1, _nt(_c(0xFF4C9A3A), n));
      if (_h(i + 5) % 5 == 0) g.r(x + 2, gy + 2, 1, 1, _c(0xFFF4D35E));
    });
    final big = _nt(_c(0xFF123D26), n);
    g.scroll(t, 6.0, 31, (i, x) {
      final ht = 16 + _h(i + 3) % 5;
      _pine(g, x, g.rows - 4, ht, big, trunk);
    });
    if (n > 0.3) {
      for (int i = 0; i < 14; i++) {
        if (sin(t * 3 + i * 2.1) > 0) {
          final x = _rf(i + 70) * g.cols + sin(t * 0.7 + i) * 3;
          final y = hz + 2 + _rf(i + 90) * (g.rows - hz - 6) + cos(t * 0.9 + i) * 2;
          g.r(x, y, 1, 1, _c(0xFFFFF176));
        }
      }
    }
  }

  // ── sakura ──
  void _sakura(_G g, double t, double hour) {
    final s = _skyAt(hour);
    final n = s.night;
    final hz = (g.rows * 0.58).round();
    g.sky(_mix(s.top, _c(0xFFFFB3C7), 0.35), _mix(s.bot, _c(0xFFFFE3EC), 0.5));
    _stars(g, t, n, 40, hz - 4);
    _celestial(g, hour, hz);
    _clouds(g, t, n, 4, 5, speed: 1.0);
    // Mount Fuji
    final fx = (g.cols * 0.32).round();
    final fh = (g.rows * 0.3).round();
    for (int row = 0; row < fh; row++) {
      final half = (row * 1.25).round();
      final snow = row < fh * 0.28;
      final col = snow ? _nt(_c(0xFFFFFFFF), n) : _nt(_c(0xFF5B7DB1), n);
      g.r(fx - half, hz - fh + row, half * 2 + 1, 1, col);
    }
    g.hills(t, 0.4, hz - 2, 3, 0.1, 1.0, _nt(_c(0xFF8FBF8A), n));
    g.hills(t, 1.0, hz + 3, 3, 0.13, 4.0, _nt(_c(0xFF6FA86B), n));
    final gy = g.rows - 7;
    g.r(0, gy, g.cols, 7, _nt(_c(0xFF86C47A), n));
    g.r(0, gy, g.cols, 1, _nt(_c(0xFFA6DA8F), n));
    g.scroll(t, 3.0, 9, (i, x) {
      if (_h(i) % 2 == 0) g.r(x, gy + 2 + _h(i + 1) % 3, 2, 1, _nt(_c(0xFFF7B6CE), n));
    });
    // blossom tree on the right
    final tx = (g.cols * 0.82).round();
    final trunk = _nt(_c(0xFF5A3A2A), n);
    g.r(tx, gy - 18, 3, 19, trunk);
    g.r(tx - 6, gy - 14, 6, 2, trunk);
    g.r(tx + 3, gy - 11, 6, 2, trunk);
    final pinks = [_c(0xFFF7A8C4), _c(0xFFFFC2D6), _c(0xFFE986A9)];
    const blobs = [
      (0, -22, 9),
      (-8, -17, 7),
      (9, -18, 7),
      (-3, -26, 6),
      (6, -13, 5),
      (-9, -12, 4),
    ];
    for (int i = 0; i < blobs.length; i++) {
      final b = blobs[i];
      g.disc(tx + 1 + b.$1, gy + b.$2, b.$3, _nt(pinks[i % 3], n));
    }
    // falling petals
    for (int i = 0; i < 40; i++) {
      final sp = 2.5 + _rf(i + 20) * 3;
      final y = (t * sp + _rf(i) * g.rows) % g.rows;
      final x = ((_rf(i + 60) * g.cols + sin(t * 1.2 + i) * 3 - t * 1.5) % g.cols + g.cols) % g.cols;
      g.r(x, y, i % 3 == 0 ? 2 : 1, 1, _nt(pinks[i % 3], n * 0.5));
    }
  }

  // ── underwater ──
  void _sea(_G g, double t, double hour) {
    final n = _skyAt(hour).night * 0.45;
    g.sky(_nt(_c(0xFF4FC3E8), n), _nt(_c(0xFF0A2A5E), n));
    for (int k = 0; k < 5; k++) {
      final ray = _c(0x16FFFFFF);
      for (int y = 0; y < (g.rows * 0.75).round(); y += 1) {
        final x = k * 20 + y * 0.45 + sin(t * 0.3 + k) * 4;
        g.r(x, y, 3 + (k % 2) * 2, 1, ray);
      }
    }
    for (int x = 0; x < g.cols; x++) {
      final y = (sin(x * 0.3 + t * 2) * 1.2).round() + 1;
      g.r(x, y, 1, 1, _c(0xFFCFF6FF));
    }
    // far fish school + jellyfish
    for (int i = 0; i < 5; i++) {
      final dir = i.isEven ? 1 : -1;
      final span = g.cols + 24;
      var x = ((t * (3 + i) + _rf(i) * span) % span) - 12;
      if (dir < 0) x = g.cols - x;
      final y = g.rows * (0.2 + 0.12 * i) + sin(t + i) * 2;
      _fish(g, x, y, dir, _c([0xFFFFB703, 0xFFFB8500, 0xFFFF70A6, 0xFF8ECAE6, 0xFFB5E48C][i]));
    }
    final jx = g.cols * 0.7 + sin(t * 0.4) * 6;
    final jy = g.rows * 0.4 + sin(t * 0.9) * 4;
    g.disc(jx.round(), jy.round(), 4, _c(0xAAFF9AD5));
    for (int k = -3; k <= 3; k += 2) {
      for (int j = 0; j < 6; j++) {
        g.r(jx.round() + k + (sin(t * 2 + j * 0.6 + k) * 1).round(), jy.round() + 2 + j, 1, 1,
            _c(0x99FFB3E6));
      }
    }
    // seabed
    final by = g.rows - 5;
    g.r(0, by, g.cols, 5, _c(0xFFD9B77A));
    g.r(0, by, g.cols, 1, _c(0xFFEBCF98));
    for (int i = 0; i < 9; i++) {
      final x = i * 11 + 3 + _h(i) % 4;
      final ht = 8 + _h(i + 3) % 7;
      final col = i % 3 == 0 ? _c(0xFF2A9D8F) : _c(0xFF3FBF6B);
      for (int k = 0; k < ht; k++) {
        final dx = (sin(t * 1.5 + k * 0.5 + i) * 1.6).round();
        g.r(x + dx, by - k, 2, 1, col);
      }
    }
    for (int i = 0; i < 4; i++) {
      final x = 8 + i * 23;
      g.r(x, by - 3, 4, 3, _c(0xFFFF6B6B));
      g.r(x + 1, by - 5, 2, 2, _c(0xFFFF8E8E));
      g.r(x + 3, by - 4, 2, 4, _c(0xFFE05555));
    }
    // bubbles
    for (int i = 0; i < 18; i++) {
      final sp = 3 + _rf(i + 11) * 4;
      final y = g.rows - ((t * sp + _rf(i) * g.rows) % g.rows);
      final x = _rf(i + 33) * g.cols + sin(t + i) * 1.5;
      g.r(x, y, i % 4 == 0 ? 2 : 1, i % 4 == 0 ? 2 : 1, _c(0xAAFFFFFF));
    }
  }

  void _fish(_G g, double x, double y, int dir, Color col) {
    final xi = x.round();
    final yi = y.round();
    final d = dir.toDouble();
    g.r(xi, yi, 5, 3, col);
    g.r(xi + (d > 0 ? 1 : 0), yi - 1, 3, 1, col);
    g.r(d > 0 ? xi - 2 : xi + 5, yi, 2, 1, col);
    g.r(d > 0 ? xi - 2 : xi + 6, yi - 1, 1, 3, col);
    g.r(d > 0 ? xi + 4 : xi, yi, 1, 1, const Color(0xFF111111));
  }

  // ── desert ──
  void _desert(_G g, double t, double hour) {
    final s = _skyAt(hour);
    final n = s.night;
    final hz = (g.rows * 0.55).round();
    g.sky(_mix(s.top, _c(0xFFF2A65A), 0.15), _mix(s.bot, _c(0xFFFFD9A0), 0.5));
    _stars(g, t, n, 55, hz - 3);
    _celestial(g, hour, hz);
    _clouds(g, t, n, 2, 6, speed: 0.8);
    // pyramids
    g.scroll(t, 0.35, 70, (i, x) {
      final hh = 10 + _h(i) % 6;
      for (int row = 0; row < hh; row++) {
        g.r(x - row, hz - hh + row + 4, row * 2 + 1, 1,
            _nt(row % 4 == 3 ? _c(0xFFC9964F) : _c(0xFFD9A85F), n));
      }
    });
    g.hills(t, 0.7, hz + 2, 3, 0.08, 0.5, _nt(_c(0xFFE8B66E), n));
    g.hills(t, 1.6, hz + 8, 4, 0.1, 2.5, _nt(_c(0xFFD99A4E), n));
    g.scroll(t, 1.6, 37, (i, x) {
      if (_h(i) % 3 != 0) _cactus(g, x, hz + 12, _nt(_c(0xFF3E8E4E), n));
    });
    g.hills(t, 3.0, g.rows - 12, 3, 0.14, 4.0, _nt(_c(0xFFB9783A), n),
        edge: _nt(_c(0xFFE2A25E), n));
    // tumbleweed
    final tw = ((t * 9) % (g.cols + 30)) - 10;
    final ty = g.rows - 9 - (sin(t * 7).abs() * 3);
    g.disc(tw.round(), ty.round(), 2, _nt(_c(0xFF8A5A2B), n));
    g.disc(tw.round(), ty.round(), 1, _nt(_c(0xFFB9783A), n));
    if (n < 0.5) {
      // sun-bleached shimmer lines
      for (int i = 0; i < 6; i++) {
        final y = hz + 1 + i;
        final x = ((_rf(i + 4) * g.cols + t * 2) % g.cols);
        g.r(x, y, 6, 1, _c(0x22FFFFFF));
      }
    }
  }

  void _cactus(_G g, double x, int baseY, Color col) {
    final xi = x.floor();
    g.r(xi, baseY - 10, 2, 10, col);
    g.r(xi - 3, baseY - 7, 3, 1, col);
    g.r(xi - 3, baseY - 9, 1, 3, col);
    g.r(xi + 2, baseY - 5, 3, 1, col);
    g.r(xi + 4, baseY - 7, 1, 3, col);
  }

  // ── night city ──
  void _city(_G g, double t) {
    const night = 1.0;
    g.sky(_c(0xFF0B1030), _c(0xFF3B2A6B));
    _stars(g, t, night, 60, (g.rows * 0.5).round());
    g.disc((g.cols * 0.78).round(), (g.rows * 0.16).round(), 5, _c(0xFFF4F1DE));
    g.r((g.cols * 0.78).round() + 1, (g.rows * 0.16).round() - 2, 2, 2, _c(0xFFD8D4BC));
    _clouds(g, t, 0.9, 3, 8, speed: 0.8);
    final ground = g.rows - 5;
    _buildings(g, t, 0.8, 9, 7, ground, _c(0xFF1A1F3D), _c(0xFFB89A4A), 0.25, 0.2, 7);
    _buildings(g, t, 2.2, 17, 13, ground, _c(0xFF0E1128), _c(0xFFFFD66B), 0.45, 0.28, 15);
    // neon sign
    if (sin(t * 4) > -0.4) {
      final x = (g.cols * 0.2).round();
      final y = (g.rows * 0.55).round();
      g.r(x, y, 14, 4, _c(0xFFFF2E93));
      g.r(x + 1, y + 1, 12, 2, _c(0xFF0E1128));
      g.r(x + 2, y + 1, 3, 1, _c(0xFFFF8CC6));
      g.r(x + 7, y + 2, 4, 1, _c(0xFF6EE7FF));
    }
    g.r(0, ground, g.cols, 5, _c(0xFF080A1A));
    g.r(0, ground, g.cols, 1, _c(0xFF2A2F5A));
    g.scroll(t, 6.0, 10, (i, x) => g.r(x, ground + 3, 4, 1, _c(0xFF6B6F9A)));
    // street lamps
    g.scroll(t, 6.0, 30, (i, x) {
      g.r(x, ground - 9, 1, 9, _c(0xFF2A2F5A));
      g.r(x - 1, ground - 10, 3, 1, _c(0xFFFFE08A));
      g.r(x - 2, ground - 9, 5, 1, _c(0x55FFE08A));
    });
  }

  void _buildings(_G g, double t, double speed, int spacing, int width, int ground, Color body,
      Color win, double base, double extra, int seed) {
    g.scroll(t, speed, spacing, (i, x) {
      final ht = (g.rows * base + (_h(i + seed) % 100) / 100.0 * g.rows * extra).round();
      final top = ground - ht;
      g.r(x, top, width, ht, body);
      g.r(x, top, width, 1, _mix(body, const Color(0xFFFFFFFF), 0.08));
      if (i % 4 == 0) g.r(x + width ~/ 2, top - 4, 1, 4, body); // antenna
      for (int wy = top + 3; wy < ground - 2; wy += 3) {
        for (int wx = 1; wx < width - 1; wx += 2) {
          final key = i * 131 + wx * 17 + wy * 7;
          var lit = _h(key) % 100 < 45;
          if (_h(key + (t / 5).floor() * 3) % 100 < 3) lit = !lit;
          if (lit) {
            g.r(x + wx, wy, 1, 2, _h(key + 1) % 6 == 0 ? const Color(0xFF6EE7FF) : win);
          }
        }
      }
    });
  }

  // ── space ──
  void _space(_G g, double t) {
    g.sky(_c(0xFF05030F), _c(0xFF1A0B3B));
    // nebula blobs
    g.disc((g.cols * 0.2).round(), (g.rows * 0.25).round(), 14, _c(0x1AFF66CC));
    g.disc((g.cols * 0.25).round(), (g.rows * 0.3).round(), 9, _c(0x1A9D5CFF));
    g.disc((g.cols * 0.85).round(), (g.rows * 0.75).round(), 16, _c(0x1A4CC9F0));
    // star layers with parallax
    for (int layer = 0; layer < 3; layer++) {
      final cnt = 30 + layer * 8;
      final sp = 1.0 + layer * 2.5;
      for (int i = 0; i < cnt; i++) {
        final k = i + layer * 100;
        final x = ((_rf(k) * g.cols - t * sp) % g.cols + g.cols) % g.cols;
        final y = _rf(k + 500) * g.rows;
        final tw = sin(t * 2 + k).abs();
        final col = layer == 2
            ? const Color(0xFFFFFFFF)
            : (tw > 0.5 ? const Color(0xFFCAD3FF) : const Color(0xFF7480B8));
        g.r(x, y, layer == 2 ? 2 : 1, layer == 2 ? 2 : 1, col);
      }
    }
    // planet with ring
    final cx = (g.cols * 0.7).round();
    final cy = (g.rows * 0.3).round();
    final rad = (g.cols * 0.13).round();
    final rw = (rad * 1.9).round();
    final rh = (rad * 0.4).round();
    for (int dx = -rw; dx <= rw; dx++) {
      final yy = (sqrt(max(0.0, 1 - (dx / rw) * (dx / rw))) * rh).round();
      g.r(cx + dx, cy - yy, 1, 1, _c(0xFFF2D6A2));
    }
    g.disc(cx, cy, rad, _c(0xFFE07A5F));
    for (int dy = -rad; dy <= rad; dy++) {
      final w = sqrt((rad * rad - dy * dy).toDouble()).round();
      if (dy % 5 == 0) g.r(cx - w, cy + dy, w * 2 + 1, 1, _c(0xFFC95F47));
      g.r(cx + (w * 0.35).round(), cy + dy, (w * 0.65).round() + 1, 1, _c(0x33000000));
    }
    g.disc(cx - rad ~/ 3, cy - rad ~/ 3, rad ~/ 4, _c(0xFFF09C85));
    for (int dx = -rw; dx <= rw; dx++) {
      final yy = (sqrt(max(0.0, 1 - (dx / rw) * (dx / rw))) * rh).round();
      g.r(cx + dx, cy + yy, 1, 1, _c(0xFFF2D6A2));
    }
    // small orbiting moon
    final mx = cx + (cos(t * 0.35) * rw * 1.15).round();
    final my = cy + (sin(t * 0.35) * rh * 1.6).round() - rad ~/ 2;
    g.disc(mx, my, 2, _c(0xFFB8C0D8));
    // shooting star
    final ph = (t % 8) / 8;
    if (ph < 0.12) {
      final f = ph / 0.12;
      final sx = g.cols * 0.15 + f * g.cols * 0.5;
      final sy = g.rows * 0.1 + f * g.rows * 0.25;
      for (int k = 0; k < 8; k++) {
        g.r(sx - k, sy - k * 0.5, 1, 1, _mix(const Color(0xFFFFFFFF), const Color(0x00FFFFFF), k / 8));
      }
    }
    // little rocket drifting
    final rx = ((t * 4) % (g.cols + 30)) - 15;
    final ry = g.rows * 0.78 + sin(t * 0.8) * 3;
    g.r(rx, ry, 6, 2, _c(0xFFEDEDED));
    g.r(rx + 6, ry, 2, 2, _c(0xFFFF5D5D));
    g.r(rx + 2, ry - 1, 2, 1, _c(0xFF6EE7FF));
    g.r(rx - 2, ry, 2, 2, (t * 6).floor().isEven ? _c(0xFFFFB703) : _c(0xFFFF6B35));
  }
}

// ───────────────────────── Shop / chooser screen ─────────────────────────

class BgShopScreen extends StatelessWidget {
  const BgShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return PixelPage(
      title: t('bgs'),
      actions: [coinChip()],
      child: ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(14),
          children: [
            infoBox(t('bg_help')),
            const SizedBox(height: 12),
            for (final d in kBgs) ...[
              _card(context, d),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, BgDef d) {
    final s = AppState.I;
    final owned = s.ownedBg.contains(d.id) || d.unlocked(s);
    return PixelBox(
      padding: const EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          GestureDetector(
            onTap: d.id == 'none' ? null : () => _fullPreview(context, d),
            child: SizedBox(
              height: 130,
              child: ClipRect(
                child: d.id == 'none'
                    ? ColoredBox(color: C.creamDeep, child: Center(child: tx(d.name, bold: true)))
                    : Stack(
                        fit: StackFit.expand,
                        children: [
                          BgScene(id: d.id),
                          Positioned(
                            left: 6,
                            bottom: 6,
                            child: Container(
                              color: const Color(0x99000000),
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              child: Text(t('bg_preview'),
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: tx(d.name, bold: true, size: 15)),
              if (!owned)
                PixelButton(
                  label: '${d.price}',
                  icon: 'coin',
                  small: true,
                  filled: true,
                  onTap: () {
                    if (s.coins >= d.price) {
                      s.coins -= d.price;
                      s.ownedBg.add(d.id);
                      s.bgHome = d.id;
                      s.saveExtra();
                      Sfx.play('win');
                    } else {
                      toast(context, t('not_enough_coins'));
                    }
                  },
                ),
            ],
          ),
          if (!owned && d.hint() != null) ...[
            const SizedBox(height: 6),
            tx(d.hint()!, size: 12, color: C.dark),
          ],
          if (owned) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: PixelButton(
                    label: s.bgHome == d.id ? t('bg_in_home') : t('bg_home'),
                    small: true,
                    expand: true,
                    filled: s.bgHome != d.id,
                    onTap: s.bgHome == d.id
                        ? null
                        : () {
                            if (!s.ownedBg.contains(d.id)) s.ownedBg.add(d.id);
                            s.bgHome = d.id;
                            s.saveExtra();
                          },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: PixelButton(
                    label: s.bgGames == d.id ? t('bg_in_games') : t('bg_games'),
                    small: true,
                    expand: true,
                    filled: s.bgGames != d.id,
                    onTap: s.bgGames == d.id
                        ? null
                        : () {
                            if (!s.ownedBg.contains(d.id)) s.ownedBg.add(d.id);
                            s.bgGames = d.id;
                            s.saveExtra();
                          },
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  void _fullPreview(BuildContext context, BgDef d) {
    Sfx.play('tap');
    showDialog<void>(
      context: context,
      barrierColor: Colors.black,
      builder: (_) => GestureDetector(
        onTap: () => Navigator.of(context).maybePop(),
        child: Material(
          color: Colors.black,
          child: Stack(
            fit: StackFit.expand,
            children: [
              BgScene(id: d.id),
              Positioned(
                top: 40,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    color: const Color(0x99000000),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text(d.name,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
